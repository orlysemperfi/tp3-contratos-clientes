﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.GD
{
    [Serializable()]
    class FormularioGeneracion
    {
        private List<FormularioGeneracionDetalle > _lista;
        public List<FormularioGeneracionDetalle> DetalleFormulario
        {
            get { return _lista; }
            set { _lista = value; }
        }

    }
}
