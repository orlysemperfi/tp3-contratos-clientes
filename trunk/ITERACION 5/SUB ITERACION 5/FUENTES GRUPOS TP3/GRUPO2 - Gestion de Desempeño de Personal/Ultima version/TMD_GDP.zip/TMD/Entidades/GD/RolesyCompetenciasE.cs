﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.GD
{
    public class RolesyCompetenciasE
    {
        public string COMPETENCIA { get; set; }
        public Int32 COD_ID { get; set; }
        public Int32 COD_I { get; set; }
        public string NIVEL_1 { get; set; }
        public string NIVEL_2 { get; set; }
        public string NIVEL_3 { get; set; }
        public string NIVEL_4 { get; set; }
        public string NIVEL_5 { get; set; }

    }
}
