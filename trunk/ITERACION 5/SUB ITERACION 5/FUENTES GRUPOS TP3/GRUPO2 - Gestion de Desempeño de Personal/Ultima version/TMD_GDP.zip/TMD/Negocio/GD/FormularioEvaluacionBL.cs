﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.GD;
using Entidades.GD;

namespace Negocio.GD
{
    public class FormularioEvaluacionBL : Negocio.GD.IFormularioEvaluacionBL
    {
        private IFormularioEvaluacionDAO forEvaluacion = new FormularioEvaluacionDAO();
        public Int32 insertarFormularioEvaluacion(String NOMBRE)
        {
            return forEvaluacion.insertarFormularioEvaluacion(NOMBRE);
        }


        public void insertaEvaluacionDetalle(Int32 CODIGO, Int32 CODIGO_SECCION, Int32 CODIGO_SECCION_DETALLE)
        {
            forEvaluacion.insertaEvaluacionDetalle(CODIGO,CODIGO_SECCION,CODIGO_SECCION_DETALLE );
        }

        public void eliminaEvaluacionDetalle(Int32 CODIGO)
        {
            forEvaluacion.eliminaEvaluacionDetalle(CODIGO);
        }

        public void insertaEvaluacionCalificacion(Int32 CODIGO, Int32 CODIGO_TIPO, Int32 CODIGO_COMPETENCIA, Int32 CODIGO_COMPETENCIA_DETALLE)
        {
            forEvaluacion.insertaEvaluacionCalificacion(CODIGO, CODIGO_TIPO, CODIGO_COMPETENCIA, CODIGO_COMPETENCIA_DETALLE);
        }

        public void actualizaFormulario(Int32 CODIGO, String NOMBRE)
        {
            forEvaluacion.actualizaFormulario(CODIGO, NOMBRE);
        }

    }
}
