﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.GD;
using System.Data.SqlClient;
using Datos.GEN;
using System.Data;


namespace Datos.GD
{
    public class FormularioDetalleDAO : IFormularioDetalleDAO
    {
        public List<FormularioDetalleE> ListaDetalle(Int32 empleado,Int32 formulario)
        {
            ConexionDAO cn = new ConexionDAO();
            List<FormularioDetalleE> listDet = new List<FormularioDetalleE>();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EMPLEADO_SEL", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_EMPLEADO", empleado));
                    //cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO", formulario));
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        FormularioDetalleE fdet = new FormularioDetalleE();
                        fdet.CODIGO_SECCION_DETALLE = reader.GetInt32(8);
                        fdet.SECCION = reader.GetString(7);
                        fdet.SECCION_DETALLE = reader.GetString(9);
                        fdet.CODIGO_SECCION = reader.GetInt32(6);
                        
                        listDet.Add(fdet);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listDet;
        }





        public List<FormularioDetalleE> ListaDetalleCLF(Int32 evaluador)
        {
            ConexionDAO cn = new ConexionDAO();
            List<FormularioDetalleE> listDet = new List<FormularioDetalleE>();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EVALUACION_EMPLEADO_EVALUADOR_SEL", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_EVALUADOR", evaluador));
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        FormularioDetalleE fdet = new FormularioDetalleE();
                        fdet.CODIGO_SECCION_DETALLE = reader.GetInt32(7);
                        fdet.SECCION = reader.GetString(6);
                        fdet.SECCION_DETALLE = reader.GetString(8);
                        fdet.CODIGO_SECCION = reader.GetInt32(5);
                        fdet.VALOR_CAMPO = reader.GetString(11);
                        listDet.Add(fdet);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listDet;
        }





        public void IngresaDetalle(Int32 formulario,Int32 empleado, Int32 codseccion,string seccion)
        {

            ConexionDAO cn = new ConexionDAO();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EVALUACION_EMPLEADO_SECCION_INS", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO", formulario));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_EMPLEADO", empleado));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_SECCION", codseccion));
                    cmd.Parameters.Add(new SqlParameter("@VALOR_SECCION", seccion));

                    int response = cmd.ExecuteNonQuery();

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }




        public List<FormularioCalificacionE> ListaDetalleC(Int32 empleado, Int32 formulario)
        {
            ConexionDAO cn = new ConexionDAO();
            List<FormularioCalificacionE> listDet = new List<FormularioCalificacionE>();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_DETALLE_SELC", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_EMPLEADO", empleado));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO", formulario));
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        FormularioCalificacionE fcal = new FormularioCalificacionE();
                        fcal.CODIGO_SECCION = reader.GetInt32(2);
                        fcal.SECCION = reader.GetString(1);
                        listDet.Add(fcal);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listDet;
        }




        public List<RolesyCompetenciasE> ListaCombo(Int32 formulario)
        {
            ConexionDAO cn = new ConexionDAO();
            List<RolesyCompetenciasE> listR = new List<RolesyCompetenciasE>();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_COMBO_COMPETENCIA_SEL", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO", formulario));
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        RolesyCompetenciasE fcb = new RolesyCompetenciasE();
                        fcb.COMPETENCIA = reader.GetString(0);
                        fcb.COD_ID = reader.GetInt32(1);
                        fcb.NIVEL_1 = reader.GetString(2);
                        fcb.NIVEL_2 = reader.GetString(3);
                        fcb.NIVEL_3 = reader.GetString(4);
                        fcb.NIVEL_4 = reader.GetString(5);
                        fcb.NIVEL_5 = reader.GetString(6);
                        fcb.COD_I = reader.GetInt32(7);
                        listR.Add(fcb);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listR;
        }


        //enviar una entidad
        public void InsertarAuto(Int32 formulario,Int32 empleado,Int32 seccion,Int32 detalle,string valor)
        {

            ConexionDAO cn = new ConexionDAO();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EVALUACION_EMPLEADO_SECCION_INS", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO_EVALUACION", formulario));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_EMPLEADO", empleado));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_SECCION", seccion));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_SECCION_DETALLE", detalle));
                    cmd.Parameters.Add(new SqlParameter("@VALOR_SECCION", valor));

                    int response = cmd.ExecuteNonQuery();

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }


        public void Actualizar(Int32 formulario, Int32 empleado, string fecha,string estado)
        {

            ConexionDAO cn = new ConexionDAO();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EVALUACION_EMPLEADO_EVALUADO_UPD", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO_EVALUACION", formulario));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_EMPLEADO", empleado));
                    cmd.Parameters.Add(new SqlParameter("@FECHA", fecha));
                    cmd.Parameters.Add(new SqlParameter("@ESTADO", estado));

                    int response = cmd.ExecuteNonQuery();

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }


        public void IngresaCompetencias(Int32 formulario, Int32 empleado, Int32 tcalif, Int32 i, Int32 id, String calificacion)
        {

            ConexionDAO cn = new ConexionDAO();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EVALUACION_EMPLEADO_CALIFICACION_INS", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO_EVALUACION", formulario));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_EMPLEADO", empleado));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_TIPO_CALIFICACION_EVALUACION", tcalif));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_COMPETENCIA_INDICADOR", i));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_COMPETENCIA_INDICADOR_DETALLE", id));
                    cmd.Parameters.Add(new SqlParameter("@VALOR_CALIFICACION", calificacion));

                    int response = cmd.ExecuteNonQuery();

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }













        public List<FormularioE> getFormulario()
        {
            ConexionDAO cn = new ConexionDAO();

            List<FormularioE> listF = new List<FormularioE>();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_SECCION_SEL", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        FormularioE form = new FormularioE();
                        form.CODIGO_SECCION = reader.GetInt32(0);
                        form.SECCION = reader.GetString(1);
                        form.CODIGO_SECCION_DETALLE = reader.GetInt32(2);
                        form.SECCION_DETALLE = reader.GetString(3);
                        listF.Add(form);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listF;
        }






    }
}
