﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Negocio.GD
{
    public interface IFormularioCabeceraBL
    {
        Entidades.GD.FormularioCabeceraE llenarCabecera(Int32 codigoEmpleado);
        Entidades.GD.FormularioCabeceraE llenarCabeceraC(Int32 codigoEmpleado);
        Int32 VALIDA_EVALUACION(Int32 empleado, Int32 formulario, string estado);
    }
}
