﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.GD;

namespace Datos.GD
{
    public interface IFormularioEvaluacionDAO
    {
       Int32 insertarFormularioEvaluacion(String NOMBRE);
       void insertaEvaluacionDetalle(Int32 CODIGO, Int32 CODIGO_SECCION, Int32 CODIGO_SECCION_DETALLE);
       void eliminaEvaluacionDetalle(Int32 CODIGO);
       void insertaEvaluacionCalificacion(Int32 CODIGO, Int32 CODIGO_TIPO, Int32 CODIGO_COMPETENCIA, Int32 CODIGO_COMPETENCIA_DETALLE);
       void actualizaFormulario(Int32 CODIGO, String NOMBRE);
    }
}
