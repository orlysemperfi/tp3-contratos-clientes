﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.GD;
using System.Data.SqlClient;
using Datos.GEN;
using System.Data;

namespace Datos.GD
{
    public class FormularioCabeceraDAO : IFormularioCabeceraDAO
    {
        public FormularioCabeceraE llenarCabecera(Int32 codigoEmpleado)
        {
            ConexionDAO cn = new ConexionDAO();
            FormularioCabeceraE formulario = new FormularioCabeceraE();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EMPLEADO_SEL", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_EMPLEADO", codigoEmpleado));
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        
                            if (reader.GetInt32(8) != 6)
                            {
                                formulario.CODIGO_EMPLEADO = reader.GetInt32(13);
                                formulario.EVALUADO = reader.GetString(3);
                                formulario.ROL = reader.GetString(11);
                                formulario.PROYECTO = reader.GetString(10);
                                formulario.FECHA = DateTime.Today.ToString("dd/MM/yyyy");
                                formulario.FRECEPCION = reader.GetDateTime(0).ToString("dd/MM/yyyy");
                                formulario.EVALUADOR = reader.GetString(4);
                                formulario.NOMBRE = reader.GetString(1);
                                formulario.ESTADO = reader.GetString(2);
                                formulario.AREA = reader.GetString(5);
                                formulario.CODIGO_PROYECTO = reader.GetInt32(12);
                            }
                        
                        



                        
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return formulario;
        }




        public FormularioCabeceraE llenarCabeceraC(Int32 codigoEmpleado)
        {
            ConexionDAO cn = new ConexionDAO();
            FormularioCabeceraE formulario = new FormularioCabeceraE();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EMPLEADO_SELC", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_EMPLEADO", codigoEmpleado));
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {


                            formulario.CODIGO_EMPLEADO = reader.GetInt32(13);
                            formulario.EVALUADO = reader.GetString(3);
                            formulario.ROL = reader.GetString(11);
                            formulario.PROYECTO = reader.GetString(10);
                            formulario.FECHA = DateTime.Today.ToString("dd/MM/yyyy");
                            formulario.FRECEPCION = reader.GetDateTime(0).ToString("dd/MM/yyyy");
                            formulario.EVALUADOR = reader.GetString(4);
                            formulario.NOMBRE = reader.GetString(1);
                            formulario.ESTADO = reader.GetString(2);
                            formulario.AREA = reader.GetString(5);
                            formulario.CODIGO_PROYECTO = reader.GetInt32(12);







                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return formulario;
        }



        public Int32 VALIDA_EVALUACION(Int32 empleado,Int32 formulario,string estado)
        {
            ConexionDAO cn = new ConexionDAO();
            Int32 valida=0;

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_VALIDA_EVALUACIONES", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO", formulario));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_EMPLEADO", empleado));
                    cmd.Parameters.Add(new SqlParameter("@ESTADO", estado));
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {

                        valida = reader.GetInt32(0);

                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return valida;
        }


    }
}
