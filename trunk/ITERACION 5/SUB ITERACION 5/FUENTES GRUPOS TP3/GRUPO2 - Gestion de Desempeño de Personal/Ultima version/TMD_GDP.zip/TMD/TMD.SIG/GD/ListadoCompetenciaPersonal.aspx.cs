﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.GD;
using Entidades.GD;
using TMD.SIG.Util;


namespace TMD.SIG.GD
{
    public partial class ListadoCompetenciaPersonal : System.Web.UI.Page
    {

        private ICompetenciaPersonalBL forev = new CompetenciaPersonalBL();


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ListaCompetencia();
        
            }

        }

        protected void bntGrabar_Click(object sender, EventArgs e)
        {
            Response.Redirect("RegistroCompetenciaPersonal.aspx");
        }



        public void ListaCompetencia()
        {
            this.GridView1.DataSource = forev.listadoCompetencia();
            this.GridView1.DataBind();
        }


        protected void bntCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/GD/GD_Index.aspx");
        }


        protected void Modificar_click(object sender, EventArgs e)
        {
            string codigo = ((LinkButton)sender).CommandArgument.ToString();
            Response.Redirect("../GD/RegistroCompetenciaPersonal.aspx?codigo=" + codigo);
        }

        protected void Eliminar_click(object sender, EventArgs e)
        {
            string codigo = ((LinkButton)sender).CommandArgument.ToString();

            Int32 vresult = forev.EliminarCompetencia(Convert.ToInt32(codigo));
            
            if (vresult == 1)
            {
                ClientMessageBox.Show("Se realizó la eliminación exitosamente ", this);
            }
            else
            {
                ClientMessageBox.Show("La competencia seleccionada tiene formulario asignado, no se puede eliminar", this);
            }
            ListaCompetencia();

        }


    }
}