﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.GD;
using Entidades.GD;

namespace Negocio.GD
{
    public class FormularioCabeceraBL : Negocio.GD.IFormularioCabeceraBL
    {
        private IFormularioCabeceraDAO forcab = new FormularioCabeceraDAO();

        public FormularioCabeceraE llenarCabecera(Int32 codigoEmpleado)
        {
            return forcab.llenarCabecera(codigoEmpleado);
        }

        public FormularioCabeceraE llenarCabeceraC(Int32 codigoEmpleado)
        {
            return forcab.llenarCabeceraC(codigoEmpleado);
        }

        public Int32 VALIDA_EVALUACION(Int32 empleado, Int32 formulario, string estado)
        {
            return forcab.VALIDA_EVALUACION(empleado, formulario, estado);
        }
    }
}
