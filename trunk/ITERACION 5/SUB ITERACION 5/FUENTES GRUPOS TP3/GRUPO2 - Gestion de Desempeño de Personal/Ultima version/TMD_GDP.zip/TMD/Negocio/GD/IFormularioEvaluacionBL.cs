﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.GD;

namespace Negocio.GD
{
    public interface IFormularioEvaluacionBL
    {
        Int32 insertarFormularioEvaluacion(String NOMBRE);
        void insertaEvaluacionDetalle(Int32 CODIGO,Int32 CODIGO_SECCION_DETALLE, Int32 CODIGO_SECCION);
        void eliminaEvaluacionDetalle(Int32 CODIGO);
        void insertaEvaluacionCalificacion(Int32 CODIGO, Int32 CODIGO_TIPO, Int32 CODIGO_COMPETENCIA, Int32 CODIGO_COMPETENCIA_DETALLE);
        void actualizaFormulario(Int32 CODIGO, String NOMBRE);
    }
}
