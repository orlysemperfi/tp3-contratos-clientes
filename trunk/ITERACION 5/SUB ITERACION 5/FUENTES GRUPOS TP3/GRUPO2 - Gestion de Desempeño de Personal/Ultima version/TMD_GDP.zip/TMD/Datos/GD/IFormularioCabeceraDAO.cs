﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.GD;

namespace Datos.GD
{
    public interface IFormularioCabeceraDAO
    {
        FormularioCabeceraE llenarCabecera(Int32 codigoEmpleado);
        FormularioCabeceraE llenarCabeceraC(Int32 codigoEmpleado);
        Int32 VALIDA_EVALUACION(Int32 empleado, Int32 formulario, string estado);
    }
}
