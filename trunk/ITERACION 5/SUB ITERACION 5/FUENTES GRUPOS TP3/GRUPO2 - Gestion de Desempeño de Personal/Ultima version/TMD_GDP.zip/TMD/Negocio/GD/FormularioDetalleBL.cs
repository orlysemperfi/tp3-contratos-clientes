﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.GD;
using Entidades.GD;

namespace Negocio.GD
{
    public class FormularioDetalleBL : Negocio.GD.IFormularioDetalleBL
    {
        private IFormularioDetalleDAO fordet = new FormularioDetalleDAO();

        public List<FormularioDetalleE> ListaDetalle(Int32 empleado, Int32 formulario)
        {
            return fordet.ListaDetalle(empleado,formulario);
        }


        public List<FormularioCalificacionE> ListaDetalleC(Int32 empleado, Int32 formulario)
        {
            return fordet.ListaDetalleC(empleado, formulario);
        }

        public List<RolesyCompetenciasE> ListaCombo(Int32 formulario)
        {
            return fordet.ListaCombo(formulario);
        }

        public void InsertarAuto(Int32 formulario, Int32 empleado, Int32 seccion, Int32 detalle, string valor)
        {
            fordet.InsertarAuto(formulario, empleado, seccion, detalle, valor);
        }

        public void Actualizar(Int32 formulario, Int32 empleado, string fecha, string estado)
        {
            fordet.Actualizar(formulario, empleado, fecha, estado);
        }

        public List<FormularioDetalleE> ListaDetalleCLF(Int32 evaluador)
        {
            return fordet.ListaDetalleCLF(evaluador);
        }

        public void IngresaCompetencias(Int32 formulario, Int32 empleado, Int32 tcalif, Int32 i, Int32 id, String calificacion)
        {
            fordet.IngresaCompetencias(formulario, empleado, tcalif, i, id, calificacion);
        }

        public List<FormularioE> getFormulario()
        {
            return fordet.getFormulario();
        }
      
    }
}
