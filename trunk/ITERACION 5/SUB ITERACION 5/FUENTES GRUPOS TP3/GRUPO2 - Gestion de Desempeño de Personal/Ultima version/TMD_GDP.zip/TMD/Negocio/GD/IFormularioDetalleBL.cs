﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Negocio.GD
{
    public interface IFormularioDetalleBL
    {
        System.Collections.Generic.List<Entidades.GD.FormularioDetalleE> ListaDetalle(Int32 empleado, Int32 formulario);
        System.Collections.Generic.List<Entidades.GD.FormularioCalificacionE> ListaDetalleC(Int32 empleado, Int32 formulario);
        System.Collections.Generic.List<Entidades.GD.RolesyCompetenciasE> ListaCombo(Int32 formulario);
        void InsertarAuto(Int32 formulario, Int32 empleado, Int32 seccion, Int32 detalle, string valor);
        void Actualizar(Int32 formulario, Int32 empleado, string fecha, string estado);
        System.Collections.Generic.List<Entidades.GD.FormularioDetalleE> ListaDetalleCLF(Int32 evaluador);

        void IngresaCompetencias(Int32 formulario, Int32 empleado, Int32 tcalif, Int32 i, Int32 id, String calificacion);
        System.Collections.Generic.List<Entidades.GD.FormularioE> getFormulario();
    }
}
