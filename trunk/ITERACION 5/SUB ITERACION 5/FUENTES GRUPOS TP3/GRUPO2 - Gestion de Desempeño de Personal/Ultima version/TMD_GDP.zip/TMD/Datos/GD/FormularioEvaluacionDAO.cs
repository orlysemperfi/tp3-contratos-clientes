﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.GD;
using System.Data.SqlClient;
using Datos.GEN;
using System.Data;

namespace Datos.GD
{
    public class FormularioEvaluacionDAO : IFormularioEvaluacionDAO
    {
        
        public Int32 insertarFormularioEvaluacion(string NOMBRE) {
            ConexionDAO cn = new ConexionDAO();

            Int32 CODIGO = 0;
           using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EVALUACION_INS", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@NOMBRE_FORMULARIO", NOMBRE));

                    CODIGO = Convert.ToInt32(cmd.ExecuteScalar());

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
           return CODIGO;
    }

        public void insertaEvaluacionDetalle(Int32 CODIGO,Int32 CODIGO_SECCION, Int32 CODIGO_SECCION_DETALLE)
        {
            ConexionDAO cn = new ConexionDAO();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EVALUACION_SECCION_INS", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO_EVALUACION", CODIGO));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_SECCION", CODIGO_SECCION));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_SECCION_DETALLE", CODIGO_SECCION_DETALLE));
                  

                    Int32 cod = cmd.ExecuteNonQuery();

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
           
        }



        public void insertaEvaluacionCalificacion(Int32 CODIGO, Int32 CODIGO_TIPO, Int32 CODIGO_COMPETENCIA, Int32 CODIGO_COMPETENCIA_DETALLE)
        {
            ConexionDAO cn = new ConexionDAO();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EVALUACION_CALIFICACION_INS", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO_EVALUACION", CODIGO));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_TIPO_CALIFICACION_EVALUACION", CODIGO_TIPO));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_COMPETENCIA_INDICADOR", CODIGO_COMPETENCIA));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_COMPETENCIA_INDICADOR_DETALLE", CODIGO_COMPETENCIA_DETALLE));
                    

                    Int32 cod = cmd.ExecuteNonQuery();

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

        }


        public void eliminaEvaluacionDetalle(Int32 CODIGO)
        {

            ConexionDAO cn = new ConexionDAO();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EVALUACION_SECCION_DEL", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO_EVALUACION", CODIGO));



                    Int32 cod = cmd.ExecuteNonQuery();

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

        }




        public void actualizaFormulario(Int32 CODIGO,String NOMBRE)
        {

            ConexionDAO cn = new ConexionDAO();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EVALUACION_UPD", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_FORMULARIO", CODIGO));
                    cmd.Parameters.Add(new SqlParameter("@NOMBRE_FORMULARIO", NOMBRE));

                    Int32 cod = cmd.ExecuteNonQuery();

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

        }



}
}
