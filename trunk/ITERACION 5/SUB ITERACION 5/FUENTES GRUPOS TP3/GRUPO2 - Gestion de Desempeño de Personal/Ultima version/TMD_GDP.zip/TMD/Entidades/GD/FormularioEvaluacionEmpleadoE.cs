﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.GD
{
    public class FormularioEvaluacionEmpleadoE
    {
        public Int32 CODIGO { get; set; }
        public String NOMBRE { get; set; }
        public String ROL { get; set; }

    }
}
