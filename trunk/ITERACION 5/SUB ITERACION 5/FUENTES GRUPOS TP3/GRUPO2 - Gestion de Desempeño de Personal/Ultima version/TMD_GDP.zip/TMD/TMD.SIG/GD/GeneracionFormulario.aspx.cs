﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.GD;
using Entidades.GD;
using TMD.SIG.Util;

namespace TMD.SIG.GD
{
    public partial class GeneracionFormulario : System.Web.UI.Page
    {


        private IFormularioDetalleBL fdet = new FormularioDetalleBL();
        List<FormularioE> formulario = new List<FormularioE>();
        private ICompetenciaPersonalBL forev = new CompetenciaPersonalBL();
        Int32 CODIGO = 1;
  


        protected void Page_Load(object sender, EventArgs e)
        {


            if (!IsPostBack)
            {
                formulario = fdet.getFormulario();

                for (int i = 0; i < formulario.Count; i++)
                {


                    if (formulario[i].CODIGO_SECCION_DETALLE == 1)
                    {
                        lblSecA.Text = formulario[i].SECCION;
                        lblSec1.Text = formulario[i].SECCION_DETALLE;
                    }

                    if (formulario[i].CODIGO_SECCION_DETALLE == 2)
                    {
                        lblSec2.Text = formulario[i].SECCION_DETALLE;
                    }

                    if (formulario[i].CODIGO_SECCION_DETALLE == 3)
                    {
                        lblSecB.Text = formulario[i].SECCION;
                        lblSec3.Text = formulario[i].SECCION_DETALLE;
                    }

                    if (formulario[i].CODIGO_SECCION_DETALLE == 4)
                    {
                        lblSec4.Text = formulario[i].SECCION_DETALLE;
                    }

                    if (formulario[i].CODIGO_SECCION_DETALLE == 5)
                    {
                        lblSec5.Text = formulario[i].SECCION_DETALLE;
                    }
                    if (formulario[i].CODIGO_SECCION_DETALLE == 6)
                    {
                        lblSecC.Text = formulario[i].SECCION;
                        lblSec6.Text = formulario[i].SECCION_DETALLE;
                    }

                    this.GridView1.DataSource = forev.listadoCompetencia();
                    this.GridView1.DataBind();

                    this.GridView1.Columns[0].Visible = false;
                    this.GridView1.Columns[2].Visible = false;


                }
            }
            
            
            
            


        }



        protected void bntGrabar_Click(object sender, EventArgs e)
        {
           // String sec1, sec2, sec3, sec4, sec5,sec6;
             String nombre;

            FormularioEvaluacionBL fEvaluacion = new FormularioEvaluacionBL();


            nombre = txtFormulario.Text.Trim().ToUpper();

            if (nombre.Length==0)
            {
                ClientMessageBox.Show("Debe colocar un nombre al formulario", this);
                return;
            }

            if(!chksec1.Checked && !chksec2.Checked){
                ClientMessageBox.Show("Debe seleccionar al menos un campo para la seccion A", this);
                return;
            }


            if (!chksec3.Checked && !chksec4.Checked && !chksec5.Checked)
            {
                ClientMessageBox.Show("Debe seleccionar al menos un campo para la seccion B", this);
                return;
            }

            if (!chksec6.Checked)
            {
                ClientMessageBox.Show("Debe seleccionar al menos un campo para la seccion C", this);
                return;
            }
 

             try
             {

                 //Int32 CODIGO = fEvaluacion.insertarFormularioEvaluacion(nombre);
                 fEvaluacion.eliminaEvaluacionDetalle(CODIGO);
                 fEvaluacion.actualizaFormulario(CODIGO, nombre);



                 if (CODIGO > 0)
                 {
                    
                        
                         if (chksec1.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO,1,1);
             
                         }

                         if (chksec2.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO, 1, 2);
    
                         }
                         if (chksec3.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO, 2, 3);
      
                         }
                         if (chksec4.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO, 2, 4);
                       
                         }
                         if (chksec5.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO, 2, 5);
                             //lista.Add(fgeneradetalle);
                         }

                         if (chksec6.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO, 3, 6);
                             //lista.Add(fgeneradetalle);
                         }

                         //bool vResultado = false;

                         //vResultado = new Negocio.GD.FormularioDetalleBL().GenerarFormulario(lista);  
                    
                 }
             }
             catch (Exception)
             {
                 
                 throw;
             }


             CheckBox chk;
             Int32 codcomp = 0;
             Int32 codcompdet = 0;

             Int32 cont = 0;

             foreach (GridViewRow rowItem in GridView1.Rows)
             {
                 chk = (CheckBox)(rowItem.Cells[4].FindControl("chk1"));

                 if (chk.Checked)
                 {
                    cont+=1;
                 }
             }

            if (cont==0){
                ClientMessageBox.Show("Debe de marcar al menos una competencia",this);
                return;
            }


             foreach (GridViewRow rowItem in GridView1.Rows)
             {
                 chk = (CheckBox)(rowItem.Cells[4].FindControl("chk1"));
 
                 if (chk.Checked)
                 {
                     codcompdet = Convert.ToInt32(GridView1.DataKeys[rowItem.RowIndex]["CODIGO_COMPETENCIA_INDICADOR_DETALLE"].ToString());
                     codcomp = Convert.ToInt32(GridView1.DataKeys[rowItem.RowIndex]["CODIGO_COMPETENCIA_INDICADOR"].ToString());
                     fEvaluacion.insertaEvaluacionCalificacion(CODIGO, 1, codcomp, codcompdet);
                 }
             }





             Response.Redirect("~/GD/GD_Index.aspx?mensaje=3");  
        }

        protected void bntCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/GD/GD_Index.aspx");
        }
    }
}