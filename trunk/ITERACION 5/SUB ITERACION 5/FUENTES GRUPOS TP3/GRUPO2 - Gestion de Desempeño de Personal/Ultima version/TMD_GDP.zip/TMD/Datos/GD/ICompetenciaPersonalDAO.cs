﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.GD;

namespace Datos.GD
{
    public interface ICompetenciaPersonalDAO
    {

        List<CompetenciaPersonalE> listadoCompetencia();

        List<CompetenciaPersonalE> listadoCompetenciaIndicador();

        Int32 EliminarCompetencia(Int32 idcompetencia);

        void IngresaCompetencia(Int32 competencia_indicador, Int32 tipo_calificacion, string descripcion, string nivel1, string nivel2, string nivel3, string nivel4, string nivel5);

        CompetenciaPersonalE getCompetenciaPersonal(Int32 codigo);

        void ActualizaCompetencia(Int32 competencia_detalle, Int32 competencia_indicador, Int32 tipo_calificacion, string descripcion, string nivel1, string nivel2, string nivel3, string nivel4, string nivel5);

    }
}
