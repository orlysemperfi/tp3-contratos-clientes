﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.GD;

namespace Datos.GD
{
    public interface IFormularioEvaluacionEmpleadoDAO
    {
        List<FormularioEvaluacionEmpleadoE> listAll();
    }
}
