﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.GD;
using Entidades.GD;


namespace Negocio.GD
{
    public class CompetenciaPersonalBL : Negocio.GD.ICompetenciaPersonalBL
    {
        private ICompetenciaPersonalDAO forev = new CompetenciaPersonalDAO();

        public List<CompetenciaPersonalE> listadoCompetencia()
        {
            return forev.listadoCompetencia();
        }


        public List<CompetenciaPersonalE> listadoCompetenciaIndicador()
        {
            return forev.listadoCompetenciaIndicador();
        }

        public Int32 EliminarCompetencia(Int32 pidCompetencia)
        {
            return forev.EliminarCompetencia(pidCompetencia);
        }

        public void IngresaCompetencia(Int32 competencia_indicador, Int32 tipo_calificacion, string descripcion, string nivel1, string nivel2, string nivel3, string nivel4, string nivel5)
        {
            forev.IngresaCompetencia(competencia_indicador, tipo_calificacion, descripcion, nivel1, nivel2, nivel3, nivel4, nivel5);
        }

        public CompetenciaPersonalE getCompetenciaPersonal(Int32 codigo)
        {
            return forev.getCompetenciaPersonal(codigo);
        }

        public void ActualizaCompetencia(Int32 competencia_detalle, Int32 competencia_indicador, Int32 tipo_calificacion, string descripcion, string nivel1, string nivel2, string nivel3, string nivel4, string nivel5)
        {
            forev.ActualizaCompetencia(competencia_detalle, competencia_indicador, tipo_calificacion, descripcion, nivel1, nivel2, nivel3, nivel4, nivel5);
        }

    }
}
