﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.GD;
using System.Data.SqlClient;
using Datos.GEN;
using System.Data;

namespace Datos.GD
{
    public class FormularioEvaluacionEmpleadoDAO : IFormularioEvaluacionEmpleadoDAO
    {
        public List<FormularioEvaluacionEmpleadoE> listAll(){
            ConexionDAO cn = new ConexionDAO();
            List<FormularioEvaluacionEmpleadoE> listEv = new List<FormularioEvaluacionEmpleadoE>();
            
            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_FORMULARIO_EVALUACION_EMPLEADO_LISTAR", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_EVALUADOR", 2));
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        FormularioEvaluacionEmpleadoE eval = new FormularioEvaluacionEmpleadoE();

                        eval.CODIGO = reader.GetInt32(0);
                        eval.NOMBRE = reader.GetString(1);
                        eval.ROL= reader.GetString(2);

                        listEv.Add(eval);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listEv;
        }


    }
}
