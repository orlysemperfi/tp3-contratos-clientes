﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Negocio.GD
{
    public interface IFormularioEvaluacionEmpleadoBL
    {
        System.Collections.Generic.List<Entidades.GD.FormularioEvaluacionEmpleadoE> listAll();
    }
}
