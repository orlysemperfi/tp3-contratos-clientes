﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.GD;
using Entidades.GD;

namespace Negocio.GD
{
    public class FormularioEvaluacionEmpleadoBL : Negocio.GD.IFormularioEvaluacionEmpleadoBL
    {
        private IFormularioEvaluacionEmpleadoDAO forev = new FormularioEvaluacionEmpleadoDAO();

        public List<FormularioEvaluacionEmpleadoE> listAll()
        {
            return forev.listAll();
        }
    }
}
