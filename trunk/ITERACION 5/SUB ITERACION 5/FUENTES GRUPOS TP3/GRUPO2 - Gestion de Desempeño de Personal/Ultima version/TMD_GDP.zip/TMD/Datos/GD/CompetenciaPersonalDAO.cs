﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.GD;
using System.Data.SqlClient;
using Datos.GEN;
using System.Data;
namespace Datos.GD
{
    public class CompetenciaPersonalDAO : ICompetenciaPersonalDAO
    {


        public Int32 EliminarCompetencia(Int32 pidCompetencia)
        {
            ConexionDAO cn = new ConexionDAO();
            Int32 vresult = 0;

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_COMPETENCIA_INDICADOR_DETALLE_DEL", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_COMP_IND_DETALLE", pidCompetencia));

                    vresult = Convert.ToInt32(cmd.ExecuteNonQuery());

                    cmd.Dispose();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }

            return vresult;
        }



        public void IngresaCompetencia(Int32 competencia_indicador,Int32 tipo_calificacion,string descripcion,string nivel1,string nivel2,string nivel3,string nivel4,string nivel5)
        {

            ConexionDAO cn = new ConexionDAO();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_COMPETENCIA_INDICADOR_DETALLE_INS", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_COMPETENCIA_INDICADOR", competencia_indicador));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_TIPO_CALIFICACION_EVALUACION", tipo_calificacion));
                    cmd.Parameters.Add(new SqlParameter("@DESCRIPCION", descripcion));
                    cmd.Parameters.Add(new SqlParameter("@NIVEL_1", nivel1));
                    cmd.Parameters.Add(new SqlParameter("@NIVEL_2", nivel2));
                    cmd.Parameters.Add(new SqlParameter("@NIVEL_3", nivel3));
                    cmd.Parameters.Add(new SqlParameter("@NIVEL_4", nivel4));
                    cmd.Parameters.Add(new SqlParameter("@NIVEL_5", nivel5));

                    int response = cmd.ExecuteNonQuery();

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }





        public void ActualizaCompetencia(Int32 competencia_detalle, Int32 competencia_indicador, Int32 tipo_calificacion, string descripcion, string nivel1, string nivel2, string nivel3, string nivel4, string nivel5)
        {

            ConexionDAO cn = new ConexionDAO();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_COMPETENCIA_INDICADOR_DETALLE_UPD", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_COMPETENCIA_INDICADOR_DETALLE", competencia_detalle));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_COMPETENCIA_INDICADOR", competencia_indicador));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_TIPO_CALIFICACION_EVALUACION", tipo_calificacion));
                    cmd.Parameters.Add(new SqlParameter("@DESCRIPCION", descripcion));
                    cmd.Parameters.Add(new SqlParameter("@NIVEL_1", nivel1));
                    cmd.Parameters.Add(new SqlParameter("@NIVEL_2", nivel2));
                    cmd.Parameters.Add(new SqlParameter("@NIVEL_3", nivel3));
                    cmd.Parameters.Add(new SqlParameter("@NIVEL_4", nivel4));
                    cmd.Parameters.Add(new SqlParameter("@NIVEL_5", nivel5));

                    int response = cmd.ExecuteNonQuery();

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }



        public List<CompetenciaPersonalE> listadoCompetencia()
        {
            ConexionDAO cn = new ConexionDAO();
            List<CompetenciaPersonalE> listEv = new List<CompetenciaPersonalE>();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_LISTADO_COMPETENCIAS", con);

                    cmd.CommandType = CommandType.StoredProcedure;
               
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        CompetenciaPersonalE eval = new CompetenciaPersonalE();

                        eval.CODIGO_COMPETENCIA_INDICADOR_DETALLE = reader.GetInt32(0);
                        eval.NOMBRE_COMPETENCIA = reader.GetString(1);
                        eval.TIPO_COMPETENCIA = reader.GetString(2);
                        eval.CODIGO_COMPETENCIA_INDICADOR = reader.GetInt32(3);
                       
                        listEv.Add(eval);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listEv;
        }

        public List<CompetenciaPersonalE> listadoCompetenciaIndicador()
        {
            ConexionDAO cn = new ConexionDAO();
            List<CompetenciaPersonalE> listEv = new List<CompetenciaPersonalE>();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_LISTADO_COMPETENCIA_INDICADOR", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        CompetenciaPersonalE eval = new CompetenciaPersonalE();

                        eval.CODIGO_TIPO_CALIFICACION_EVALUACION = reader.GetInt32(0);
                        eval.DESCRIPCION_COMPETENCIA = Convert.ToString(reader.GetInt32(0)) + "  -  " + reader.GetString(1) ;

                        listEv.Add(eval);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listEv;
        }




        public CompetenciaPersonalE getCompetenciaPersonal(Int32 codigo)
        {
            ConexionDAO cn = new ConexionDAO();
            CompetenciaPersonalE CPE = new CompetenciaPersonalE();

            using (SqlConnection con = new SqlConnection(cn.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("GD.USP_COMPETENCIA_INDICADOR_DETALLE_SEL", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_CID", codigo));

                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        CPE.CODIGO_COMPETENCIA_INDICADOR = reader.GetInt32(0);
                        CPE.CODIGO_TIPO_CALIFICACION_EVALUACION = reader.GetInt32(1);
                        CPE.DESCRIPCION_COMPETENCIA = reader.GetString(2);
                        CPE.NIVEL1 = reader.GetString(3);
                        CPE.NIVEL2 = reader.GetString(4);
                        CPE.NIVEL3 = reader.GetString(5);
                        CPE.NIVEL4 = reader.GetString(6);
                        CPE.NIVEL5 = reader.GetString(7);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return CPE;
        }





    }
}
