﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.GD
{
    public class FormularioEvaluacion
    {

        public string NOMBRE { get; set; }

    }
}
