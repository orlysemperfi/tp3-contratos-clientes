﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.GD;
using Datos.GD;

namespace Negocio.GD
{
    public interface ICompetenciaPersonalBL 
    {

        System.Collections.Generic.List<Entidades.GD.CompetenciaPersonalE> listadoCompetencia();

        System.Collections.Generic.List<Entidades.GD.CompetenciaPersonalE> listadoCompetenciaIndicador();

        Int32 EliminarCompetencia(Int32 idCompetencia);

        void IngresaCompetencia(Int32 competencia_indicador, Int32 tipo_calificacion, string descripcion, string nivel1, string nivel2, string nivel3, string nivel4, string nivel5);

        CompetenciaPersonalE getCompetenciaPersonal(Int32 codigo);

        void ActualizaCompetencia(Int32 competencia_detalle, Int32 competencia_indicador, Int32 tipo_calificacion, string descripcion, string nivel1, string nivel2, string nivel3, string nivel4, string nivel5);

    }
}
