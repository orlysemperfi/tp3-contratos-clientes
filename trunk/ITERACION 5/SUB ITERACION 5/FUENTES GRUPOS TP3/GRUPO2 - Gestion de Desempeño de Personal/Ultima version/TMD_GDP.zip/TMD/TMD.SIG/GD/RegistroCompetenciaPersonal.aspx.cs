﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.GD;
using Entidades.GD;
using TMD.SIG.Util;

namespace TMD.SIG.GD
{
    public partial class RegistroCompetenciaPersonal : System.Web.UI.Page
    {
        string msj;
        Int32 codigo;

        private ICompetenciaPersonalBL forev = new CompetenciaPersonalBL();
        private CompetenciaPersonalE cp;

        protected void Page_Load(object sender, EventArgs e)
        {



            if (!IsPostBack)
            {


                Int32 tipo;

                cbotipo.DataSource = forev.listadoCompetenciaIndicador();
                cbotipo.DataTextField = "DESCRIPCION_COMPETENCIA";
                cbotipo.DataBind();

                msj = Convert.ToString(Request.QueryString["codigo"]);
                codigo = Convert.ToInt32(msj);

                txtN1.Enabled = false;
                txtN2.Enabled = false;
                txtN3.Enabled = false;
                txtN4.Enabled = false;
                txtN5.Enabled = false;


                if (msj!=null)
                {

                    Label1.Visible = true;
                    TextBox1.Visible = true;

                    cp = new CompetenciaPersonalE();
                    cp = forev.getCompetenciaPersonal(codigo);

                    TextBox1.Text = msj;

                    txtnomcompetencia.Text = cp.DESCRIPCION_COMPETENCIA;

                    txtN1.Text = cp.NIVEL1;

                    if (txtN1.Text.Length == 0)
                    {
                        ckN1.Checked = false;
                        txtN1.Enabled = false;
                    }
                    else
                    {
                        ckN1.Checked = true;
                        txtN1.Enabled = true;
                    }
                    

                    txtN2.Text = cp.NIVEL2;

                    if (txtN2.Text.Length == 0)
                    {
                        ckN2.Checked = false;
                        txtN2.Enabled = false;
                    }
                    else
                    {
                        ckN2.Checked = true;
                        txtN2.Enabled = true;
                    }

                    txtN3.Text = cp.NIVEL3;

                    if (txtN3.Text.Length == 0)
                    {
                        ckN3.Checked = false;
                        txtN3.Enabled = false;
                    }
                    else
                    {
                        ckN3.Checked = true;
                        txtN3.Enabled = true;
                    }

                    txtN4.Text = cp.NIVEL4;

                    if (txtN4.Text.Length == 0)
                    {
                        ckN4.Checked = false;
                        txtN4.Enabled = false;
                    }
                    else
                    {
                        ckN4.Checked = true;
                        txtN4.Enabled = true;
                    }

                    txtN5.Text = cp.NIVEL5;

                    if (txtN5.Text.Length == 0)
                    {
                        ckN5.Checked = false;
                        txtN5.Enabled = false;
                    }
                    else
                    {
                        ckN5.Checked = true;
                        txtN5.Enabled = true;
                    }


                    for (int i = 0; i < cbotipo.Items.Count - 1; i++)
                    {
                        
                        tipo = Convert.ToInt32(cbotipo.Items[i].Text.Substring(0, 3).Trim());
                        if (cp.CODIGO_COMPETENCIA_INDICADOR==tipo)
                        {
                            cbotipo.SelectedIndex = i;
                        }
                    }

                }
            }

        }

        protected void bntGrabar_Click(object sender, EventArgs e)
        {
            Int32 count = 0;
            CompetenciaPersonalE personal = new CompetenciaPersonalE();
            personal.CODIGO_COMPETENCIA_INDICADOR = Convert.ToInt32(cbotipo.SelectedValue.ToString().Substring(0, 3).Trim());

            if (txtnomcompetencia.Text.Trim().Length == 0)
            {
                ClientMessageBox.Show("Debe se digitar un nombre para la competencia", this);
                return;
            }
            
            personal.DESCRIPCION_COMPETENCIA = txtnomcompetencia.Text;

            if (ckN1.Checked)
            {
                if (txtN1.Text.Trim().Length == 0)
                {
                    ClientMessageBox.Show("Debe digitar una descripción al nivel 1", this);
                    return;
                }

                personal.NIVEL1 = txtN1.Text.Trim();
                count += 1;
            }
            else 
            {
                personal.NIVEL1 = "";
            }


            if (ckN2.Checked)
            {
                if (txtN2.Text.Trim().Length == 0)
                {
                    ClientMessageBox.Show("Debe digitar una descripción al nivel 2", this);
                    return;
                }

                personal.NIVEL2 = txtN2.Text.Trim();
                count += 1;
            }
            else
            {
                personal.NIVEL2 = "";
            }

            if (ckN3.Checked)
            {
                if (txtN3.Text.Trim().Length == 0)
                {
                    ClientMessageBox.Show("Debe digitar una descripción al nivel 3", this);
                    return;
                }


                personal.NIVEL3 = txtN3.Text.Trim();
                count += 1;
            }
            else
            {
                personal.NIVEL3 = "";
            }


            if (ckN4.Checked)
            {
                if (txtN4.Text.Trim().Length == 0)
                {
                    ClientMessageBox.Show("Debe digitar una descripción al nivel 4", this);
                    return;
                }

                personal.NIVEL4 = txtN4.Text.Trim();
                count += 1;
            }
            else
            {
                personal.NIVEL4 = "";
            }


            if (ckN5.Checked)
            {
                if (txtN5.Text.Trim().Length == 0)
                {
                    ClientMessageBox.Show("Debe digitar una descripción al nivel 5", this);
                    return;
                }

                personal.NIVEL5 = txtN5.Text.Trim();
                count += 1;
            }
            else
            {
                personal.NIVEL5 = "";
            }



            if (count == 0 || count<2)
            {
                ClientMessageBox.Show("Debe de marcar como minimo dos niveles", this);
                return;
            }


            if (TextBox1.Text.Length == 0)
            {
                forev.IngresaCompetencia(personal.CODIGO_COMPETENCIA_INDICADOR, 1, personal.DESCRIPCION_COMPETENCIA, personal.NIVEL1, personal.NIVEL2, personal.NIVEL3, personal.NIVEL4, personal.NIVEL5);
            }
            else
            {
                forev.ActualizaCompetencia(Convert.ToInt32(TextBox1.Text.Trim()), personal.CODIGO_COMPETENCIA_INDICADOR, 1, personal.DESCRIPCION_COMPETENCIA, personal.NIVEL1, personal.NIVEL2, personal.NIVEL3, personal.NIVEL4, personal.NIVEL5);
            }

            
            Response.Redirect("~/GD/ListadoCompetenciaPersonal.aspx");
        }

 

        protected void bntCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/GD/ListadoCompetenciaPersonal.aspx");
        }

        protected void ckN1_CheckedChanged(object sender, EventArgs e)
        {
            if (ckN1.Checked==true)
            {
                txtN1.Enabled = true;
            }
            else
            {
                txtN1.Enabled = false;
            }
            txtN1.Text = "";
        }

        protected void ckN2_CheckedChanged(object sender, EventArgs e)
        {
            if (ckN2.Checked == true)
            {
                txtN2.Enabled = true;
            }
            else
            {
                txtN2.Enabled = false;
            }
            txtN2.Text = "";
        }

        protected void ckN3_CheckedChanged(object sender, EventArgs e)
        {
            if (ckN3.Checked == true)
            {
                txtN3.Enabled = true;
            }
            else
            {
                txtN3.Enabled = false;
            }
            txtN3.Text = "";
        }

        protected void ckN4_CheckedChanged(object sender, EventArgs e)
        {
            if (ckN4.Checked == true)
            {
                txtN4.Enabled = true;
            }
            else
            {
                txtN4.Enabled = false;
            }
            txtN4.Text = "";
        }

        protected void ckN5_CheckedChanged(object sender, EventArgs e)
        {
            if (ckN5.Checked == true)
            {
                txtN5.Enabled = true;
            }
            else
            {
                txtN5.Enabled = false;
            }
            txtN5.Text = "";
        }
        

   

   
    }
}