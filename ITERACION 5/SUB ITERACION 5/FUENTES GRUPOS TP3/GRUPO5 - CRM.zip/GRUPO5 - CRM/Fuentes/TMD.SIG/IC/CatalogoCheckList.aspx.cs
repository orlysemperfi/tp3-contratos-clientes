﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMD.SIG.IC
{
    public partial class CatalogoCheckList : System.Web.UI.Page
    {
        Entidades.IC.CatalagoChecklistE oCatalogoE = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
                gvListarCatalaogo.DataBind();
        }

        protected void btbBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                gvListarCatalaogo.DataBind();
            }
            catch (Exception ex)
            {
                
            }
        }

        protected void odsCatalagos_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
        {
            oCatalogoE = new Entidades.IC.CatalagoChecklistE();
            if (!Page.IsPostBack)
                oCatalogoE.Nombre = "0";
            else
                oCatalogoE.Nombre = string.IsNullOrEmpty(txtBusqueda.Text) ? "O" : txtBusqueda.Text.Trim();
            e.InputParameters["o"]= oCatalogoE;
        }

    }
}