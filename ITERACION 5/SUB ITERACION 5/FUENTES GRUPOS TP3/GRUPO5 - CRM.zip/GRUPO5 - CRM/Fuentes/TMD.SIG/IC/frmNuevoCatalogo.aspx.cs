﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;

namespace TMD.SIG.IC
{
    public partial class frmNuevoCatalogo : System.Web.UI.Page
    {
        CatalagoChecklistE oCatalogoE=null;
        CatalogoCheckListBL oCatalogoBL = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            listar();
        }

        protected void btnGrabar_Click(object sender, EventArgs e)
        {
            oCatalogoE = new CatalagoChecklistE();
            oCatalogoBL = new CatalogoCheckListBL();
            try
            {
                oCatalogoE.Nombre = txtNombre.Text.Trim() ;
                oCatalogoE.Descripcion = txtDescripcion.Text.Trim();
                oCatalogoE.Version = txtVersion.Text.Trim();
                oCatalogoE.Prioridad = ddlPrioridad.SelectedValue;

                //implementando logica de negocio
                oCatalogoBL.insertar(oCatalogoE);

                listar();
                limpiarCasillas();
            }
            catch (Exception ex)
            {
                lblMensaje.Text = ex.Message;
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            oCatalogoE = new CatalagoChecklistE();
            oCatalogoBL = new CatalogoCheckListBL();
            try
            {
                //oCatalogoE.Codigo = txtNombre.Text.Trim();

                //implementando logica de negocio
                oCatalogoBL.Eliminar(oCatalogoE);
            }
            catch (Exception ex)
            {
                lblMensaje.Text = ex.Message;
            }
        }

        public void listar()
        {
            oCatalogoBL = new CatalogoCheckListBL();

            GridView1.AutoGenerateColumns = false;
            GridView1.DataSource = oCatalogoBL.listAll();

            GridView1.DataBind();

        }

        public void limpiarCasillas()
        {
            txtNombre.Text = "";
            txtDescripcion.Text = "";
            txtVersion.Text = "";
        }

       
    }
}