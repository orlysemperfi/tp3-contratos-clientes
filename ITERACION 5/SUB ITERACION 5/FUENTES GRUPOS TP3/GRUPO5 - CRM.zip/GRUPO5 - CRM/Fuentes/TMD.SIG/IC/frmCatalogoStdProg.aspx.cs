﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;
using Negocio.IC;

namespace TMD.SIG.IC
{
    public partial class frmCatalogoStdProg : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack ) {
                dsCatalogo.DataBind();
            }
        }

        protected void btnNuevo_Click(object sender, EventArgs e)
        {

        }

        /*
        void listar() {
            lista = new List<EstandaresE>();
            oEstandarBL = new EstandarBL();
            try
            {

               
                //implementando logica de negocio
                lista = oEstandarBL.listAll();

              gvLsProgram.DataSource = lista;
              gvLsProgram.DataBind();

            }
            catch (Exception ex)
            {
                lblMensaje.Text = ex.Message;
            }
        }

      */
    }
}