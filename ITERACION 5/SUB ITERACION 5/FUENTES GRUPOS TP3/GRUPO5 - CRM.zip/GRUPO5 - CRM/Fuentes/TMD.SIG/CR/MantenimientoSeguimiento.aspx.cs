﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Negocio.CR;
using Entidades.CR;

namespace TMD.SIG.CR
{
    public partial class MantenimientoSeguimiento : System.Web.UI.Page
    {
        IMantenimientoSeguimientoBL iMantenimientoSeguimientoBL = new MantenimientoSeguimientoBL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                DataTable dt = new DataTable();

                CampanaCaptacionE campanaCaptacionE = new CampanaCaptacionE();
                campanaCaptacionE.estado = "A";

                dt = iMantenimientoSeguimientoBL.ConsultarCampana_Captacion_Estado(campanaCaptacionE).Tables[0];

                if (dt.Rows.Count > 0)
                {
                    ddlCampaña.DataSource = dt;
                    ddlCampaña.DataTextField = "NOMBRE";
                    ddlCampaña.DataValueField = "CODIGO_CAMPANA_CAPTACION";
                    ddlCampaña.DataBind();
                }
                else 
                {
                    lblEstadoGrabar.Text = "No se encontraron campañas Activas";
                    lblEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");
                }

                
            }
        }

        protected void lnkItemSegumiento_Click(object sender, EventArgs e)
        {
            Button1_ModalPopupExtender.Show();

        }
        
        protected void btnVerMiembros_Click(object sender, EventArgs e)
        {
            if (ddlCampaña.Items.Count > 0)
            {
                DataTable dt = new DataTable();

                int idCampana = Convert.ToInt32(ddlCampaña.SelectedValue.ToString());

                dt = iMantenimientoSeguimientoBL.ConsultarSegumiento_PorCampana_Captacion(idCampana).Tables[0];

                txtListaMarketing.Text = dt.Rows[0][10].ToString();

                grdSeguimiento.DataSource = dt;
                grdSeguimiento.DataBind();

                dt = iMantenimientoSeguimientoBL.BuscaCampana_Captacion(Convert.ToInt32(idCampana)).Tables[0];

                Session["idCampana"] = idCampana;

                String estado = "";

                switch (dt.Rows[0][7].ToString())
                {
                    case "CREADA":
                        estado = "C";
                        break;
                    case "ACTIVA":
                        estado = "A";
                        break;
                    case "CERRADA":
                        estado = "E";
                        break;
                    case "AUTORIZADA":
                        estado = "U";
                        break;
                    default:
                        estado = "R";
                        break;
                }

                Session["estadoCampana"] = estado;
                Session["fechaInicioCampana"] = dt.Rows[0][2].ToString();
                Session["fechaFinCampana"] = dt.Rows[0][3].ToString();

                lblEstadoGrabar.Text = grdSeguimiento.Rows.Count.ToString() + " resultado(s) encontrado(s). Estado de campaña : " + dt.Rows[0][7].ToString();
                lblEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");
            }
            else 
            {
                lblEstadoGrabar.Text = "No se encontraron campañas Activas";
                lblEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");
            }
        }

        protected void grdSegumiento_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            String[] argumentos = null;
           
            if (e == null)
            {
                argumentos = (String[])Session["argumentos"];
            }
            else
            {
                argumentos = e.CommandArgument.ToString().Split(',');
                Session["argumentos"] = argumentos;
            }

            txtNombre.Text = argumentos[1];
            txtRazonSocial.Text = argumentos[2];
            
            int idContacto= Convert.ToInt32(argumentos[0]);
            lblAuxIdContacto.Text = argumentos[0];
            lblAuxCodigoLm.Text = argumentos[3];
            lblAuxCodigoCampanaCaptacion.Text = argumentos[4];

            SeguimientoE seguimientoE = new SeguimientoE();

            seguimientoE.codigo_oventa = int.Parse(argumentos[0].ToString());
            seguimientoE.codigo_lm = int.Parse(argumentos[3].ToString());
            seguimientoE.codigo_campana_captacion = int.Parse(argumentos[4].ToString());

            DataTable dt = new DataTable();
            dt = iMantenimientoSeguimientoBL.ConsultarSegumiento_PorContacto(seguimientoE).Tables[0];
       
            grdContactos.DataSource = dt;
            grdContactos.DataBind();

            String estadoCampana = (String)Session["estadoCampana"];

            btnIngresar.Visible = estadoCampana.Equals("A");
            
            lblContactosEstadoGrabar.Text = grdContactos.Rows.Count.ToString() + " resultado(s) encontrado(s)";
            lblContactosEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");
        }

        protected void grdContactos_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            lblSegTitulo.Text = "Modificar Seguimiento";
            btnSegIngresar.Visible = false;
            btnSegModificar.Visible = true;

            String idSeguimiento = e.CommandArgument.ToString();
            lblAuxIdSeguimiento.Text = idSeguimiento;

            DataTable dt = new DataTable();
            dt = iMantenimientoSeguimientoBL.buscaSeguimiento(Convert.ToInt32(idSeguimiento)).Tables[0];

            ddlCanal.SelectedValue =dt.Rows[0][1].ToString();
            txtSegCostoReal.Text = dt.Rows[0][2].ToString();

            DateTime fecContacto = DateTime.ParseExact(dt.Rows[0][3].ToString(), "dd/MM/yyyy", System.Globalization.CultureInfo.CurrentCulture);
            txtSegFechaContacto.Text = fecContacto.ToString("yyyy-MM-dd");

            String estado = "";

            switch (dt.Rows[0][4].ToString())
            {
                case "EN PROGRESO":
                    estado = "E";
                    break;
                case "PLANIFICADO":
                    estado = "P";
                    break;
                case "FINALIZADO":
                    estado = "F";
                    break;
                default:
                    estado = "C";
                    break;
            }

            ddlSegEstado.SelectedValue = estado;
            txtSegObservaciones.Text = dt.Rows[0][5].ToString() ;

            String estadoCampana = (String)Session["estadoCampana"];

            Session["estadoSeguimiento"] = estado;
            String estadoSeguimineto = (String)Session["estadoSeguimiento"];


            if (estadoCampana.Equals("A"))
            {
                btnSegIngresar.Visible = false;
                btnSegModificar.Visible = true;
                ddlCanal.Enabled = false;
                txtSegCostoReal.Enabled = true;
                txtSegFechaContacto.Enabled = true;
                ddlSegEstado.Enabled = true;
                txtSegObservaciones.Enabled = true;
            }
            else
            { 
                btnSegIngresar.Visible = false;
                btnSegModificar.Visible = false;
                ddlCanal.Enabled = false;
                txtSegCostoReal.Enabled = false;
                txtSegFechaContacto.Enabled = false;
                ddlSegEstado.Enabled = false;
                txtSegObservaciones.Enabled = false;
                lblSegTitulo.Text = "Ver Seguimiento";
            }

            lblSegMensaje.Text = "";
        }

        protected void btnSegSalir_Click(object sender, EventArgs e)
        {
            Button1_ModalPopupExtender.Show();
        }

        protected void btnIngresar_Click(object sender, EventArgs e)
        {
            lblSegTitulo.Text = "Ingresar Seguimiento";
            btnSegIngresar.Visible = true;
            btnSegModificar.Visible = false;


            ddlCanal.SelectedIndex =0;
            txtSegCostoReal.Text = "";
            txtSegFechaContacto.Text = "";
            txtSegObservaciones.Text = "";
            ddlCanal.Enabled = true;
            txtSegCostoReal.Enabled = true;
            txtSegFechaContacto.Enabled = true;
            ddlSegEstado.Enabled = true;
            txtSegObservaciones.Enabled = true;

            lblSegMensaje.Text = "";
            Button2_ModalPopupExtender.Show();
        }

        protected void lnkItemContacto_Click(object sender, EventArgs e)
        {
            Button2_ModalPopupExtender.Show();
        }

        protected void btnSegIngresar_Click(object sender, EventArgs e)
        {

            String cadena = "Los campos ";
            bool valida = false;

            if (ddlCanal.SelectedValue.ToString().Equals("-"))
            {
                cadena += "Canal, ";
                valida = true;
            }

            if (txtSegFechaContacto.Text.Trim().Length == 0)
            {
                cadena += "Fecha de contacto,";
                valida = true;
            }
            if (txtSegCostoReal.Text.Trim().Length == 0)
            {
                cadena += "Costo,";
                valida = true;
            }
            if (ddlSegEstado.SelectedValue.ToString().Equals("-"))
            {
                cadena += "Estado, ";
                valida = true;
            }
            if (valida)
            {
                lblSegMensaje.Text = cadena + " son requeridos";
                lblSegMensaje.ForeColor = System.Drawing.Color.Red;
                Button2_ModalPopupExtender.Show();
                return;
            }

            try
            {
                DateTime fecInicio = DateTime.ParseExact(txtSegFechaContacto.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);
            }
            catch (Exception ex)
            {
                lblSegMensaje.Text = "La fecha tiene formato yyyy-MM-dd " + ex;
                lblSegMensaje.ForeColor = System.Drawing.Color.Red;
                Button2_ModalPopupExtender.Show();
                return;
            }

            try
            {
                double.Parse(txtSegCostoReal.Text);
            }
            catch (Exception ex)
            {
                lblSegMensaje.Text = "El costo debe ser real " + ex;
                lblSegMensaje.ForeColor = System.Drawing.Color.Red;
                Button2_ModalPopupExtender.Show();
                return;
            }

            String  strfecInicioCam =(String) Session["fechaInicioCampana"];
            String  strFinCamp =(String) Session["fechaFinCampana"];

            DateTime fecInicioCam = DateTime.ParseExact(strfecInicioCam, "dd/MM/yyyy", System.Globalization.CultureInfo.CurrentCulture);
            DateTime fecFinCamp = DateTime.ParseExact(strFinCamp, "dd/MM/yyyy", System.Globalization.CultureInfo.CurrentCulture);
            DateTime fecRegistro = DateTime.ParseExact(txtSegFechaContacto.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);
            DateTime fecActual = DateTime.Now;

            TimeSpan restInicioActual = fecRegistro - fecInicioCam;
            TimeSpan restFinActual = fecRegistro - fecFinCamp;
            if (restInicioActual.TotalDays <= 0 || restFinActual.TotalDays > 0)
            {

                lblSegMensaje.Text = " La fecha de seguimiento debe estar entre el inicio y el fin de campaña : " + strfecInicioCam + " y " + strFinCamp;
                lblSegMensaje.ForeColor = System.Drawing.Color.Red;
                Button2_ModalPopupExtender.Show();
                return;
            }

            TimeSpan resProgreso = fecRegistro - fecActual;

            if (ddlSegEstado.SelectedValue.ToString().Equals("E") && resProgreso.TotalDays>0)
            {

                lblSegMensaje.Text = "Para el estado 'En progreso' la fecha del seguimiento debe ser menor o igual a la fecha actual";
                lblSegMensaje.ForeColor = System.Drawing.Color.Red;
                Button2_ModalPopupExtender.Show();
                return;
            }

            TimeSpan resPlanificado = fecActual - fecRegistro;

            if (ddlSegEstado.SelectedValue.ToString().Equals("P") && resPlanificado.TotalDays > 0)
            {

                lblSegMensaje.Text = "En estado 'planificado' la fecha del seguimiento es mayor o igual a la fecha actual";
                lblSegMensaje.ForeColor = System.Drawing.Color.Red;
                Button2_ModalPopupExtender.Show();
                return;
            }

            SeguimientoE obj = new SeguimientoE();
            obj.canal = ddlCanal.SelectedValue.ToString();
            obj.fechaContacto = txtSegFechaContacto.Text;

            obj.costoReal = double.Parse(txtSegCostoReal.Text);
            obj.estado = ddlSegEstado.SelectedValue.ToString();
            obj.observaciones = txtSegObservaciones.Text;

            obj.contactoId = int.Parse(lblAuxIdContacto.Text);
            obj.codigo_lm = int.Parse(lblAuxCodigoLm.Text);
            obj.codigo_campana_captacion = int.Parse(lblAuxCodigoCampanaCaptacion.Text);

            int idCampana = (int)Session["idCampana"];

            bool salida = iMantenimientoSeguimientoBL.InsertarSeguimiento(obj);
            bool salida2 = iMantenimientoSeguimientoBL.ModificarCostoCampana(idCampana);
                
            grdSegumiento_RowCommand(sender, null);
            Button1_ModalPopupExtender.Show();
        }

        protected void btnSegModificar_Click(object sender, EventArgs e)
        {
            String cadena = "Los campos ";
            bool valida = false;

            if (ddlCanal.SelectedValue.ToString().Equals("-"))
            {
                cadena += "Canal, ";
                valida = true;
            }

            if (txtSegFechaContacto.Text.Trim().Length == 0)
            {
                cadena += "Fecha de contacto,";
                valida = true;
            }

            if (txtSegCostoReal.Text.Trim().Length == 0)
            {
                cadena += "Costo,";
                valida = true;
            }

            if (ddlSegEstado.SelectedValue.ToString().Equals("-"))
            {
                cadena += "Estado, ";
                valida = true;
            }

            if (valida)
            {
                lblSegMensaje.Text = cadena + " son requeridos";
                lblSegMensaje.ForeColor = System.Drawing.Color.Red;
                Button2_ModalPopupExtender.Show();
                return;
            }

            try
            {
                DateTime fecInicio = DateTime.ParseExact(txtSegFechaContacto.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);
            }
            catch (Exception x)
            {
                lblSegMensaje.Text = "La fecha tiene formato yyyy-MM-dd";
                lblSegMensaje.ForeColor = System.Drawing.Color.Red;
                Button2_ModalPopupExtender.Show();
                return;
            }

            try
            {
                double.Parse(txtSegCostoReal.Text);
            }
            catch (Exception x)
            {
                lblSegMensaje.Text = "El costo debe ser real";
                lblSegMensaje.ForeColor = System.Drawing.Color.Red;
                Button2_ModalPopupExtender.Show();
                return;
            }

            String strfecInicioCam = (String)Session["fechaInicioCampana"];
            String strFinCamp = (String)Session["fechaFinCampana"];

            DateTime fecInicioCam = DateTime.ParseExact(strfecInicioCam, "dd/MM/yyyy", System.Globalization.CultureInfo.CurrentCulture);
            DateTime fecFinCamp = DateTime.ParseExact(strFinCamp, "dd/MM/yyyy", System.Globalization.CultureInfo.CurrentCulture);
            DateTime fecRegistro = DateTime.ParseExact(txtSegFechaContacto.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);

            TimeSpan restInicioActual = fecRegistro - fecInicioCam;
            TimeSpan restFinActual = fecRegistro - fecFinCamp;

            if (restInicioActual.TotalDays <= 0 || restFinActual.TotalDays > 0)
            {

                lblSegMensaje.Text = " La fecha de seguimiento debe estar entre : " + strfecInicioCam + " y " + strFinCamp;
                lblSegMensaje.ForeColor = System.Drawing.Color.Red;
                Button2_ModalPopupExtender.Show();
                return;
            }

            String estadoSeguimineto = (String)Session["estadoSeguimiento"];

            if (estadoSeguimineto.Equals("E") && ddlSegEstado.SelectedValue.ToString().Equals("P"))
            {

                lblSegMensaje.Text = "No se puede cambiar de 'En progreso' a 'Planificado'";
                lblSegMensaje.ForeColor = System.Drawing.Color.Red;
                Button2_ModalPopupExtender.Show();
                return;
            }

            SeguimientoE obj = new SeguimientoE();
            obj.canal = ddlCanal.SelectedValue.ToString();
            obj.fechaContacto = txtSegFechaContacto.Text;
            obj.costoReal = double.Parse(txtSegCostoReal.Text);
            obj.estado = ddlSegEstado.SelectedValue.ToString();
            obj.observaciones = txtSegObservaciones.Text;
            obj.segumientoId = Convert.ToInt32(lblAuxIdSeguimiento.Text);

            int idCampana = (int)Session["idCampana"];

            bool salida = iMantenimientoSeguimientoBL.ModificarSegumiento(obj);
            bool salida2 = iMantenimientoSeguimientoBL.ModificarCostoCampana(idCampana);

            grdSegumiento_RowCommand(sender, null);
            Button1_ModalPopupExtender.Show();
        }

        protected void btnSalirSeguimiento_Click(object sender, EventArgs e)
        {
            Button1_ModalPopupExtender.Show();
            Button2_ModalPopupExtender.Hide();
        }

        protected void ddlSegEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(ddlSegEstado.SelectedValue.ToString().Equals("C")){
                Session["memoria"] = txtSegCostoReal.Text;
                txtSegCostoReal.Text = "0.0";
                txtSegCostoReal.Enabled = false;
            }else
            {
                if (Session["memoria"] != null) {
                    txtSegCostoReal.Text = (String)Session["memoria"];
                }
                txtSegCostoReal.Enabled = true;
            }
            Button2_ModalPopupExtender.Show();
        }
    }
}
