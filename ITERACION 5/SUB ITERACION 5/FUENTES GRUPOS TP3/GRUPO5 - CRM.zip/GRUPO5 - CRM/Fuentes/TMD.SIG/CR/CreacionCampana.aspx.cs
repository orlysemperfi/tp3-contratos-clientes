﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Negocio.CR;
using Entidades.CR;

namespace TMD.SIG.CR
{
    public partial class CreacionCampana : System.Web.UI.Page
    {
        ICreacionCampanaBL iCreacionCampanaBL = new CreacionCampanaBL();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ddlListaMarketing.DataSource = iCreacionCampanaBL.ObtenerListaMarketing();
                ddlListaMarketing.DataTextField = "nombre";
                ddlListaMarketing.DataValueField = "listaMarketingId";
                ddlListaMarketing.DataBind();
            }
        }

        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            try
            {
                String cadena = "Los campos ";
                bool valida = false;

                if (txtPopNombreCampaña.Text.Trim().Length == 0)
                {
                    cadena += "Nombre de campaña, ";
                    valida = true;
                }
                if (txtPopFecInicio.Text.Trim().Length == 0)
                {
                    cadena += "Fecha de Inicio, ";
                    valida = true;
                }
                if (txtPopFecFin.Text.Trim().Length == 0)
                {
                    cadena += "Fecha de Fin, ";
                    valida = true;
                }
                if (txtPopPresupuestoPlanificado.Text.Trim().Length == 0)
                {
                    cadena += "Presupuesto planificado, ";
                    valida = true;
                }
                if (txtPopObjetivos.Text.Trim().Length == 0)
                {
                    cadena += "Objetivos, ";
                    valida = true;
                }
                if (txtPopObservaciones.Text.Trim().Length == 0)
                {
                    cadena += "Observaciones, ";
                    valida = true;
                }
                if (valida)
                {
                    lblEstadoPopup.Text = cadena + " son requeridos";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    return;
                }

                if ((txtPopFecInicio.Text.Trim().Length == 0 && txtPopFecFin.Text.Trim().Length != 0) || (txtPopFecInicio.Text.Trim().Length != 0 && txtPopFecFin.Text.Trim().Length == 0))
                {
                    lblEstadoPopup.Text = " La fecha de inicio y/o fin debe completada";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    return;
                }

                DateTime fecInicio = DateTime.ParseExact(txtPopFecInicio.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);
                DateTime fecFin = DateTime.ParseExact(txtPopFecFin.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);
                DateTime fecActual = DateTime.Now;

                TimeSpan restInicioActual = fecActual - fecInicio;
                TimeSpan restFinActual = fecActual - fecFin;
                if (restInicioActual.TotalDays >= 0 || restFinActual.TotalDays >= 0)
                {

                    lblEstadoPopup.Text = " La fecha de inicio y fecha fin deben ser mayores que la fecha actual";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    return;
                }

                TimeSpan restFecha = fecInicio - fecFin;
                if (restFecha.TotalDays > 0)
                {
                    lblEstadoPopup.Text = " La fecha fin debe ser mayor que la fecha de inicio";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    return;
                }


                CampanaCaptacionE obj = new CampanaCaptacionE();
                obj.nombre = txtPopNombreCampaña.Text;
                obj.fechaInicio = txtPopFecInicio.Text;
                obj.fechaFin = txtPopFecFin.Text;
                obj.objetivos = txtPopObjetivos.Text;
                obj.presupuestoPlanificado = double.Parse(txtPopPresupuestoPlanificado.Text);
                obj.observaciones = txtPopObservaciones.Text;
                obj.listaMarketing = Convert.ToInt32(ddlListaMarketing.SelectedValue.ToString());


                bool salida = iCreacionCampanaBL.InsertarCampana_Captacion(obj);
                if (salida)
                {
                    txtPopNombreCampaña.Text = "";
                    txtPopFecInicio.Text = "";
                    txtPopFecFin.Text = "";
                    txtPopObjetivos.Text = "";
                    txtPopPresupuestoPlanificado.Text = "";
                    txtPopObservaciones.Text = "";
                    ddlListaMarketing.SelectedIndex = 0;

                    lblEstadoPopup.Text = "";

                    lblEstadoGrabar.Text = "Se registro correctamente";
                    lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
                }
                else
                {
                    lblEstadoGrabar.Text = "No se registro correctamente";
                    lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
                }

            }
            catch (Exception ex)
            {
                lblEstadoGrabar.Text = " " + ex.Message;
                lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
            }        
        }
    }
}