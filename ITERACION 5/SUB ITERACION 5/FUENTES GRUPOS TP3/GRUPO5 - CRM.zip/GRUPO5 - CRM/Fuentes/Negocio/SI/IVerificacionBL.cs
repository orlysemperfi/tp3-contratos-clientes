﻿using System;
namespace Negocio.SI
{
    public interface IVerificacionBL
    {
        System.Collections.Generic.List<Entidades.SI.ControlE> getListaControles(int codPolitica);
        System.Collections.Generic.List<Entidades.SI.PoliticaE> getListaPoliticas();
        System.Collections.Generic.List<Entidades.SI.VerificacionE> getListaVerificacion(int codControl, string fechaDesde, string fechaHasta);
        Entidades.SI.ResponsableControlE getResponsableControl(int codResponsable);
        int registrarVerificacion(Entidades.SI.VerificacionE o);
    }
}
