﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.SI;
using Datos.SI;

namespace Negocio.SI
{
    public class VerificacionBL : Negocio.SI.IVerificacionBL
    {
        private IVerificacionControlDAO verifcacionDao = new VerificacionControlDAO();
 

        public List<ControlE> getListaControles(int codPolitica)
        {
            return verifcacionDao.getListaControles(codPolitica);
        }

        public List<PoliticaE> getListaPoliticas()
        {
            return verifcacionDao.getListaPoliticas();
        }

        public List<VerificacionE> getListaVerificacion(int codControl, string fechaDesde, string fechaHasta)
        {
            return verifcacionDao.getListaVerificacion(codControl,fechaDesde,fechaHasta);
        }

        public ResponsableControlE getResponsableControl(int codResponsable)
        {
            return verifcacionDao.getResponsableControl(codResponsable);
        }

        public int registrarVerificacion(VerificacionE o)
        {
            return verifcacionDao.registrarVerificacion(o);
        }

    }
}
