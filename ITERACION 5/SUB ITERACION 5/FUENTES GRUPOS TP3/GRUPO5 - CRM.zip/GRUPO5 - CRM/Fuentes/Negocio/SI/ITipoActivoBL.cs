﻿using System;
namespace Negocio.SI
{
    public interface ITipoActivoBL
    {
        void insertar(Entidades.SI.TipoActivoE o);
    }
}
