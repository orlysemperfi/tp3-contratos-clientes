﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;

namespace Negocio.IC
{

    public interface ICatalogoPBL
    {
        int insertar(CatalagoPrioridadE o);
        List<CatalagoPrioridadE> ListAll();
        int modificar(CatalagoPrioridadE o);
        int aprobar(CatalagoPrioridadE o);
        List<CatalagoPrioridadE> buscar(String nombre);
        int eliminar(CatalagoPrioridadE o);
    }
}
