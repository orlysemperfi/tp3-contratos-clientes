﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.IC;

namespace Negocio.IC
{
    public class CatalogoCheckListBL : ICatalogoCheckListBL
    {
        CatalogoDAO oCatalogDAO = null;
        public void insertar(Entidades.IC.CatalagoChecklistE o)
        {
            oCatalogDAO = new CatalogoDAO();
            oCatalogDAO.Insert(o);
        }

        public List<Entidades.IC.CatalagoChecklistE> listAll()
        {
            return null;
        }

        public List<Entidades.IC.CatalagoChecklistE> listAll(Entidades.IC.CatalagoChecklistE o)
        {
            oCatalogDAO = new CatalogoDAO();
            return oCatalogDAO.ListAll(o); 
        }

        public List<Entidades.IC.CatalagoChecklistE> ListGrilla(Entidades.IC.CatalagoChecklistE oCatalogoe)
        {
            oCatalogDAO= new CatalogoDAO();
            return oCatalogDAO.ListCatalogoNombre(oCatalogoe);
        }

        public int Eliminar(Entidades.IC.CatalagoChecklistE o)
        {
            oCatalogDAO = new CatalogoDAO();   
            return oCatalogDAO.Eliminar(o);
        }
    }
}
