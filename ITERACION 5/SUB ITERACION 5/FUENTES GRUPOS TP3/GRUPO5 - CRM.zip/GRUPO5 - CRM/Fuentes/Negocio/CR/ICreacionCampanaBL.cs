﻿using System;
using Entidades.CR;
using System.Collections.Generic;

namespace Negocio.CR
{
    public interface ICreacionCampanaBL
    {
        bool InsertarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);

        List<ListaMarketingE> ObtenerListaMarketing();
    }
}
