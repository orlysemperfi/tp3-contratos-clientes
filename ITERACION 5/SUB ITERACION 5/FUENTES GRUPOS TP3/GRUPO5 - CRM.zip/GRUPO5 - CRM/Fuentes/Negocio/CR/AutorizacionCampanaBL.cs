﻿using System;
using System.Collections.Generic;
using System.Linq;
using Entidades.CR;
using Datos.CR;
using System.Text;
using System.Data;

namespace Negocio.CR
{
    public class AutorizacionCampanaBL : IAutorizacionCampanaBL
    {
        ICampanaCaptacionDAO iCampanaCaptacionDAO = new CampanaCaptacionDAO();
        IListaMarketingDAO iListaMarketingDAO = new ListaMarketingDAO();
        IPersonaDAO iPersonaDAO = new PersonaDAO();
        
        public List<PersonaE> ObtenerAsesores()
        {
            return iPersonaDAO.ObtenerAsesores();
        }

        public bool AutorizarCampana_Captacion(CampanaCaptacionE campanaCaptacionE)
        {
            return iCampanaCaptacionDAO.AutorizarCampana_Captacion(campanaCaptacionE);
        }

        public bool RechazarCampana_Captacion(CampanaCaptacionE campanaCaptacionE)
        {
            return iCampanaCaptacionDAO.RechazarCampana_Captacion(campanaCaptacionE);
        }

        public DataSet ConsultarCampana_Captacion_Estado(CampanaCaptacionE campanaCaptacionE) 
        {
            return iCampanaCaptacionDAO.ConsultarCampana_Captacion_Estado(campanaCaptacionE);
        }

        public List<ListaMarketingE> ObtenerListaMarketing() 
        {
            return iListaMarketingDAO.ObtenerListaMarketing();
        }

        public DataSet BuscaCampana_Captacion(int campanaCaptacionId) 
        {
            return iCampanaCaptacionDAO.BuscaCampana_Captacion(campanaCaptacionId);
        }
    }
}
