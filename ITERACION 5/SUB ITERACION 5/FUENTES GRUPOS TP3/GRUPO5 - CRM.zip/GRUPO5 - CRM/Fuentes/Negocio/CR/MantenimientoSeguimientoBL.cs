﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.CR;
using Entidades.CR;
using System.Data;

namespace Negocio.CR
{
    public class MantenimientoSeguimientoBL : IMantenimientoSeguimientoBL
    {
        ICampanaCaptacionDAO iCampanaCaptacionDAO = new CampanaCaptacionDAO();
        ISeguimientoDAO iSeguimientoDAO = new SeguimientoDAO();
        IContactoDAO iContactoDAO = new ContactoDAO();

        public DataSet ConsultarSegumiento_PorContacto(SeguimientoE seguimientoE)
        {
            return iSeguimientoDAO.ConsultarSegumiento_PorContacto(seguimientoE);
        }

        public DataSet buscaSeguimiento(int seguimientoId)
        {
            return iSeguimientoDAO.buscaSeguimiento(seguimientoId);
        }

        public bool InsertarSeguimiento(SeguimientoE seguimientoE) 
        {
            return iSeguimientoDAO.InsertarSeguimiento(seguimientoE);
        }

        public bool ModificarSegumiento(SeguimientoE seguimientoE)
        {
            return iSeguimientoDAO.ModificarSegumiento(seguimientoE);
        }

        public DataSet BuscaCampana_Captacion(int campanaCaptacionId)
        {
            return iCampanaCaptacionDAO.BuscaCampana_Captacion(campanaCaptacionId);
        }

        public bool ModificarCostoCampana(CampanaCaptacionE campanaCaptacionE)
        {
            return iCampanaCaptacionDAO.ModificarCampana_Captacion(campanaCaptacionE);
        }

        public bool ModificarCostoCampana(int idCampana) 
        {
            return iCampanaCaptacionDAO.ModificarCostoCampana(idCampana);
        }

        public DataSet ConsultarSegumiento_PorCampana_Captacion(int campanaCaptacionId)
        {
            return iContactoDAO.ConsultarContacto_PorCampana_Captacion(campanaCaptacionId);
        }

        public DataSet ConsultarCampana_Captacion(CampanaCaptacionE campanaCaptacionE) 
        {
            return iCampanaCaptacionDAO.ConsultarCampana_Captacion(campanaCaptacionE);
        }

        public DataSet ConsultarCampana_Captacion_Estado(CampanaCaptacionE campanaCaptacionE) 
        {
            return iCampanaCaptacionDAO.ConsultarCampana_Captacion_Estado(campanaCaptacionE);
        }
    }
}
