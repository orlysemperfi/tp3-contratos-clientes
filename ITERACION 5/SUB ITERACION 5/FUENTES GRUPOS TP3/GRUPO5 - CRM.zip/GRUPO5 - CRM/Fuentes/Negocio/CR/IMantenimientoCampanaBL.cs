﻿using System;
using System.Data;
using Entidades.CR;
using System.Collections.Generic;

namespace Negocio.CR
{
    public interface IMantenimientoCampanaBL
    {
        DataSet ConsultarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);

        bool ModificarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);

        DataSet BuscaCampana_Captacion(int campanaCaptacionId);

        List<ListaMarketingE> ObtenerListaMarketing();

    }
}
