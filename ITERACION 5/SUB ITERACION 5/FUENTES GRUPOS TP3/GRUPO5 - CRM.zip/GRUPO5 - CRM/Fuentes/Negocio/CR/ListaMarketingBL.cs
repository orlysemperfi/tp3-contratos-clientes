﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Entidades.CR;
using Datos.CR;
using Negocio.CR;

namespace Negocio.CR
{
    public class ListaMarketingBL : IListaMarketingBL
    {
        IListaMarketingDAO iListaMarketingDAO = new ListaMarketingDAO();
        ICampanaCaptacionDAO iCampanaCaptacionDAO = new CampanaCaptacionDAO();
        
        public DataSet ConsultarLista_de_Marketing(ListaMarketingE listaMarketingE)
        {
            return iListaMarketingDAO.ConsultarLista_de_Marketing(listaMarketingE);
        }

        public int InsertarListaMarketing(List<ContactoE> lstContacto, ListaMarketingE listaMarketingE) 
        {
            return iListaMarketingDAO.InsertarListaMarketing(lstContacto, listaMarketingE);
        }

        public DataSet ConsultarCampana_Captacion(CampanaCaptacionE campanaCaptacionE) {
            return iCampanaCaptacionDAO.ConsultarCampana_Captacion(campanaCaptacionE);
        }

        public List<ListaMarketingE> ObtenerListaMarketing()
        {
            return iListaMarketingDAO.ObtenerListaMarketing();
        }

    }
}
