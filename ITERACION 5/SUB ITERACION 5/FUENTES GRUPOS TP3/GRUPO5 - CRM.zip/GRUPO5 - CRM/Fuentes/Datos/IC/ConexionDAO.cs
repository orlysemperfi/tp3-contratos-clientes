﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Datos.IC
{
    public static class CatalgoConexionDAO
    {
        public static string CadenaConexion()
        {
            /*La configuracion de la cadena de conexion esta en el Web.config de la capa TMD.SIG*/
            return ConfigurationManager.ConnectionStrings["cnxConn"].ConnectionString;
        }
    }
}
