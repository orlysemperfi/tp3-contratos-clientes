﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;

namespace Datos.IC
{
    public interface ICatalogoDAO
    {
        int Insert(CatalagoChecklistE oCatalogoE);
        List<CatalagoChecklistE> ListAll();
        int Modificar(CatalagoChecklistE oCatalogoE);
        int Eliminar(CatalagoChecklistE oCatalogoE);

    }
}
