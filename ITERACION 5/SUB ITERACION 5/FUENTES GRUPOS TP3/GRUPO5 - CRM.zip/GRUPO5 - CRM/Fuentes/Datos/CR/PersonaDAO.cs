﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Entidades.CR;

namespace Datos.CR
{
    public class PersonaDAO : Datos.CR.IPersonaDAO
    {
        public List<PersonaE> ObtenerAsesores()
        {
            List<PersonaE> lstAsesor = new List<PersonaE>();

            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlDataAdapter da = new SqlDataAdapter();
                    DataTable dt = new DataTable();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Obtener_Lista_de_Asesores";

                    da.SelectCommand = cmd;

                    con.Open();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            PersonaE personaE = new PersonaE();
                            personaE.personaId = dr["CODIGO_USUARIO"].ToString();
                            personaE.nombre = dr["NOMBRE"].ToString();
                            lstAsesor.Add(personaE);
                        }
                    }

                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    con.Close();
                }

            }

            return lstAsesor;

        }
    }
}
