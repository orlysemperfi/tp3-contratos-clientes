﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Entidades.CR;

namespace Datos.CR
{
    public class ListaMarketingDAO : IListaMarketingDAO
    {
        public List<ListaMarketingE> ObtenerListaMarketing() {
            List<ListaMarketingE> lstListaMarketing = new List<ListaMarketingE>();

            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try 
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlDataAdapter da = new SqlDataAdapter();
                    DataTable dt = new DataTable();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Obtener_Lista_de_Marketing";
                    
                    da.SelectCommand = cmd;
                
                    con.Open();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0) {
                        foreach (DataRow dr in dt.Rows)
                        {
                            ListaMarketingE listaMarketingE = new ListaMarketingE();
                            listaMarketingE.listaMarketingId = int.Parse((dr["CODIGO_LM"].ToString()));
                            listaMarketingE.nombre = dr["NOMBRE"].ToString();
                            lstListaMarketing.Add(listaMarketingE); 
                        }
                    }

                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    con.Close();
                }

            }

            return lstListaMarketing;
        
        }

 
        public DataSet ConsultarLista_de_Marketing(ListaMarketingE listaMarketingE)
        {
            DataSet dts = new DataSet();

            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion())) {

                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Consultar_Lista_de_Marketing";
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_LM", listaMarketingE.listaMarketingId));

                    SqlDataAdapter miada = default(SqlDataAdapter);
                    miada = new SqlDataAdapter(cmd);
                    miada.Fill(dts);
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally 
                {
                    con.Close();
                }
            }

            return dts;
        }

        public int InsertarListaMarketing(List<ContactoE> lstContacto, ListaMarketingE listaMarketingE)
        {
            int vsalida = -1;

            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Insertar_Lista_de_Marketing";
                    String idListaMarketing = null;

                    cmd.Parameters.Add(new SqlParameter("@NOMBRE", listaMarketingE.nombre));

                    SqlParameter paramOut = new SqlParameter("@CODIGO_LM", SqlDbType.Int);
                    paramOut.Direction = ParameterDirection.Output;

                    cmd.Parameters.Add(paramOut);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    
                    idListaMarketing = paramOut.Value.ToString();
                    vsalida = int.Parse(idListaMarketing);

                    foreach (ContactoE c in lstContacto)
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "sp_Actualizar_Contacto";

                        cmd.Parameters.Clear();

                        cmd.Parameters.Add(new SqlParameter("@NOMBRE", c.nombre));
                        cmd.Parameters.Add(new SqlParameter("@DNI", c.tipo));
                        cmd.Parameters.Add(new SqlParameter("@RAZON_SOCIAL", c.razonSocial));
                        cmd.Parameters.Add(new SqlParameter("@RUC", c.ruc));
                        cmd.Parameters.Add(new SqlParameter("@CATEGORIA", c.categoria));
                        cmd.Parameters.Add(new SqlParameter("@RUBRO", c.rubro));
                        cmd.Parameters.Add(new SqlParameter("@CARGO", c.cargo));
                        cmd.Parameters.Add(new SqlParameter("@TELEFONO", c.telefono));
                        cmd.Parameters.Add(new SqlParameter("@EMAIL", c.email));
                        cmd.Parameters.Add(new SqlParameter("@OBSERVACIONES", c.observaciones));
                        cmd.Parameters.Add(new SqlParameter("@DIRECCION", c.direccion));
                        cmd.Parameters.Add(new SqlParameter("@CODIGO_LM", idListaMarketing));

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
                catch (SqlException ex)
                {
                    vsalida = -1;
                    throw new Exception(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return vsalida;
        }
    }
}
