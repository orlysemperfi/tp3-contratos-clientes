﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Entidades.CR;

namespace Datos.CR
{
    public class SeguimientoDAO : Datos.CR.ISeguimientoDAO
    {
        public bool InsertarSeguimiento(SeguimientoE seguimientoE)
        {
            Boolean response = false; 

            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Insertar_Seguimiento";

                    cmd.Parameters.Add(new SqlParameter("@CANAL", seguimientoE.canal));
                    cmd.Parameters.Add(new SqlParameter("@FECHA_DE_CONTACTO", DateTime.ParseExact(seguimientoE.fechaContacto, "yyyy-MM-dd", null)));
                    cmd.Parameters.Add(new SqlParameter("@COSTO", seguimientoE.costoReal));
                    cmd.Parameters.Add(new SqlParameter("@ESTADO", seguimientoE.estado));
                    cmd.Parameters.Add(new SqlParameter("@OBSERVACIONES", seguimientoE.observaciones));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_OVENTA", seguimientoE.contactoId));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_LM", seguimientoE.codigo_lm));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_CAMPANA_CAPTACION", seguimientoE.codigo_campana_captacion));
                    
                    con.Open();
                    cmd.ExecuteNonQuery();
                    response = true;
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return response;
        }

        public bool ModificarSegumiento(SeguimientoE seguimientoE)
        {
            Boolean response = false;

            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion())) 
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Modificar_Seguimiento";
                    
                    cmd.Parameters.Add(new SqlParameter("@CANAL", seguimientoE.canal));
                    cmd.Parameters.Add(new SqlParameter("@FECHA_DE_CONTACTO", DateTime.ParseExact(seguimientoE.fechaContacto, "yyyy-MM-dd", null)));
                    cmd.Parameters.Add(new SqlParameter("@COSTO_REAL", seguimientoE.costoReal));
                    cmd.Parameters.Add(new SqlParameter("@ESTADO", seguimientoE.estado));
                    cmd.Parameters.Add(new SqlParameter("@OBSERVACIONES", seguimientoE.observaciones));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_SEGUIMIENTO", seguimientoE.segumientoId));

                    con.Open();
                    cmd.ExecuteNonQuery();
                    response = true;
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return response;
        }

        public DataSet buscaSeguimiento(int seguimientoId)
        {
            DataSet dts = new DataSet();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_buscar_segumiento";

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_SEGUIMIENTO", seguimientoId));
                    SqlDataAdapter miada = default(SqlDataAdapter);
                    miada = new SqlDataAdapter(cmd);
                    miada.Fill(dts);
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return dts;
        }
        
        public DataSet ConsultarSegumiento_PorContacto(SeguimientoE seguimientoE)
        {
            DataSet dts = new DataSet();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Consultar_Segumiento_por_contacto";

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_LM", seguimientoE.codigo_lm));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_CAMPANA_CAPTACION", seguimientoE.codigo_campana_captacion));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_OVENTA", seguimientoE.codigo_oventa));

                    con.Open();

                    SqlDataAdapter miada = default(SqlDataAdapter);
                    miada = new SqlDataAdapter(cmd);
                    miada.Fill(dts);
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return dts;
        }
        
        public DataSet ConsultarSegumiento_PorCampana_Captacion(int campanaCaptacionId)
        {
            DataSet dts = new DataSet();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Consultar_Contactos_por_Campana";
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_CAMPANA_CAPTACION", campanaCaptacionId));
                    SqlDataAdapter miada = default(SqlDataAdapter);
                    miada = new SqlDataAdapter(cmd);
                    miada.Fill(dts);

                }
                catch (SqlException x)
                {
                    throw new Exception(x.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return dts;
        }

    }
}
