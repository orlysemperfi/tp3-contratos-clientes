﻿using System;
using System.Data;
using Entidades.CR;
using System.Collections.Generic;

namespace Datos.CR
{
    public interface ISeguimientoDAO
    {
        DataSet buscaSeguimiento(int seguimientoId);
        
        bool InsertarSeguimiento(SeguimientoE seguimientoE);
        
        bool ModificarSegumiento(SeguimientoE seguimientoE);

        DataSet ConsultarSegumiento_PorContacto(SeguimientoE seguimientoE);

        DataSet ConsultarSegumiento_PorCampana_Captacion(int campanaCaptacionId);
    }
}
