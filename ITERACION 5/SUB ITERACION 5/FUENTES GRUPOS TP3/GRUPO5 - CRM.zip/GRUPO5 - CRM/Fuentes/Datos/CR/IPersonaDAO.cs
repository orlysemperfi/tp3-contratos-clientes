﻿using System;
using System.Collections.Generic;
using Entidades.CR;

namespace Datos.CR
{
    public interface IPersonaDAO
    {
        List<PersonaE> ObtenerAsesores();
    }
}
