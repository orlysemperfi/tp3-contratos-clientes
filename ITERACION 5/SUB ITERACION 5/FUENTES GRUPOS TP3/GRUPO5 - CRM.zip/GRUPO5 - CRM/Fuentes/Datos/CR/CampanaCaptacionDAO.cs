﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Entidades.CR;

namespace Datos.CR
{
    public class CampanaCaptacionDAO : ICampanaCaptacionDAO
    {
        public bool InsertarCampana_Captacion(CampanaCaptacionE campanaCaptacionE)
        {
            Boolean response = false;
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try 
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Insertar_Campana_Captacion";

                    cmd.Parameters.Add(new SqlParameter("@NOMBRE", campanaCaptacionE.nombre));
                    cmd.Parameters.Add(new SqlParameter("@FECHA_INICIO", DateTime.ParseExact(campanaCaptacionE.fechaInicio, "yyyy-MM-dd", null)));
                    cmd.Parameters.Add(new SqlParameter("@FECHA_FIN", DateTime.ParseExact(campanaCaptacionE.fechaFin, "yyyy-MM-dd", null)));
                    cmd.Parameters.Add(new SqlParameter("@PRESUPUESTO_PLANIFICADO", campanaCaptacionE.presupuestoPlanificado));
                    cmd.Parameters.Add(new SqlParameter("@OBJETIVOS", campanaCaptacionE.objetivos));
                    cmd.Parameters.Add(new SqlParameter("@OBSERVACIONES", campanaCaptacionE.observaciones));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_LM", campanaCaptacionE.listaMarketing));
                    
                    con.Open();
                    cmd.ExecuteNonQuery();
                    response = true;

                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
                finally
                {
                    con.Close();
                }
            }

            return response;
        }

        public bool ModificarCampana_Captacion(CampanaCaptacionE campanaCaptacionE)
        {
            Boolean response = false;
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Modificar_Campana_Captacion";

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_CAMPANA_CAPTACION", campanaCaptacionE.campanaCaptacionId));
                    cmd.Parameters.Add(new SqlParameter("@NOMBRE", campanaCaptacionE.nombre));
                    cmd.Parameters.Add(new SqlParameter("@FECHA_INICIO", campanaCaptacionE.fechaInicio));
                    cmd.Parameters.Add(new SqlParameter("@FECHA_FIN", campanaCaptacionE.fechaFin));
                    cmd.Parameters.Add(new SqlParameter("@PRESUPUESTO_PLANIFICADO", campanaCaptacionE.presupuestoPlanificado));
                    cmd.Parameters.Add(new SqlParameter("@PRESUPUESTO_REAL", campanaCaptacionE.presupuestoReal));
                    cmd.Parameters.Add(new SqlParameter("@OBJETIVOS", campanaCaptacionE.objetivos));
                    cmd.Parameters.Add(new SqlParameter("@OBSERVACIONES", campanaCaptacionE.observaciones));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_LM", campanaCaptacionE.listaMarketing));
                    cmd.Parameters.Add(new SqlParameter("@ESTADO", campanaCaptacionE.estado));

                    con.Open();
                    cmd.ExecuteNonQuery();
                    response = true;
                }
                catch(SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return response;
        }

        public DataSet ListarCampana_Captacion()
        {
            DataSet dts = new DataSet();
            
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Listar_Campana_Captacion";
                    SqlDataAdapter miada = default(SqlDataAdapter);
                    miada = new SqlDataAdapter(cmd);
                    miada.Fill(dts);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();                
                }
            }
            return dts;
        }

        public DataSet ConsultarCampana_Captacion(CampanaCaptacionE campanaCaptacionE)
        {
            DataSet dts = new DataSet();

            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Consultar_Campana_Captacion";
                    cmd.Parameters.Add(new SqlParameter("@NOMBRE", campanaCaptacionE.nombre));
                    cmd.Parameters.Add(new SqlParameter("@ESTADO", campanaCaptacionE.estado));
                    cmd.Parameters.Add(new SqlParameter("@FECHA_INICIO",campanaCaptacionE.fechaInicio));
                    cmd.Parameters.Add(new SqlParameter("@FECHA_FIN", campanaCaptacionE.fechaFin));

                    SqlDataAdapter miada = default(SqlDataAdapter);
                    miada = new SqlDataAdapter(cmd);
                    miada.Fill(dts);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();                
                }
            }
            return dts;
        }

        public DataSet ConsultarCampana_Captacion_Estado(CampanaCaptacionE campanaCaptacionE) 
        {
            DataSet dts = new DataSet();

            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Consultar_Campana_Captacion_Estado";
                    cmd.Parameters.Add(new SqlParameter("@ESTADO", campanaCaptacionE.estado));

                    SqlDataAdapter miada = default(SqlDataAdapter);
                    miada = new SqlDataAdapter(cmd);
                    miada.Fill(dts);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();                
                }
            }
            return dts;
        }

        public DataSet BuscaCampana_Captacion(int campanaCaptacionId)
        {
            DataSet dts = new DataSet();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Busca_Campana_Captacion";
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_CAMPANA_CAPTACION", campanaCaptacionId));
                    SqlDataAdapter miada = default(SqlDataAdapter);
                    miada = new SqlDataAdapter(cmd);
                    miada.Fill(dts);
                }
                catch (SqlException x)
                {
                    throw new Exception(x.Message);
                }
            }
            return dts;
        }

        public bool ModificarCostoCampana(int idCampana)
        {
            Boolean response = false;
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Modificar_Costo_Campana_Captacion";

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_CAMPANA_CAPTACION", idCampana));

                    con.Open();
                    cmd.ExecuteNonQuery();
                    response = true;
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return response;
        }
                
        public bool AutorizarCampana_Captacion(CampanaCaptacionE campanaCaptacionE)
        {
            Boolean response = false;
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Autorizar_Campana_Captacion";

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_CAMPANA_CAPTACION", campanaCaptacionE.campanaCaptacionId));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_USUARIO_ASESOR", campanaCaptacionE.codigoUsuarioAsesor));

                    con.Open();
                    cmd.ExecuteNonQuery();
                    response = true;
                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return response;
        }

        public bool RechazarCampana_Captacion(CampanaCaptacionE campanaCaptacionE)
        {
            Boolean response = false;
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Rechazar_Campana_Captacion";

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_CAMPANA_CAPTACION", campanaCaptacionE.campanaCaptacionId));
                    cmd.Parameters.Add(new SqlParameter("@MOTIVO_RECHAZO", campanaCaptacionE.motivoRechazo));
                    
                    con.Open();
                    cmd.ExecuteNonQuery();
                    response = true;
                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return response;
        }
    }
}
