﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Entidades.CR;

namespace Datos.CR
{
    public class ContactoDAO : IContactoDAO
    {
        public DataSet ConsultarContacto_PorCampana_Captacion(int campanaCaptacionId)
        {
            DataSet dts = new DataSet();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Consultar_Contactos_por_Campana";

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_CAMPANA_CAPTACION", campanaCaptacionId));

                    con.Open();

                    SqlDataAdapter miada = default(SqlDataAdapter);
                    miada = new SqlDataAdapter(cmd);
                    miada.Fill(dts);
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return dts;
        }

        public DataSet Consultar_Oventa(ContactoE contactoE)
        {
            DataSet dts = new DataSet();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Consultar_Oventa";

                    cmd.Parameters.Add(new SqlParameter("@RAZON_SOCIAL", contactoE.razonSocial));
                    cmd.Parameters.Add(new SqlParameter("@RUC", contactoE.ruc));

                    con.Open();

                    SqlDataAdapter miada = default(SqlDataAdapter);
                    miada = new SqlDataAdapter(cmd);
                    miada.Fill(dts);
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return dts;
        }

        public DataSet Busca_Oventa(int codigoOventa)
        {
            DataSet dts = new DataSet();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Busca_Oventa";
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_OVENTA", codigoOventa));
                    SqlDataAdapter miada = default(SqlDataAdapter);
                    miada = new SqlDataAdapter(cmd);
                    miada.Fill(dts);
                }
                catch (SqlException x)
                {
                    throw new Exception(x.Message);
                }
            }
            return dts;
        }

        public bool Actualiza_Oventa(ContactoE contactoE)
        {
            Boolean response = false;
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();

                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Actualiza_Oventa";

                    cmd.Parameters.Add(new SqlParameter("@CODIGO_OVENTA", contactoE.contactoId));
                    cmd.Parameters.Add(new SqlParameter("@NOMBRE", contactoE.nombre));
                    cmd.Parameters.Add(new SqlParameter("@DNI", contactoE.dni));
                    cmd.Parameters.Add(new SqlParameter("@TIPO", contactoE.tipo));
                    cmd.Parameters.Add(new SqlParameter("@RAZON_SOCIAL", contactoE.razonSocial));
                    cmd.Parameters.Add(new SqlParameter("@RUC", contactoE.ruc));
                    cmd.Parameters.Add(new SqlParameter("@RUBRO", contactoE.rubro));
                    cmd.Parameters.Add(new SqlParameter("@CARGO", contactoE.cargo));
                    cmd.Parameters.Add(new SqlParameter("@TELEFONO", contactoE.telefono));
                    cmd.Parameters.Add(new SqlParameter("@EMAIL", contactoE.email));
                    cmd.Parameters.Add(new SqlParameter("@INTERESES", contactoE.intereses));
                    cmd.Parameters.Add(new SqlParameter("@OBSERVACIONES", contactoE.observaciones));
                    cmd.Parameters.Add(new SqlParameter("@DIRECCION", contactoE.direccion));
                    cmd.Parameters.Add(new SqlParameter("@ESTADO_OFERTA", contactoE.estado_oferta));

                    con.Open();
                    cmd.ExecuteNonQuery();
                    response = true;
                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return response;
        }
    }
}
