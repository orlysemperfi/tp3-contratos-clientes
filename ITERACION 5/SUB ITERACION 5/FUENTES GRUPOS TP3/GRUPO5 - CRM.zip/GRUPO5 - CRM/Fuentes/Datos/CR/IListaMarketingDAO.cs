﻿using System;
using System.Data;
using Entidades.CR;
using System.Collections.Generic;

namespace Datos.CR
{
    public interface IListaMarketingDAO
    {
        List<ListaMarketingE> ObtenerListaMarketing();

        DataSet ConsultarLista_de_Marketing(ListaMarketingE listaMarketingE);

        int InsertarListaMarketing(List<Entidades.CR.ContactoE> lstContacto, ListaMarketingE listaMarketingE);
    }
}
