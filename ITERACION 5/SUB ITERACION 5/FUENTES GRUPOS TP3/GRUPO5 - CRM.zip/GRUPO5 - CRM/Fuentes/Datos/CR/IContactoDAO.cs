﻿using System;
using System.Data;
using Entidades.CR;

namespace Datos.CR
{
    public interface IContactoDAO
    {
        DataSet ConsultarContacto_PorCampana_Captacion(int campanaCaptacionId);

        DataSet Consultar_Oventa(ContactoE contactoE);

        Boolean Actualiza_Oventa(ContactoE contactoE);

        DataSet Busca_Oventa(int oventaId);
    }
}
