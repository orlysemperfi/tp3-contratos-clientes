﻿using System;
using System.Data;
using Entidades.CR;
using System.Collections.Generic;

namespace Datos.CR
{
    public interface ICampanaCaptacionDAO
    {
        DataSet BuscaCampana_Captacion(int campanaCaptacionId);

        DataSet ConsultarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);

        DataSet ConsultarCampana_Captacion_Estado(CampanaCaptacionE campanaCaptacionE);
        
        bool InsertarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);

        DataSet ListarCampana_Captacion();

        bool ModificarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);

        bool ModificarCostoCampana(int idCampana);
        
        bool AutorizarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);

        bool RechazarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);
    }
}
