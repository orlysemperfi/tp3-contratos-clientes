﻿using System;
namespace Datos.SI
{
    public interface IVerificacionControlDAO
    {
        System.Collections.Generic.List<Entidades.SI.ControlE> getListaControles(int codPolitica);
        System.Collections.Generic.List<Entidades.SI.PoliticaE> getListaPoliticas();
        System.Collections.Generic.List<Entidades.SI.VerificacionE> getListaVerificacion(int codControl, string fechaDesde, string fechaHasta);
        Entidades.SI.ResponsableControlE getResponsableControl(int codResponsable);
        int registrarVerificacion(Entidades.SI.VerificacionE o);
    }
}
