﻿using System;
namespace Datos.SI
{
    public interface ITipoActivoDAO
    {
        void insertar(Entidades.SI.TipoActivoE o);
    }
}
