﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.SI;
using Datos.GEN;
using System.Data;
using System.Data.SqlClient;

namespace Datos.SI
{
    public class CreacionActivoDAO : Datos.SI.ICreacionActivoDAO
    {
        public List<MonedaE> getListaMonedas()
        {
            List<MonedaE> lstMoneda = new List<MonedaE>();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("CC.USP_MONEDA_SEL", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        MonedaE bean = new MonedaE();
                        bean.codMoneda = reader.GetString(0);
                        bean.nomMoneda = reader.GetString(1);
                        lstMoneda.Add(bean);
                    }

                    cmd.Dispose();
                }

                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                finally
                {
                    con.Close();
                }
            }
            return lstMoneda;
        }


        public List<ActivoE> getListActivo()
        {
            List<ActivoE> lstActivo = new List<ActivoE>();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("SI.USP_ACTIVO_SEL", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        ActivoE bean = new ActivoE();
                        bean.codActivo = reader.GetInt32(0);
                        bean.nomActivo = reader.GetString(1);
                        lstActivo.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return lstActivo;
        }

        public int registrarActivo(ActivoE o, int codProp, int codRTO, string codTipoAct, string codMoneda, int codActivoPadre)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("SI.USP_ACTIVO_INS", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    //Parametro de salida
                    SqlParameter result_transac = new SqlParameter("@TRANSAC", SqlDbType.Int);
                    result_transac.Direction = ParameterDirection.Output;

                    cmd.Parameters.Add(result_transac);
                    cmd.Parameters.Add(new SqlParameter("@CODACTIVO", o.codActivo));
                    cmd.Parameters.Add(new SqlParameter("@NOMACTIVO", o.nomActivo));
                    cmd.Parameters.Add(new SqlParameter("@PROPIETARIO", codProp));
                    cmd.Parameters.Add(new SqlParameter("@RPO", codRTO));
                    cmd.Parameters.Add(new SqlParameter("@CODTIPACTIVO", codTipoAct));
                    cmd.Parameters.Add(new SqlParameter("@UBICACION", o.ubicacion));
                    cmd.Parameters.Add(new SqlParameter("@CODIGO_MONEDA", codMoneda));
                    cmd.Parameters.Add(new SqlParameter("@COSTO_ACTIVO", o.costo));
                    cmd.Parameters.Add(new SqlParameter("@CODACTIVO_PADRE", codActivoPadre));

                    int response = cmd.ExecuteNonQuery();
                    if (response > 0)
                    {
                        result = Convert.ToInt32(cmd.Parameters["@TRANSAC"].Value);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return result;
        }
    }
}
