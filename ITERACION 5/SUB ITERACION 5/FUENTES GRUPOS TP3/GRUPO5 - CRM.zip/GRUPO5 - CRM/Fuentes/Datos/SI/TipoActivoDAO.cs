﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.SI;
using System.Data;
using System.Data.SqlClient;
using Datos.GEN;

namespace Datos.SI
{
    public class TipoActivoDAO : Datos.SI.ITipoActivoDAO
    {
        public void insertar(TipoActivoE o)
        {
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("SI.TIPOACTIVO_INS", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@Codigo", o.codigo));
                    cmd.Parameters.Add(new SqlParameter("@Nombre", o.nombre));
                    

                    int response = cmd.ExecuteNonQuery();

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
