﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.SI;
using Datos.GEN;
using System.Data;
using System.Data.SqlClient;

namespace Datos.SI
{
    public class VerificacionControlDAO : Datos.SI.IVerificacionControlDAO
    {
        public List<ControlE> getListaControles(int codPolitica)
        {
            List<ControlE> lstControles = new List<ControlE>();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("SI.USP_LISTA_CONTROL", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CodPolitica", codPolitica));
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        ControlE bean = new ControlE();
                        bean.codControl = reader.GetInt32(0);
                        bean.nomControl = reader.GetString(1);
                        bean.codEmpleado = reader.GetInt32(2);
                        lstControles.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return lstControles;
        }

        public List<PoliticaE> getListaPoliticas()
        {
            List<PoliticaE> lstPolitica = new List<PoliticaE>();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("SI.USP_LISTA_POLITICA", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        PoliticaE bean = new PoliticaE();
                        bean.codPolitica = reader.GetInt32(0);
                        bean.nomPolitica = reader.GetString(1);
                        lstPolitica.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return lstPolitica;
        }

        public ResponsableControlE getResponsableControl(int codResponsable)
        {
            ResponsableControlE bean = new ResponsableControlE();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("SI.USP_RESPONSABLE", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CodEmpleado", codResponsable));
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        bean.codResponsable = reader.GetInt32(0);
                        bean.nomResponsable = reader.GetString(1);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return bean;

        }

        public List<VerificacionE> getListaVerificacion(int codControl, string fechaDesde, string fechaHasta)
        {
            List<VerificacionE> lstVerificacion = new List<VerificacionE>();
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("SI.USP_LISTA_VERIFICACION", con);
                    cmd.Parameters.Add(new SqlParameter("@CodControl", codControl));
                    cmd.Parameters.Add(new SqlParameter("@FechaVerificacionDesde", fechaDesde));
                    cmd.Parameters.Add(new SqlParameter("@FechaVerificacionHasta", fechaHasta));
                    cmd.CommandType = CommandType.StoredProcedure;

                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        VerificacionE bean = new VerificacionE();
                        bean.codVerificacion = reader.GetInt32(0);
                        bean.codControl = reader.GetInt32(1);
                        bean.nomControl = reader.GetString(2);
                        bean.nomEmpleado = reader.GetString(3);
                        bean.fechaVerificacionDate = reader.GetDateTime(4);
                        bean.tipoVerificacion = reader.GetString(5);
                        bean.observacion = reader.GetString(6);
                        bean.resultado = reader.GetString(7);
                        lstVerificacion.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return lstVerificacion;
        }

        public int registrarVerificacion(VerificacionE o)
        {
            int result=0;
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("SI.USP_REGISTRAR_VERIFICACION", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    //Parametro de salida
                    SqlParameter result_transac = new SqlParameter("@Transacc", SqlDbType.Int);
                    result_transac.Direction = ParameterDirection.Output;

                    cmd.Parameters.Add(result_transac);
                    cmd.Parameters.Add(new SqlParameter("@CodVerificacion", o.codVerificacion));
                    cmd.Parameters.Add(new SqlParameter("@CodControl", o.codControl));
                    cmd.Parameters.Add(new SqlParameter("@CodTipoVerificacion", o.codTipoVerificacion));
                    cmd.Parameters.Add(new SqlParameter("@Observacion", o.observacion));
                    cmd.Parameters.Add(new SqlParameter("@Resultado", o.codResultado));
                    cmd.Parameters.Add(new SqlParameter("@Resultado", o.codResultado));                    

                    int response = cmd.ExecuteNonQuery();
                    if(response > 0){
                        result = Convert.ToInt32(cmd.Parameters["@Transacc"].Value);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return result;
        }
    }
}
