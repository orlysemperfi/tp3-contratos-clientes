﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.SI
{

    public class ActivoE
    {
        public int codActivo { get; set; }
        public string nomActivo { get; set; }
        public string ubicacion { get; set; }
        public decimal costo { get; set; }
        public int codPropietario { get; set; }
        public string nomPropietario { get; set; }
        public int codRPO { get; set; }
        public string nomRPO { get; set; }
        public string codTipoActivo { get; set; }
        public string nomTipoActivo { get; set; }
        public string nomUbicacion { get; set; }
        public string codMoneda { get; set; }
        public string nomMoneda { get; set; }
        public decimal CostoActivo { get; set; }
        public int codActivoPadre { get; set; }
        public string nomActivoPadre { get; set; }
    }

}
