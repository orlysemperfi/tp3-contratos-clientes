﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.SI
{
    public class VerificacionE
    {
        public int codVerificacion { get; set; }
        public int codControl { get; set; }
        public string nomControl { get; set; }
        public string nomEmpleado { get; set; }
        public string fechaVerificacion { get; set; }
        public DateTime fechaVerificacionDate { get; set; }
        public int codTipoVerificacion { get; set; }
        public string tipoVerificacion { get; set; }
        public string observacion { get; set; }
        public int codResultado { get; set; }
        public string resultado { get; set; }

    }
}
