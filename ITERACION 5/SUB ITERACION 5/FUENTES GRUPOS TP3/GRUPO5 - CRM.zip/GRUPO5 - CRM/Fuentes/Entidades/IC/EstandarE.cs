﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.IC
{
    public class EstandaresE
    {

        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Archivo { get; set; }
        public string Estado { get; set; }
        public int Version { get; set; }
        public string Usuario_Aprobacion { get; set; }
        public string Fecha_Aprobacion { get; set; }
        public string Usuario_Creacion { get; set; }
        public string Fecha_Creacion { get; set; }
        public string Usuario_Modificacion { get; set; }
        public string Fecha_Modificacion { get; set; }

    }
}
