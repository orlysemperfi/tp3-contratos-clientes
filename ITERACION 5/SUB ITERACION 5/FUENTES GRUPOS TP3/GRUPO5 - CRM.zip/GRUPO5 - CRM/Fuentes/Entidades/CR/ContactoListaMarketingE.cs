﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.CR
{
    public class ContactoListaMarketingE
    {
        public int contactoId {get; set;}
        public int listaMarketingId {get; set;}
    }
}
