﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.CR
{
    public class ListaMarketingE
    {
        public String nombre {get; set;}
        public String tipo { get; set; }
        public int listaMarketingId { get; set; }
        public int campanaCapacitacionId { get; set; }
    }
}
