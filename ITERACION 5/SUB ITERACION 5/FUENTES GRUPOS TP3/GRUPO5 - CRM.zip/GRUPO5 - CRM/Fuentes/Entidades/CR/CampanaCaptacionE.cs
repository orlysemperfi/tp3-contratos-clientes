﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.CR
{
    public class CampanaCaptacionE
    {
        public int campanaCaptacionId {get; set;}
        public String nombre {get; set;}
        public String fechaCreacion {get; set;}
        public String fechaInicio {get; set;}
        public String fechaFin {get; set;}
        public double presupuestoPlanificado {get; set;}
        public double presupuestoReal { get; set; }
        public String objetivos { get; set; }
        public String observaciones { get; set; }
        public String estado { get; set; }
        public int listaMarketing { get; set; }

        public String codigoUsuarioAsesor { get; set; }
        public String codigoUsuarioAutoriza { get; set; }
        public String fechaAutorizacion { get; set; }

        public String codigoUsuarioRechazo { get; set; }
        public String motivoRechazo { get; set; }
        public String fechaRechazo { get; set; }
    }
}
