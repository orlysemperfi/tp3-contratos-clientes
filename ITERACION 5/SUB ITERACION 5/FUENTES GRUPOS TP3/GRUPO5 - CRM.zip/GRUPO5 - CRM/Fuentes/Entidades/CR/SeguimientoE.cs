﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.CR
{
    public class SeguimientoE
    {
        public int segumientoId {get; set;}
        public String canal { get; set; }
        public double costoReal { get; set; }
        public String fechaContacto { get; set; }
        public String estado { get; set; }
        public String observaciones { get; set; }
        public int codigo_lm { get; set; }
        public int codigo_campana_captacion { get; set; }
        public int codigo_oventa { get; set; }
        
        public int contactoId { get; set; }
    }
}
