﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.CR
{
    public class ContactoE
    {
        public string contactoId { get; set; }
        public string nombre { get; set; }
        public string dni { get; set; }
        public string tipo { get; set; }
        public string razonSocial { get; set; }
        public string ruc { get; set; }
        public string categoria { get; set; }
        public string rubro { get; set; }
        public string cargo { get; set; }
        public string telefono { get; set; }
        public string email { get; set; }
        public string intereses { get; set; }
        public string observaciones { get; set; }
        public string estado_oferta { get; set; }
        public string direccion { get; set; }
    }
}
