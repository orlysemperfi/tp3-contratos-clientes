﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.GEN
{
    public class OrganizacionE
    {
        public string codigoOrganizacion { get; set; }
        public string nombre { get; set; }
        public string vision { get; set; }
        public string mision { get; set; }
  
    }


}
