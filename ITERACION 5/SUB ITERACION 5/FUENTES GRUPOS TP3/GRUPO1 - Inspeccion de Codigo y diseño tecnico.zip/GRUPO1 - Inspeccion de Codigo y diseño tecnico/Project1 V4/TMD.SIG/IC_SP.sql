USE [TMD]
GO

/****** Object:  StoredProcedure [IC].[ESTANDAR_INS]    Script Date: 01/19/2013 20:42:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [IC].[ESTANDAR_INS] (
                    @P_CODIGO varchar(10),
                    @P_NOMBRE varchar(50),
                    @P_DESCRIPCION varchar(255),
                    @P_ARCHIVO varchar(255),
                    @P_USRCREA varchar(10)
                    )

as

declare @conta int;

select @conta= COUNT(1) from [IC].[ESTANDARES_PROGRAMACION_DISENO]

if ( @conta = 0) 
	set @P_CODIGO = 1;
else
	select @P_CODIGO= (MAX(CODIGO)+1)
	from [IC].[ESTANDARES_PROGRAMACION_DISENO];


INSERT INTO [TMD].[IC].[ESTANDARES_PROGRAMACION_DISENO]
           ([CODIGO]
           ,[NOMBRE]
           ,[DESCRIPCION]
           ,[ARCHIVO]
           ,[ESTADO]
           ,[USUARIO_CREACION]
           ,[FECHA_CREACION])
     VALUES
           (@P_CODIGO
           ,@P_NOMBRE
           ,@P_DESCRIPCION
           ,@P_ARCHIVO
           ,'P'
           ,@P_USRCREA
           ,GETDATE());

GO

USE [TMD]
GO

/****** Object:  StoredProcedure [IC].[ESTANDAR_LIS]    Script Date: 01/19/2013 20:43:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [IC].[ESTANDAR_LIS]
as

SELECT [CODIGO]
      ,[NOMBRE]
      ,[DESCRIPCION]
      ,[ARCHIVO]
      ,[ESTADO]
      ,[USUARIO_APROBACION]
      ,CONVERT(VARCHAR(10),[FECHA_APROBACION],105) AS "FECHA_APROBACION"
      ,[USUARIO_CREACION]
      ,CONVERT(VARCHAR(10),[FECHA_CREACION],105) AS "FECHA_CREACION"
      ,[USUARIO_MODIFICACION]
      ,CONVERT(VARCHAR(10),[FECHA_MODIFICACION],105) AS "FECHA_MODIFICACION"
  FROM [TMD].[IC].[ESTANDARES_PROGRAMACION_DISENO]

GO




