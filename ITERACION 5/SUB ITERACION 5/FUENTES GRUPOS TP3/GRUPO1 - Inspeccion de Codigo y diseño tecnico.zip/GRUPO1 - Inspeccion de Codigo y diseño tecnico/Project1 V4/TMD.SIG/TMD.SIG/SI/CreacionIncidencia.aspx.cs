﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using Entidades.SI;
using Negocio.SI;

namespace TMD.SIG.SI
{
    public partial class CreacionIncidencia : System.Web.UI.Page
    {
        private ICreacionIncidenciaBL creaInci = new CreacionIncidenciaBL();
        private IVerificacionBL generic = new VerificacionBL();

        protected void Page_Load(object sender, EventArgs e)
        {
            TxbEstimacion.Text = "0,00";
            //Cargar Control
            int strNull = 0;
            List<ControlE> lstControl = generic.getListaControles(strNull);
            if (!IsPostBack)
            {
                this.ddlbControl.Items.Clear();
                ddlbControl.Items.Add(new ListItem { Value = "0", Text = "--Seleccione Control--" });
                foreach (ControlE L in lstControl)
                {
                    ddlbControl.Items.Add(new ListItem { Value = L.codControl.ToString(), Text = L.nomControl });
                }
            }
            //Cargar Prioridad
            string param = "PRIORIDAD";
            List<PrioridadImpactoE> lstPriori = creaInci.getListPrioridadImpacto(param);
            if (!IsPostBack)
            {
                this.ddlbPrioridad.Items.Clear();
                ddlbPrioridad.Items.Add(new ListItem { Value = "0", Text = "--Seleccione Prioridad--" });
                foreach (PrioridadImpactoE L in lstPriori)
                {
                    ddlbPrioridad.Items.Add(new ListItem { Value = L.codValor.ToString(), Text = L.descripValor });
                }
            }
            //Cargar Impacto
            string param2 = "IMPACTO";
            List<PrioridadImpactoE> lstImpacto = creaInci.getListPrioridadImpacto(param2);
            if (!IsPostBack)
            {
                this.ddlbImpacto.Items.Clear();
                ddlbImpacto.Items.Add(new ListItem { Value = "0", Text = "--Seleccione Impacto--" });
                foreach (PrioridadImpactoE L in lstImpacto)
                {
                    ddlbImpacto.Items.Add(new ListItem { Value = L.codValor.ToString(), Text = L.descripValor });
                }
            }
        }

        protected void btnGrabar_Click(object sender, EventArgs e)
        {
            if (!TxbCodigo.Text.Equals("")
                && !txtTicket.Text.Equals("")
                && ddlbControl.SelectedIndex != 0)
            {
                const string message = "Esta seguro de guardar el registro?";
                const string caption = "Guardar Incidencia";

                var result = MessageBox.Show(message, caption,
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    IncidenciaE incid = new IncidenciaE();
                    incid.codIncidencia = Convert.ToInt32(TxbCodigo.Text);
                    incid.codTicket = Convert.ToInt32(txtTicket.Text);
                    incid.codControl = Convert.ToInt32(ddlbControl.SelectedValue);
                    incid.fechaApertura = TxbFechaApertura.Text;
                    incid.codPrioridad = Convert.ToInt32(ddlbPrioridad.SelectedValue);
                    incid.codImpacto = Convert.ToInt32(ddlbImpacto.SelectedValue);
                    incid.resumen = TxbResumen.Text;
                    incid.accionInmediata = TxbAxnInmediata.Text;
                    incid.causa = TxbCausa.Text;
                    if (!TxbEstimacion.Text.Equals(""))
                    {
                        incid.estimacionCosto = Convert.ToDecimal(TxbEstimacion.Text);
                    }
                    else
                    {
                        incid.estimacionCosto = Convert.ToDecimal("0,00");
                    }

                    int retorno = creaInci.registrarIncidencia(incid);

                    if (retorno == 0)
                    {
                        var ok = MessageBox.Show("Se guardo satisfactoriamente el registro", "Guardado",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                        if (ok == DialogResult.OK)
                        {
                            limpiar();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Llene los campos obligatorios", "Guardando",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Stop);
            }
        }

        private void limpiar()
        {
            TxbCodigo.Text = "";
            txtTicket.Text = "";
            ddlbControl.SelectedIndex = 0;
            ddlbPrioridad.SelectedIndex = 0;
            ddlbImpacto.SelectedIndex = 0;
            TxbFechaApertura.Text = "";
            TxbResumen.Text = "";
            TxbAxnInmediata.Text = "";
            TxbCausa.Text = "";
            TxbEstimacion.Text = "";

        }

    }
}