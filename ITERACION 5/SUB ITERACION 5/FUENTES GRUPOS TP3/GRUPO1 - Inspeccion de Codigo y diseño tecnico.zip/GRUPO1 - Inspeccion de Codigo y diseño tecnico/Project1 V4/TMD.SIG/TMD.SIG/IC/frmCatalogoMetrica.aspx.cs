﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;

namespace TMD.SIG.IC
{
    public partial class frmCatalogoMetrica : System.Web.UI.Page
    {
        MetricaE oCatalogoE=null;
        MetricaBL oCatalogoBL = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                gvCatalago.DataBind();
        }

        protected void btnGrabar_Click(object sender, EventArgs e)
        {
           
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            oCatalogoE = new MetricaE();
            oCatalogoBL = new MetricaBL();
            try
            {
                //oCatalogoE.Codigo = txtNombre.Text.Trim();

                //implementando logica de negocio
                oCatalogoBL.ModificarEstado(oCatalogoE);
            }
            catch (Exception ex)
            {
                //lblMensaje.Text = ex.Message;
            }
        }

        //Eliminar
        protected void btnAprobar_Click(object sender, EventArgs e)
        {
            oCatalogoBL = new MetricaBL();
            oCatalogoE = new MetricaE();
            oCatalogoE.Codigo = int.Parse(gvCatalago.SelectedRow.Cells[0].Text);
            oCatalogoE.Estado=gvCatalago.SelectedRow.Cells[4].Text;
            if (oCatalogoE.Estado.ToUpper() != "U" && oCatalogoE.Estado.ToUpper() != "P")
            {
                oCatalogoE.Estado = "O";
                oCatalogoBL.ModificarEstado(oCatalogoE);
                gvCatalago.DataBind();
            }
            else
                lblMensaje.Text = "No se puede Eliminar Catalogo se encuentra en uso";
        }

        protected void btnModifcar_Click(object sender, EventArgs e)
        {
            oCatalogoE = new MetricaE();

            oCatalogoE.Codigo = int.Parse(gvCatalago.SelectedRow.Cells[0].Text);
            oCatalogoE.Descripcion = gvCatalago.SelectedRow.Cells[1].Text;
            oCatalogoE.Objetivo = gvCatalago.SelectedRow.Cells[2].Text;
            oCatalogoE.Estado=gvCatalago.SelectedRow.Cells[3].Text;
           
            //if (oCatalogoE.Estado.ToUpper() != "U" && oCatalogoE.Estado.ToUpper() != "P")
            if (oCatalogoE.Estado.ToUpper() == "A" )
            {
                Session["CatalogoM"] = oCatalogoE;
                //oCatalogoBL.Eliminar(oCatalogoE);
                Response.Redirect("./frmModCatalogoMetrica.aspx");
                //gvCatalago.DataBind();
            }
            else
                lblMensaje.Text = "No se puede Modificar Catalogo";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            oCatalogoBL = new MetricaBL();
            oCatalogoE = new MetricaE();
            oCatalogoE.Codigo = int.Parse(gvCatalago.SelectedRow.Cells[0].Text);
            oCatalogoE.Estado = gvCatalago.SelectedRow.Cells[3].Text;
            if (oCatalogoE.Estado.ToUpper() == "P")
            {
                oCatalogoE.Estado = "A";
                oCatalogoBL.ModificarEstado(oCatalogoE);
                gvCatalago.DataBind();
            }
            else
            {
                lblMensaje.Text = "No se puede Aprobar este Catalogo.";
            }
        }


    }
}