﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using Negocio.SI;
using Entidades.SI;

namespace TMD.SIG.SI
{
    public partial class MantenimientoActivo : System.Web.UI.Page
    {
        private IMantenimientoaActivoBL mantAct = new MantenimientoaActivoBL(); 

        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<TipoActivoE> ListTipoActivo = mantAct.listTipoActivo();
                ddlTipoActivo.DataSource = ListTipoActivo;
                ddlTipoActivo.DataValueField = "codTipoActivo";
                ddlTipoActivo.DataTextField = "nomTipoActivo";
                ddlTipoActivo.DataBind();
            }
            
                              
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            List<ActivoE> listaActivo = mantAct.getListaActivo(this.ddlTipoActivo.SelectedValue,
                                                           this.txtNombreActivo.Text.Trim()
                                                         );

            if (listaActivo != null && listaActivo.Count > 0)
            {
                this.lbMensaje.Text = "Se encontraron " + listaActivo.Count + " resultados";
                this.GridViewActivo.DataSource = listaActivo;
                this.GridViewActivo.DataBind();
            }
            else
            {
                this.lbMensaje.Text = "No se encontraron resultados";
                this.GridViewActivo.DataSource = listaActivo;
                this.GridViewActivo.DataBind();
            }
        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
            List<ActivoE> listaActivo = new List<ActivoE>();
            this.GridViewActivo.DataSource = listaActivo;
            this.GridViewActivo.DataBind();
            this.lbMensaje.Text = "";
        
        }


        private void limpiar()
        {
            
         
            this.txtNombreActivo.Text = "";
            this.ddlTipoActivo.SelectedIndex = 0;
          }

        protected void ibtnEditar_Command(object sender, CommandEventArgs e)
        {
            Response.Redirect("EditarActivo.aspx?CodActivo="+e.CommandArgument);
        }

        protected void ibtnEliminar_Command(object sender, CommandEventArgs e)
        {
            string vcodActivo = (string)e.CommandArgument;
           
            const string message = "Esta seguro de eliminar el registro?";
            const string caption = "Eliminar Activo";

                var result = MessageBox.Show(message, caption,
                             MessageBoxButtons.YesNo,
                             MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    ActivoE Activo = new ActivoE();
                    Activo.codActivo = Convert.ToInt32(vcodActivo);
                    int retorno = mantAct.EliminarActivo(Convert.ToInt32(vcodActivo));
                    if (retorno == 0)
                    {
                        var ok = MessageBox.Show("Se elimino satisfactoriamente el registro", "Eliminado",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                        if (ok == DialogResult.OK)
                        {
                            List<ActivoE> listaActivo = new List<ActivoE>();
                            this.GridViewActivo.DataSource = listaActivo;
                            this.GridViewActivo.DataBind();
                            this.lbMensaje.Text = "";
                        }
                    }
                    else
                    {
                        MessageBox.Show("No se puede Eliminar Activo, Activo asignado a un proceso o control", "Eliminando",
                        MessageBoxButtons.OK,
                         MessageBoxIcon.Information);
                    }

                  }
               else
                 {
                    
                    
                }
        }

      













    }
    
}