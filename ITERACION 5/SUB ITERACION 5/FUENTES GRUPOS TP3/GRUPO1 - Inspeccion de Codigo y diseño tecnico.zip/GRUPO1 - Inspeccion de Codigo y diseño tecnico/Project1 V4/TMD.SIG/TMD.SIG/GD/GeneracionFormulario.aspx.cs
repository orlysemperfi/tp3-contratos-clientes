﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.GD;
using Entidades.GD;
using TMD.SIG.Util;

namespace TMD.SIG.GD
{
    public partial class GeneracionFormulario : System.Web.UI.Page
    {

        private IFormularioCabeceraBL forcab = new FormularioCabeceraBL();
        private IFormularioDetalleBL fdet = new FormularioDetalleBL();
        List<FormularioDetalleE> formdet = new List<FormularioDetalleE>();
        private Int32 codemp = 3;
        private Int32 form = 2;
  


        protected void Page_Load(object sender, EventArgs e)
        {
            FormularioCabeceraE frc = new FormularioCabeceraE();
            frc = forcab.llenarCabecera(codemp);
  


            formdet = fdet.ListaDetalle(codemp, form);

            for (int i = 0; i < formdet.Count; i++)
            {
                if (formdet[i].CODIGO_SECCION_DETALLE == 1)
                {
                    lblSecA.Text = formdet[i].SECCION;
                    lblSec1.Text = formdet[i].SECCION_DETALLE;
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 2)
                {
                    lblSec2.Text = formdet[i].SECCION_DETALLE;
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 3)
                {
                    lblSecB.Text = formdet[i].SECCION;
                    lblSec3.Text = formdet[i].SECCION_DETALLE;
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 4)
                {
                    lblSec4.Text = formdet[i].SECCION_DETALLE;
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 5)
                {
                    lblSec5.Text = formdet[i].SECCION_DETALLE;
                }
                if (formdet[i].CODIGO_SECCION_DETALLE == 6)
                {
                    lblSecC.Text = formdet[i].SECCION;
                    lblSec6.Text = formdet[i].SECCION_DETALLE;
                }

            }

        }

        protected void CheckBox7_CheckedChanged(object sender, EventArgs e)
        {
                    }

        protected void bntGrabar_Click(object sender, EventArgs e)
        {
           // String sec1, sec2, sec3, sec4, sec5,sec6;
             String nombre;

            FormularioEvaluacionBL fEvaluacion = new FormularioEvaluacionBL();


            nombre = txtFormulario.Text.Trim().ToUpper();

            if (nombre.Length==0)
            {
                ClientMessageBox.Show("Debe colocar un nombre al formulario", this);
                return;
            }

            if(!chksec1.Checked && !chksec2.Checked){
                ClientMessageBox.Show("Debe seleccionar al menos un campo para la seccion A", this);
                return;
            }


            if (!chksec3.Checked && !chksec4.Checked && !chksec5.Checked)
            {
                ClientMessageBox.Show("Debe seleccionar al menos un campo para la seccion B", this);
                return;
            }

            if (!chksec6.Checked)
            {
                ClientMessageBox.Show("Debe seleccionar al menos un campo para la seccion C", this);
                return;
            }
 

             try
             {
                 Int32 CODIGO = fEvaluacion.insertarFormularioEvaluacion(nombre);

                 if (CODIGO > 0)
                 {
                    
                        
                         if (chksec1.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO,1,1);
             
                         }

                         if (chksec2.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO, 1, 2);
    
                         }
                         if (chksec3.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO, 2, 3);
      
                         }
                         if (chksec4.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO, 2, 4);
                       
                         }
                         if (chksec5.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO, 2, 5);
                             //lista.Add(fgeneradetalle);
                         }

                         if (chksec6.Checked == true)
                         {

                             fEvaluacion.insertaEvaluacionDetalle(CODIGO, 3, 6);
                             //lista.Add(fgeneradetalle);
                         }

                         //bool vResultado = false;

                         //vResultado = new Negocio.GD.FormularioDetalleBL().GenerarFormulario(lista);  
                    
                 }
             }
             catch (Exception)
             {
                 
                 throw;
             }



             Response.Redirect("~/GD/GD_Index.aspx?mensaje=3");  
        }

        protected void bntCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/GD/GD_Index.aspx");
        }
    }
}