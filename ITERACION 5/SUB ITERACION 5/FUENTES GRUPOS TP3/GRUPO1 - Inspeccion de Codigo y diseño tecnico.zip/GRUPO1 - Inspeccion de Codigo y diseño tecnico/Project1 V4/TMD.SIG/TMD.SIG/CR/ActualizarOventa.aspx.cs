﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Negocio.CR;
using Entidades.CR;

namespace TMD.SIG.CR
{
    public partial class ActualizarOventa : System.Web.UI.Page
    {

        IActualizaOventaBL iActualizaOventaBL = new ActualizaOventaBL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

            }
        }

        protected void btnFiltrar_Click(object sender, EventArgs e)
        {
            try
            {

 
                DataTable dt = new DataTable();
                ContactoE obj = new ContactoE();
                obj.razonSocial = txtRazSoc.Text;
                obj.ruc = txtRUC.Text;

                dt = iActualizaOventaBL.Consultar_Oventa(obj).Tables[0];

                grdOventa.DataSource = dt;
                grdOventa.DataBind();
                lblEstadoGrabar.Text = grdOventa.Rows.Count.ToString() + " resultado(s) encontrado(s)";
                lblEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");


            }
            catch (Exception ex)
            {
                lblEstadoGrabar.Text = " " + ex.Message;
                lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
            }
        }
           
        protected void lnkItemName_Click(object sender, EventArgs e)
        {
            Button1_ModalPopupExtender.Show();
        }

        protected void grdOventa_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            String idOventaActual = e.CommandArgument.ToString();

            lblModificarId.Text = idOventaActual;

            DataTable dt = new DataTable();
            dt = iActualizaOventaBL.Busca_Oventa(Convert.ToInt32(idOventaActual)).Tables[0];

            lblEstadoPopup.Text = "";

            txtPopNombre.Text = dt.Rows[0]["NOMBRE"].ToString();
            txtPopDNI.Text = dt.Rows[0]["DNI"].ToString();
            txtPopRazSoc.Text = dt.Rows[0]["RAZON_SOCIAL"].ToString();
            txtPopRUC.Text = dt.Rows[0]["RUC"].ToString();
            
            txtPopCargo.Text = dt.Rows[0]["CARGO"].ToString();
            txtPopTelefono.Text = dt.Rows[0]["TELEFONO"].ToString();
            txtPopDireccion.Text = dt.Rows[0]["DIRECCION"].ToString();
            txtPopEmail.Text = dt.Rows[0]["EMAIL"].ToString();
            txtPopObservaciones.Text = dt.Rows[0]["OBSERVACIONES"].ToString();
            txtPopIntereses.Text = dt.Rows[0]["INTERESES"].ToString();

            ddlEstadoOferta.SelectedValue = dt.Rows[0]["ESTADO_OFERTA"].ToString();
            ddlTipo.SelectedValue = dt.Rows[0]["TIPO"].ToString();
            lblTipoOriginal.Text = dt.Rows[0]["TIPO"].ToString();


            string s = dt.Rows[0]["TIPO"].ToString();

            if (s.Equals("C"))  //CONTACTO
            {
                lblEstadoOferta.Visible = false;
                ddlEstadoOferta.Visible = false;
            }
             else if (s.Equals("P")) //PROSPECTO
             {
                 lblEstadoOferta.Visible = true;
                 ddlEstadoOferta.Visible = true;
             }
             else  //CLIENTE POTENCIAL
             {
                 lblEstadoOferta.Visible = true;
                 ddlEstadoOferta.Visible = true;
             }
        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            try
            {
                String cadena = "Los campos ";
                bool valida = false;

                if (txtPopRUC.Text.Trim().Length == 0)
                {
                    cadena += "RUC, ";
                    valida = true;
                }

                if (txtPopRazSoc.Text.Trim().Length == 0)
                {
                    cadena += "Razón social, ";
                    valida = true;
                }


                if (valida)
                {
                    lblEstadoPopup.Text = cadena + " son requeridos";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    Button1_ModalPopupExtender.Show();
                    return;
                }


                if (lblTipoOriginal.Text.Trim().Equals("C") &&
                     ddlTipo.SelectedValue.Equals("L"))
                {
                    lblEstadoPopup.Text = "La OV debería pasar a Prospecto";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    Button1_ModalPopupExtender.Show();
                    return;
                }

                if (lblTipoOriginal.Text.Trim().Equals("P") &&
                     ddlTipo.SelectedValue.Equals("C"))
                {
                    lblEstadoPopup.Text = "La OV no puede retornar a Contacto";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    Button1_ModalPopupExtender.Show();
                    return;
                }

                if (lblTipoOriginal.Text.Trim().Equals("L") &&
                     ddlTipo.SelectedValue.Equals("C"))
                {
                    lblEstadoPopup.Text = "La OV no puede retornar a Contacto";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    Button1_ModalPopupExtender.Show();
                    return;
                }

                if (lblTipoOriginal.Text.Trim().Equals("L") &&
                                     ddlTipo.SelectedValue.Equals("C"))
                {
                    lblEstadoPopup.Text = "La OV no puede retornar a Contacto";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    Button1_ModalPopupExtender.Show();
                    return;
                }

                if (ddlTipo.SelectedValue.Equals("P") &&
                    txtPopIntereses.Text.Trim().Length == 0 )
                {
                    lblEstadoPopup.Text = "Ingrese Intereses de la OV para convertir en Prospecto";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    Button1_ModalPopupExtender.Show();
                    return;
                }

                if (ddlTipo.SelectedValue.Equals("L") &&
                    ddlEstadoOferta.SelectedValue.Equals("N"))
                {
                    lblEstadoPopup.Text = "Indique estado de oferta para convertir en Cliente Potencial";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    Button1_ModalPopupExtender.Show();
                    return;
                }

                ContactoE obj = new ContactoE();
                obj.contactoId =lblModificarId.Text;
                obj.nombre = txtPopNombre.Text;
                obj.dni = txtPopDNI.Text;
                obj.tipo = ddlTipo.SelectedValue;
                obj.razonSocial = txtPopRazSoc.Text;
                obj.ruc = txtPopRUC.Text;
                obj.rubro = ddlRubro.SelectedItem.Text;
                obj.cargo = txtPopCargo.Text;
                obj.telefono = txtPopTelefono.Text;
                obj.email = txtPopEmail.Text;
                obj.intereses = txtPopIntereses.Text;
                obj.observaciones = txtPopObservaciones.Text;
                obj.estado_oferta = ddlEstadoOferta.SelectedValue;
                obj.direccion = txtPopDireccion.Text;

                bool salida = iActualizaOventaBL.Actualiza_Oventa(obj);

                if (salida)
                {

                    DataTable dt = new DataTable();
                    ContactoE obj2 = new ContactoE();
                    obj.razonSocial = txtRazSoc.Text;
                    obj.ruc = txtRUC.Text;

                    dt = iActualizaOventaBL.Consultar_Oventa(obj).Tables[0];

                    grdOventa.DataSource = dt;
                    grdOventa.DataBind();

                    lblEstadoGrabar.Text = "Se modifico correctamente";
                    lblEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");
                }
                else
                {
                    lblEstadoGrabar.Text = "No se modifico";
                    lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
                }
            }
            catch (Exception ex)
            {
                lblEstadoGrabar.Text = " " + ex.Message;
                lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
            } 
        }
    }
}
