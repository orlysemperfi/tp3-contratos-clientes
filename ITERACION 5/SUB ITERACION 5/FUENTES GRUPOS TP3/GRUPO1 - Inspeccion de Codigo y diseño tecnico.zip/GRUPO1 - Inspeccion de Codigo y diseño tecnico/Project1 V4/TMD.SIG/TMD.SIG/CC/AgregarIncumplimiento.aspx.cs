﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Entidades.CC;
using Negocio.CC;

namespace TMD.SIG.CC
{
    public partial class AgregarIncumplimiento : System.Web.UI.Page
    {
        #region Metodos
        private void LimpiarControles()
        {
            txtContrato.Text = "";
            txtNumeroContrato.Value = "";
            lblRazonSocial.Text = "";
            lblRuc.Text = "";

            txtDescripcion.Text = "";
            txtFecha.Text = "";

            ddlClausula.SelectedIndex = -1;
            txtMonto.Text = "";
            txtMotivo.Text = "";
            lblMonto.Text = "";
            lblEstado.Text = "";

            pnlIncumplimiento.Visible = false;

            Session["IncumplimientoClausulas"] = null;

            LimpiarGrilla(ref gridClausulasG);
            OcultarMostrarPanel(ref Panel1, gridClausulasG);
        }

        private void CargarComboClausula(string numero_contrato)
        {
            ddlClausula.Items.Clear();
            objClausulaBL.LLenarClausulasPenalidad(ref ddlClausula, numero_contrato);

            if (ddlClausula.Items.Count <= 0)
            {
                muestraMensaje("El contrato no tiene cláusulas de penalidad");
            }
        }

        private void muestraMensaje(string mensaje)
        {
            string Clientescript = ("<script>alert(\'" + mensaje + "\')</script>");
            if (!ClientScript.IsClientScriptBlockRegistered("WMensaje"))
            {
                this.ClientScript.RegisterClientScriptBlock(this.GetType(), "WMensaje", Clientescript);
            }
        }

        private void cambioCalendario(ref Calendar calendario)
        {
            if (calendario.Visible)
            { calendario.Visible = false; }
            else
            { calendario.Visible = true; }
        }

        void OcultarMostrarPanel(ref Panel pnlPanel, GridView gridGrilla)
        {
            if (gridGrilla.Rows.Count == 0)
                pnlPanel.Visible = true;
            else
                pnlPanel.Visible = false;
        }

        void LimpiarGrilla(ref GridView gridgrilla)
        {
            gridgrilla.DataSource = null;
            gridgrilla.DataBind();
        }

        #endregion

        #region Interfaces
        private IContratoBL objContratoBL = new ContratoBL();
        private IClausulaBL objClausulaBL = new ClausulaBL();
        private IIncumplimientoBL objIncumplimientoBL = new IncumplimientoBL();
        private IIncumplimientoClausulaBL objIncumplimientoClausulaBL = new IncumplimientoClausulaBL();
        
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                btnGrabar.Attributes.Add("onclick", "return confirm('¿Guardar registro?');");
                //CargarComboClausula();
                LimpiarControles();
            }             
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            string strContrato = txtContrato.Text.Trim();
            string descripcionEstado;
            
            if (strContrato.Length <= 0)
            {
                this.muestraMensaje("Ingreso el contrato");
            }
            else
            {
                ContratoE objContrato = new ContratoE();
                objContrato = objContratoBL.ObtenerContrato(strContrato);

                if (objContrato != null)
                {
                    txtNumeroContrato.Value = objContrato.CODIGO_CONTRATO.ToString();
                    lblRazonSocial.Text = objContrato.RAZONSOCIAL;
                    lblRuc.Text = objContrato.RUC;
                    Session["MontoContrato"] = objContrato.MONTO;
                    lblMonto.Text = objContrato.MONTO.ToString();

                    if (objContrato.ESTADO == "E") descripcionEstado = "ELABORADO";
                    else if (objContrato.ESTADO == "F") descripcionEstado = "FIRMADO";
                    else if (objContrato.ESTADO == "R") descripcionEstado = "RESCINDIDO";
                    else descripcionEstado = "CONCLUIDO";
                    lblEstado.Text = descripcionEstado;
                    if (objContrato.ESTADO != "F")
                    {
                        muestraMensaje("El contrato ingresado no es válido esta en Estado:" + descripcionEstado);
                        pnlIncumplimiento.Visible = false;
                    }
                    else
                    {
                        CargarComboClausula(txtNumeroContrato.Value.Trim());
                        pnlIncumplimiento.Visible = true;
                        txtDescripcion.Focus();
                    }
                }
                else
                {
                    muestraMensaje("No existe el contrato");
                }
            }            
        }

        protected void imgFecha_Click(object sender, ImageClickEventArgs e)
        {
            cambioCalendario(ref cldFecha);
        }

        protected void cldFecha_SelectionChanged(object sender, EventArgs e)
        {
            txtFecha.Text = cldFecha.SelectedDate.ToShortDateString();
            cambioCalendario(ref cldFecha);
        }

        private bool ClausulaRepetida()
        {
            int codigoClausula;
            codigoClausula = int.Parse(ddlClausula.SelectedValue);

            if (Session["IncumplimientoClausulas"] != null)
            {
                List<IncumplimientoClausulaE> lstIncumplimientoClausulas = new List<IncumplimientoClausulaE>();
                lstIncumplimientoClausulas = (List<IncumplimientoClausulaE>)HttpContext.Current.Session["IncumplimientoClausulas"];
                foreach (IncumplimientoClausulaE clausulaE in lstIncumplimientoClausulas)
                    if (clausulaE.Codigo_Clausula == codigoClausula) return true;
            }
            return false;
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            if (ddlClausula.SelectedIndex > 0 & txtMotivo.Text.Length > 0 & txtMonto.Text.Length > 0)
            {
                if (ClausulaRepetida())
                {
                    muestraMensaje("La cláusula seleccionada ya fue agregada.");
                }
                else
                {
                    IncumplimientoClausulaE objIncumplimientoClausula = new IncumplimientoClausulaE();
                    List<IncumplimientoClausulaE> lstIncumplimientoClausulas = new List<IncumplimientoClausulaE>();

                    objIncumplimientoClausula.Codigo_Clausula = int.Parse(ddlClausula.SelectedItem.Value);
                    objIncumplimientoClausula.Descripcion = ddlClausula.SelectedItem.Text;
                    objIncumplimientoClausula.Monto = decimal.Parse(txtMonto.Text);
                    objIncumplimientoClausula.Motivo = txtMotivo.Text;

                    if (Session["IncumplimientoClausulas"] == null)
                    {
                        lstIncumplimientoClausulas.Add(objIncumplimientoClausula);
                        HttpContext.Current.Session.Add("IncumplimientoClausulas", lstIncumplimientoClausulas);
                    }
                    else
                    {
                        lstIncumplimientoClausulas = (List<IncumplimientoClausulaE>)HttpContext.Current.Session["IncumplimientoClausulas"];
                        lstIncumplimientoClausulas.Add(objIncumplimientoClausula);
                        Session["IncumplimientoClausulas"] = lstIncumplimientoClausulas;
                    }

                    gridClausulasG.DataSource = lstIncumplimientoClausulas;
                    gridClausulasG.DataBind();

                    OcultarMostrarPanel(ref Panel1, gridClausulasG);

                    ddlClausula.SelectedIndex = 0;
                    txtMonto.Text = "";
                    txtMotivo.Text = "";
                    lblPenalidad.Text = "";

                    ddlClausula.Focus();
                }
            }
            else
            {
                muestraMensaje("Ingrese los datos obligatorios");
            }
        }

        protected void gridClausulasG_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            List<IncumplimientoClausulaE> lstIncumplimientoClasulas = new List<IncumplimientoClausulaE>();
            lstIncumplimientoClasulas = (List<IncumplimientoClausulaE>)HttpContext.Current.Session["IncumplimientoClausulas"];
            lstIncumplimientoClasulas.RemoveAt(e.RowIndex);
            if (lstIncumplimientoClasulas.Count == 0)
            {
                Session["IncumplimientoClausulas"] = null;
                LimpiarGrilla(ref gridClausulasG);
                OcultarMostrarPanel(ref Panel1, gridClausulasG);
            }
            else
            {
                Session["IncumplimientoClausulas"] = lstIncumplimientoClasulas;
                gridClausulasG.DataSource = lstIncumplimientoClasulas;
                gridClausulasG.DataBind();
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpiarControles();
        }

        protected void btnGrabar_Click(object sender, EventArgs e)
        {
            string strMensaje = "";

            if (txtDescripcion.Text.Trim() == "")
                strMensaje = "Ingresar la descripción del incumplimiento";
            if (txtFecha.Text.Trim() == "")
                strMensaje = "Ingresar la fecha de incumplimiento";
            if (gridClausulasG.Rows.Count == 0)
                strMensaje = "Ingresar las claúsulas de incumplimiento";

            if (strMensaje.Trim() != "")
                muestraMensaje(strMensaje);
            else
                RegistrarIncumplimiento();
        }

        private void RegistrarIncumplimiento()
        {
            try
            {
                int codigo_incumplimiento = 0;

                IncumplimientoE objIncumplimiento = new IncumplimientoE();

                objIncumplimiento.Codigo_Contrato = int.Parse(txtNumeroContrato.Value.Trim());
                objIncumplimiento.Descripcion = txtDescripcion.Text.Trim();
                objIncumplimiento.Fecha = Convert.ToDateTime(txtFecha.Text);

                objIncumplimientoBL.insertar(objIncumplimiento);

                codigo_incumplimiento = objIncumplimiento.Codigo_Incumplimiento;

                if (codigo_incumplimiento > 0)
                {
                    RegistrarClausulasIncumplimiento(codigo_incumplimiento);

                    muestraMensaje("Registro de contrato satisfactorio");

                    LimpiarControles();
                }
                else
                {
                    muestraMensaje("Error en registro de contrato, favor informar a soporte");
                }

            }
            catch (Exception ex) { muestraMensaje("Error al grabar Contrato: \n" + ex.Message); }    
        }

        private void RegistrarClausulasIncumplimiento(int codigo_incumplimiento)
        {
            if (Session["IncumplimientoClausulas"] != null)
            {
                List<IncumplimientoClausulaE> lista = new List<IncumplimientoClausulaE>();
                lista = (List<IncumplimientoClausulaE>)HttpContext.Current.Session["IncumplimientoClausulas"];

                foreach (IncumplimientoClausulaE obj in lista)
                {
                    objIncumplimientoClausulaBL.insertar(obj, codigo_incumplimiento);
                }
            }
        }

        protected void ddlClausula_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClausulaBL clausulaBL = new ClausulaBL();
            ClausulaE clausulaE = new ClausulaE();
            //string tipoClausula;

            clausulaE = clausulaBL.ClausulaxCodigo(int.Parse(ddlClausula.SelectedValue));
            txtMonto.Text = string.Empty;
            if (clausulaE.TIPO_SANCION == "1") lblPenalidad.Text = "UIT: " + clausulaE.SANCION.ToString() + " Unidades";
            else if (clausulaE.TIPO_SANCION == "2")
            {
                lblPenalidad.Text = "CONTRATO: " + clausulaE.SANCION.ToString() + "%";
                txtMonto.Text= Math.Round( double.Parse(((decimal)Session["MontoContrato"]).ToString()) * clausulaE.SANCION / 100.0,2).ToString();
            }
            else if (clausulaE.TIPO_SANCION == "3")
            {
                lblPenalidad.Text = "MONTO FIJO:" + clausulaE.SANCION.ToString();
                txtMonto.Text = clausulaE.SANCION.ToString();
            }
            else if (clausulaE.TIPO_SANCION == "4") lblPenalidad.Text = "ULTIMA FACTURA: " + clausulaE.SANCION.ToString() + "%";
        }
    }
}