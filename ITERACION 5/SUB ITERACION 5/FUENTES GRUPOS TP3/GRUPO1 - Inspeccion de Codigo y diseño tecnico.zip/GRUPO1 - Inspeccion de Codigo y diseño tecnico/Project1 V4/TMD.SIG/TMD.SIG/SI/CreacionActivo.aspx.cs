﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using Entidades.SI;
using Negocio.SI;

namespace TMD.SIG.SI
{
    public partial class CreacionActivo : System.Web.UI.Page
    {
        private ICreacionProcesoBL generic = new CreacionProcesoBL();
        private ICreacionActivoBL activos = new CreacionActivoBL();

        protected void Page_Load(object sender, EventArgs e)
        {
            //Cargar Propietario
            List<ResponsableControlE> lstPropie = generic.getListaResponsable();
            if (!IsPostBack)
            {
                this.ddlPropietario.Items.Clear();
                ddlPropietario.Items.Add(new ListItem { Value = "0", Text = "--Seleccione Propietario--" });
                foreach (ResponsableControlE L in lstPropie)
                {
                    ddlPropietario.Items.Add(new ListItem { Value = L.codResponsable.ToString(), Text = L.nomResponsable });
                }
            }
            //Cargar RPO
            List<TiempoInterrupcionE> lstTiempo = generic.getTiempoInterrupcion();
            if (!IsPostBack)
            {
                this.ddlRPO.Items.Clear();
                ddlRPO.Items.Add(new ListItem { Value = "0", Text = "--Seleccione RPO--" });
                foreach (TiempoInterrupcionE L in lstTiempo)
                {
                    ddlRPO.Items.Add(new ListItem { Value = L.codTiempo.ToString(), Text = L.nomTiempo });
                }
            }
            //Cargar Tipo Activo
            List<TipoActivoE> lstTipoActivo = generic.getListaTipoActivo();
            if (!IsPostBack)
            {
                this.ddlTipoActivo.Items.Clear();
                ddlTipoActivo.Items.Add(new ListItem { Value = "0", Text = "--Tipo Activo--" });
                foreach (TipoActivoE L in lstTipoActivo)
                {
                    ddlTipoActivo.Items.Add(new ListItem { Value = L.codTipoActivo, Text = L.nomTipoActivo });
                }
            }
            //Cargar Moneda
            List<MonedaE> lstMoneda = activos.getListaMonedas();
            if (!IsPostBack)
            {
                this.ddlMoneda.Items.Clear();
                ddlMoneda.Items.Add(new ListItem { Value = "0", Text = "--Seleccione Moneda--" });
                foreach (MonedaE L in lstMoneda)
                {
                    ddlMoneda.Items.Add(new ListItem { Value = L.codMoneda, Text = L.nomMoneda });
                }
            }
            //Cargar Activo Padre
            List<ActivoE> lstActivoPadre = activos.getListActivo();
            if (!IsPostBack)
            {
                this.ddlActivoPadre.Items.Clear();
                ddlActivoPadre.Items.Add(new ListItem { Value = "0", Text = "--Seleccione Activo--" });
                foreach (ActivoE L in lstActivoPadre)
                {
                    ddlActivoPadre.Items.Add(new ListItem { Value = L.codActivo.ToString(), Text = L.nomActivo });
                }
            }
        }

        protected void btnGrabar_Click(object sender, EventArgs e)
        {
            if(!txtCodigoActivo.Text.Equals("")
                && !txtNombreActivo.Text.Equals("")
                && ddlRPO.SelectedIndex != 0
                && ddlTipoActivo.SelectedIndex != 0){

                const string message = "Esta seguro de guardar el registro?";
                const string caption = "Guardar Activo";

                var result = MessageBox.Show(message, caption,
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);
                if(result == DialogResult.Yes)
                {
                    ActivoE act = new ActivoE();
                    act.codActivo = Convert.ToInt32(txtCodigoActivo.Text);
                    act.nomActivo = txtNombreActivo.Text;
                    act.ubicacion = txtUbicacion.Text;
                    act.costo = Convert.ToDecimal(txtCostoActivo.Text);

                    int retorno = activos.registrarActivo(act,
                        Convert.ToInt32(ddlPropietario.SelectedValue),
                        Convert.ToInt32(ddlRPO.SelectedValue),
                        ddlTipoActivo.SelectedValue,
                        ddlMoneda.SelectedValue,
                        Convert.ToInt32(ddlActivoPadre.SelectedValue));
                    if(retorno == 0){
                        var ok =MessageBox.Show("Se guardo satisfactoriamente el registro", "Guardado",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                        if(ok == DialogResult.OK){
                            limpiar();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Llene los campos obligatorios", "Guardando",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Stop);
            }
        }

        private void limpiar()
        {
            txtCodigoActivo.Text = "";
            txtNombreActivo.Text = "";
            ddlPropietario.SelectedIndex = 0;
            ddlRPO.SelectedIndex = 0;
            ddlTipoActivo.SelectedIndex = 0;
            txtUbicacion.Text = "";
            ddlMoneda.SelectedIndex = 0;
            txtCostoActivo.Text = "";
            ddlActivoPadre.SelectedIndex = 0;
        }
    }
}