﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.GD;
using Entidades.GD;
using TMD.SIG.Util;

namespace TMD.SIG.GD
{
    public partial class RegistroCompetenciaPersonal : System.Web.UI.Page
    {

        DataTable dt = new DataTable();
    

        private ICompetenciaPersonalBL forev = new CompetenciaPersonalBL();
        protected void Page_Load(object sender, EventArgs e)
        {

          

            if (!IsPostBack)
            {
                this.cbotipo.DataSource = forev.listadoCompetenciaIndicador();
                this.cbotipo.DataTextField = "DESCRIPCION_COMPETENCIA";
                this.cbotipo.DataValueField = "CODIGO_COMPETENCIA_INDICADOR";
                this.cbotipo.DataBind();

             
          
            }

        }

        protected void bntGrabar_Click(object sender, EventArgs e)
        {
            List<CompetenciaPersonalE> lista=new List<CompetenciaPersonalE>();
            CompetenciaPersonalE personal=new CompetenciaPersonalE() ;

            for (int i = 0; i < grillaniveles.Rows.Count; i++)
            {
                personal.CODIGO_COMPETENCIA_INDICADOR = Convert.ToInt32( cbotipo.SelectedValue.ToString());
                personal.DESCRIPCION_COMPETENCIA = txtdescripcion.Text;


                if(grillaniveles.Rows[i].Cells[0].Equals("1"))
                {
                    personal.NIVEL1 = grillaniveles.Rows[i].Cells[1].ToString();
                }

                if (grillaniveles.Rows[i].Cells[0].Equals("2"))
                {
                    personal.NIVEL2 = grillaniveles.Rows[i].Cells[1].ToString();
                }
                if (grillaniveles.Rows[i].Cells[0].Equals("3"))
                {
                    personal.NIVEL2 = grillaniveles.Rows[i].Cells[1].ToString();
                }
                if (grillaniveles.Rows[i].Cells[0].Equals("4"))
                {
                    personal.NIVEL2 = grillaniveles.Rows[i].Cells[1].ToString();
                }
                if (grillaniveles.Rows[i].Cells[0].Equals("5"))
                {
                    personal.NIVEL2 = grillaniveles.Rows[i].Cells[1].ToString();
                }
    
    


            }

        }

        protected void bntAGREGAR_Click(object sender, EventArgs e)
        {


            string descripcion = txtdescripcion.Text.Trim();
            string valor = cbonivel.SelectedValue.ToString ();


//DataTable dt = new DataTable();
            DataRow dr = dt.NewRow();

            dt.Columns.Add(" Nivel ");
            dt.Columns.Add(" Descripcion de Nivel ");
            dt.Columns.Add("Eliminar");

dr[0] = cbonivel.SelectedValue.ToString();
dr[1] = txtdescripcion.Text;
dt.Rows.Add(dr);

grillaniveles.DataSource = dt;
grillaniveles.DataBind();
          



        }

        protected void bntCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/GD/ListadoCompetenciaPersonal.aspx");
        }


   
    }
}