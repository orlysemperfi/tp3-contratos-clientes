﻿var vModificarProceso = false; 

function fxListaTipoProceso(wvSelect) {
    wv_peticion_http = getObjAjax();
    wv_peticion_http.onreadystatechange = function muestraRespuesta() {
        if (wv_peticion_http.readyState == 4) {
            if (wv_peticion_http.status == 200) {
                var sRespuesta = wv_peticion_http.responseText;
                divTipoProceso.innerHTML = sRespuesta;
                if (vModificarProceso) fxListaResponsable(vResponsable);
            } else {
                alert("Error al cargar Tipo de Proceso por favor vuelva a intentar en unos minutos.");
            }
        }
    }
    wv_peticion_http.open('GET', 'ConsultaProcesosAjx.aspx?wvAction=L&wvSelect=' + wvSelect, true);
    wv_peticion_http.send(null);
}

function fxListaProcesos() {
    objSelect = document.getElementById("selTipoProceso");
    objCodigo = document.getElementById("txtCodigo");

    wvTipoProceso       = objSelect.options[objSelect.selectedIndex].value;
    wvCodigoResponsable = objCodigo.value;
   
    wv_peticion_http = getObjAjax();
    wv_peticion_http.onreadystatechange = function muestraRespuesta() {
        if (wv_peticion_http.readyState == 4) {
            if (wv_peticion_http.status == 200) {
                var sRespuesta = wv_peticion_http.responseText;
                divResultadoListaProceso.innerHTML = sRespuesta;
            } else {
                alert("Error al hacer la Consulta de Procesos por favor vuelva a intentar en unos minutos.");
            }
        }
    }
    wv_peticion_http.open('GET', 'ConsultaProcesosAjx.aspx?wvAction=LP&wvTipoProceso=' + wvTipoProceso + '&wvCodigoResponsable=' + wvCodigoResponsable, true);
    wv_peticion_http.send(null);

}

function fxListaResponsable(wvSelect) {
    wv_peticion_http = getObjAjax();
    wv_peticion_http.onreadystatechange = function muestraRespuesta() {
        if (wv_peticion_http.readyState == 4) {
            if (wv_peticion_http.status == 200) {
                var sRespuesta = wv_peticion_http.responseText;
                divResponsable.innerHTML = sRespuesta;
                if (vModificarProceso)  fxListaMTD(vMTD);
            } else {
                alert("Error al cargar Responsable por favor vuelva a intentar en unos minutos.");
            }
        }
    }
    wv_peticion_http.open('GET', 'ConsultaProcesosAjx.aspx?wvAction=LR&wvSelect=' + wvSelect, true);
    wv_peticion_http.send(null);
}

function fxListaMTD(wvSelect) {
    wv_peticion_http = getObjAjax();
    wv_peticion_http.onreadystatechange = function muestraRespuesta() {
        if (wv_peticion_http.readyState == 4) {
            if (wv_peticion_http.status == 200) {
                var sRespuesta = wv_peticion_http.responseText;
                divMTD.innerHTML = sRespuesta;
                if (vModificarProceso) fxListaRTO(vRTO);
            } else {
                alert("Error al cargar Responsable por favor vuelva a intentar en unos minutos.");
            }
        }
    }
    wv_peticion_http.open('GET', 'ConsultaProcesosAjx.aspx?wvAction=MTD&wvSelect=' + wvSelect, true);
    wv_peticion_http.send(null);
}
function fxListaRTO(wvSelect) {
    wv_peticion_http = getObjAjax();
    wv_peticion_http.onreadystatechange = function muestraRespuesta() {
        if (wv_peticion_http.readyState == 4) {
            if (wv_peticion_http.status == 200) {
                var sRespuesta = wv_peticion_http.responseText;
                divRTO.innerHTML = sRespuesta;
                if (vModificarProceso) fxListaImpacto('0');
            } else {
                alert("Error al cargar RTO por favor vuelva a intentar en unos minutos.");
            }
        }
    }
    wv_peticion_http.open('GET', 'ConsultaProcesosAjx.aspx?wvAction=RTO&wvSelect=' + wvSelect, true);
    wv_peticion_http.send(null);
}
function fxListaTipoActivo(wvSelect) {
    wv_peticion_http = getObjAjax();
    wv_peticion_http.onreadystatechange = function muestraRespuesta() {
        if (wv_peticion_http.readyState == 4) {
            if (wv_peticion_http.status == 200) {
                var sRespuesta = wv_peticion_http.responseText;
                divTipoActivo.innerHTML = sRespuesta;
            } else {
                alert("Error al cargar Activo por favor vuelva a intentar en unos minutos.");
            }
        }
    }
    wv_peticion_http.open('GET', 'ConsultaProcesosAjx.aspx?wvAction=TA&wvSelect=' + wvSelect, true);
    wv_peticion_http.send(null);
}
function fxListaImpacto(wvSelect) {
    wv_peticion_http = getObjAjax();
    wv_peticion_http.onreadystatechange = function muestraRespuesta() {
        if (wv_peticion_http.readyState == 4) {
            if (wv_peticion_http.status == 200) {
                var sRespuesta = wv_peticion_http.responseText;
                divProcesoImpacto.innerHTML = sRespuesta;
            } else {
                alert("Error al cargar Impacto del Proceso por favor vuelva a intentar en unos minutos.");
            }
        }
    }
    wv_peticion_http.open('GET', 'ConsultaProcesosAjx.aspx?wvAction=PI&wvSelect=' + wvSelect, true);
    wv_peticion_http.send(null);
}

function fxModificarProceso() {
    if (confirm("¿Está seguro que desea modificar el registro?")) {
        var vwCODPROCESO = document.getElementById("MainContent_txtCodigoProceso").value;
        var vwNOMPROCESO = document.getElementById("MainContent_txtNombreProceso").value;
        var vwOBJPROCESO = document.getElementById("MainContent_txtObjetivo").value;

        var objSelTipoProceso = document.getElementById("selTipoProceso");
        var objSelRTO = document.getElementById("selRTO");
        var objSelMTD = document.getElementById("selMTD");
        var objSelResp = document.getElementById("selResponsable");

        var vwCODTIPOPROCESO = objSelTipoProceso.options[objSelTipoProceso.selectedIndex].value;
        var vwRTO = objSelRTO.options[objSelRTO.selectedIndex].value;
        var vwMTD = objSelMTD.options[objSelMTD.selectedIndex].value;
        var vwCODRESPONSABLE = objSelResp.options[objSelResp.selectedIndex].value;

        var sURL = "ConsultaProcesosAjx.aspx?wvAction=PU&vwCODPROCESO=" + vwCODPROCESO + "&vwNOMPROCESO=" + vwNOMPROCESO + "&vwOBJPROCESO=" + vwOBJPROCESO + "&vwCODTIPOPROCESO=" + vwCODTIPOPROCESO + "&vwRTO=" + vwRTO + "&vwMTD=" + vwMTD + "&vwCODRESPONSABLE=" + vwCODRESPONSABLE;
        wv_peticion_http = getObjAjax();
        wv_peticion_http.onreadystatechange = function muestraRespuesta() {
            if (wv_peticion_http.readyState == 4) {
                if (wv_peticion_http.status == 200) {
                    var sRespuesta = wv_peticion_http.responseText;
                    alert(sRespuesta);
                    //divProcesoImpacto.innerHTML = sRespuesta;
                } else {
                    alert("Error al cargar Impacto del Proceso por favor vuelva a intentar en unos minutos.");
                }
            }
        }
        wv_peticion_http.open('GET', sURL, true);
        wv_peticion_http.send(null);
    }
}

/*********************************************************
********************** UTIL ******************************
**********************************************************/
function Left(str, n) {
    if (n <= 0)
        return "";
    else if (n > String(str).length)
        return str;
    else
        return String(str).substring(0, n);
}
function Right(str, n) {
    if (n <= 0)
        return "";
    else if (n > String(str).length)
        return str;
    else {
        var iLen = String(str).length;
        return String(str).substring(iLen, iLen - n);
    }
}

function soloEntero(objeto, e) {         
    var keynum;
    var keychar;
    var numcheck;
    if (window.event) { /*/ IE*/
        keynum = e.keyCode
    } else if (e.which) { /*/ Netscape/Firefox/Opera/*/
        keynum = e.which
    }

    if ((keynum >= 35 && keynum <= 37) || keynum == 8 || keynum == 9 || keynum == 46 || keynum == 39) {
        return true;
    }

    if ((keynum >= 95 && keynum <= 105) || (keynum >= 48 && keynum <= 57)) {
        return true;
    } else {
        return false;
    }
}

function getObjAjax() {
    if (window.XMLHttpRequest) {
        wv_peticion_http = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        //wv_peticion_http = new ActiveXObject("Microsoft.XMLHTTP");
        wv_peticion_http = new ActiveXObject("MSXML2.XMLHTTP.3.0");
    }
    
    return wv_peticion_http;
}

var constNombreArchivo = "";
var constNombreArchivo_01 = "DOCUMENTO.DOC";
var constNombreArchivo_02 = "ULTIMOS_INGRESOS.PPT";
var constNombreArchivo_03 = "CAMBIOS_PUESTO.PPT";

function fxValidaNombre(avNombreArchivo, avConstante) {
    if (avConstante == 1) constNombreArchivo = constNombreArchivo_01;
    if (avConstante == 2) constNombreArchivo = constNombreArchivo_02;
    if (avConstante == 3) constNombreArchivo = constNombreArchivo_03;
    wvNombreArchivo = avNombreArchivo.split("\\");
    if (wvNombreArchivo.length > 1) {
        if (avConstante != 4) {
            if (wvNombreArchivo[wvNombreArchivo.length - 1].toUpperCase() != constNombreArchivo) {
                alert("El nombre debe ser " + constNombreArchivo);
                return false;
            } else {
                return true;
            }
        } else {
            var waExtension = Right(wvNombreArchivo[wvNombreArchivo.length - 1].toUpperCase(), 3);
            if (waExtension != "JPG" && waExtension != "GIF") {
                alert("Solo puede subir archivos JPG o GIF");
                return false;
            } else {
                return true;
            }
        }
    } else {
        return false;
    }
}