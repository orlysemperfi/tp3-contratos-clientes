﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;

namespace TMD.SIG.IC
{
    public partial class frmModCatalogo : System.Web.UI.Page
    {
        CatalagoChecklistE oCatalogoE = null;
        CatalogoCheckListBL oCatalogoBL = null;
        DetalleCheckListBL oDetalleBL = null;
        DetalleCheckListE oDetalleE = null;

        int Codigo=-1;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                txtDescripcion.Text = ((CatalagoChecklistE)Session["Catalogo"]).Descripcion;
                txtNombre.Text = ((CatalagoChecklistE)Session["Catalogo"]).Nombre;
                txtVersion.Text = ((CatalagoChecklistE)Session["Catalogo"]).Version;
                ddlPrioridad.SelectedValue = ((CatalagoChecklistE)Session["Catalogo"]).Prioridad;

                CargarDetalle();
                lbCriterioLista.DataBind();
                gvListar.DataBind();
            }

        }

        protected void btnGrabar_Click(object sender, EventArgs e)
        {
            if (lbCriterioAgregar.Items.Count > 0)
            {
                oCatalogoE = new CatalagoChecklistE();
                oCatalogoBL = new CatalogoCheckListBL();
                oDetalleBL = new DetalleCheckListBL();
                int CodigoCheckList;
                try
                {
                    oCatalogoE.Codigo = ((CatalagoChecklistE)Session["Catalogo"]).Codigo;
                    oCatalogoE.Nombre = txtNombre.Text.Trim();
                    oCatalogoE.Descripcion = txtDescripcion.Text.Trim();
                    oCatalogoE.Version = txtVersion.Text.Trim();
                    oCatalogoE.Prioridad = ddlPrioridad.SelectedValue;

                    //implementando logica de negocio
                    CodigoCheckList=oCatalogoBL.ModificarCatalogo(oCatalogoE);
                    Codigo = ((CatalagoChecklistE)Session["Catalogo"]).Codigo;

                    //implementado borrado
                    oDetalleBL.EliminarDetalle(new DetalleCheckListE() { CodigoCheckList = Codigo });

                   //Guardando Detalle
                    foreach (ListItem item in lbCriterioAgregar.Items)
                    {
                        oDetalleBL.Insertar(new DetalleCheckListE
                        {
                            CodigoCheckList = Codigo,
                            CodigoDetalle = int.Parse(item.Value),
                            Prioridad = ddlPrioridad.SelectedValue
                        });
                        
                    }

                    gvListar.DataBind();
                    //limpiarCasillas();
                    //lbCriterioAgregar.Items.Clear();
                    lblMensaje.Text = "Detalle modificado";
                }
                catch (Exception ex)
                {
                    lblMensaje.Text = ex.Message;
                }
            }
            else
                lblMensaje.Text = "Ingrese Detalle....";
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            oCatalogoE = new CatalagoChecklistE();
            oCatalogoBL = new CatalogoCheckListBL();
            try
            {
                //oCatalogoE.Codigo = txtNombre.Text.Trim();

                //implementando logica de negocio
                oCatalogoBL.Eliminar(oCatalogoE);
            }
            catch (Exception ex)
            {
                lblMensaje.Text = ex.Message;
            }
        }


        public void limpiarCasillas()
        {
            txtNombre.Text = "";
            txtDescripcion.Text = "";
            txtVersion.Text = "";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                ListItem item_ = new ListItem(lbCriterioLista.SelectedItem.Text,
                    lbCriterioLista.SelectedValue);

                lbCriterioAgregar.Items.Add(item_);
            }
            catch (Exception ex)
            {
            }
        }

        protected void btnQuitar_Click(object sender, EventArgs e)
        {
            try
            {
                lbCriterioAgregar.Items.RemoveAt(lbCriterioAgregar.SelectedIndex);
            }
            catch (Exception ex)
            {
                    
            }
        }

        protected void btnActualizar_Click(object sender, EventArgs e)
        {

        }

        protected void ObjectDataSource2_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
        {
            oDetalleE = new DetalleCheckListE();
            oDetalleE.CodigoCheckList = ((CatalagoChecklistE)Session["Catalogo"]).Codigo;
                if (!Page.IsPostBack)
                {
                    e.InputParameters["o"] = oDetalleE;
                }
                else
                {
                    oDetalleE.CodigoCheckList = Codigo;
                    e.InputParameters["o"] = oDetalleE;
                }

        }


        void LimpiarLista()
        {
            foreach (ListItem item in lbCriterioAgregar.Items)
            {
                lbCriterioAgregar.Items.Remove(item);

            }
        }

         void CargarDetalle()
        {
            oDetalleBL = new DetalleCheckListBL();
             List<DetalleCheckListE> oDetalle = oDetalleBL.ListAll(new DetalleCheckListE(){CodigoCheckList=((CatalagoChecklistE)Session["Catalogo"]).Codigo});
            foreach(DetalleCheckListE item in oDetalle)
            {
                ListItem item_ = new ListItem(item.CHECKLIST,item.CodigoDetalle.ToString());
                lbCriterioAgregar.Items.Add(item_);
            }
                
        }
    }
}