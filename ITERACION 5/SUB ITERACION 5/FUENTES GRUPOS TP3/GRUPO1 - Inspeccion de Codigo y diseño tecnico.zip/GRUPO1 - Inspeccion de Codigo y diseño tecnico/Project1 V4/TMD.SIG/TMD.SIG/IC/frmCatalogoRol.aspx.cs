﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;

namespace TMD.SIG.IC
{
    public partial class frmCatalogoRol : System.Web.UI.Page
    {
        CatalogoRolE oCatalogoE=null;
        CatalogoRolBL oCatalogoBL = null;
        //DetalleCheckListBL oDetalle = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
                gvCatalago.DataBind();
        }

        protected void btnGrabar_Click(object sender, EventArgs e)
        {
           
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            oCatalogoE = new CatalogoRolE();
            oCatalogoBL = new CatalogoRolBL();
            try
            {
                //oCatalogoE.Codigo = txtNombre.Text.Trim();

                //implementando logica de negocio

                oCatalogoBL.modificarestado(oCatalogoE);
            }
            catch (Exception ex)
            {
                //lblMensaje.Text = ex.Message;
            }
        }

        protected void btnAprobar_Click(object sender, EventArgs e)
        {
            oCatalogoBL = new CatalogoRolBL();
            oCatalogoE = new CatalogoRolE();
            oCatalogoE.Codigo = int.Parse(gvCatalago.SelectedRow.Cells[0].Text);
            oCatalogoE.Estado=gvCatalago.SelectedRow.Cells[4].Text;
            if (oCatalogoE.Estado.ToUpper() != "U" && oCatalogoE.Estado.ToUpper() != "P")
            {
                oCatalogoE.Estado = "O";
                oCatalogoBL.modificarestado(oCatalogoE);
                gvCatalago.DataBind();
            }
            else
                lblMensaje.Text = "No se puede Eliminar Catalogo se encuentra en uso";
        }

        protected void btnModifcar_Click(object sender, EventArgs e)
        {
            oCatalogoE = new CatalogoRolE();

            oCatalogoE.Codigo = int.Parse(gvCatalago.SelectedRow.Cells[0].Text);
            oCatalogoE.Descripcion = gvCatalago.SelectedRow.Cells[1].Text;
           

                Session["CatalogoRol"] = oCatalogoE;
                //oCatalogoBL.Eliminar(oCatalogoE);
                Response.Redirect("./frmModCatalogoRol.aspx");
                //gvCatalago.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            oCatalogoBL = new CatalogoRolBL();
            oCatalogoE = new CatalogoRolE();
            oCatalogoE.Codigo = int.Parse(gvCatalago.SelectedRow.Cells[0].Text);
            oCatalogoE.Estado = "A";
            if (gvCatalago.SelectedRow.Cells[3].Text == "P")
            {
                oCatalogoBL.modificarestado(oCatalogoE);
                gvCatalago.DataBind();
            }
            else
            {
                lblMensaje.Text = "No se puede Aprobar este Catalogo.";
            }
        }

        protected void gvCatalago_RowDataBound(object sender, GridViewRowEventArgs e)
        {
 
        }


    }
}