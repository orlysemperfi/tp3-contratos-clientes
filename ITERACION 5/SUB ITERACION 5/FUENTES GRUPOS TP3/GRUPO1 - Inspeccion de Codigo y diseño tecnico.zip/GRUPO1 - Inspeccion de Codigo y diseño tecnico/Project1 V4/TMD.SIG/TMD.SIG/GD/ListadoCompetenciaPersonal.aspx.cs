﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.GD;
using Entidades.GD;
using TMD.SIG.Util;


namespace TMD.SIG.GD
{
    public partial class ListadoCompetenciaPersonal : System.Web.UI.Page
    {

        private ICompetenciaPersonalBL forev = new CompetenciaPersonalBL();


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ListaCompetencia();
        
            }

        }

        protected void bntGrabar_Click(object sender, EventArgs e)
        {
            Response.Redirect("RegistroCompetenciaPersonal.aspx");
        }

        protected void grvListadoCompetencia_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
   
                Int32 _idCompetencia = int.Parse(GridView1.Rows[e.RowIndex].Cells[0].Text);
                Int32 vresult = forev.EliminarCompetencia(_idCompetencia);
                if (vresult == 1)
                {
                    ClientMessageBox.Show("Se realizó la eliminación exitosamente ", this);
                }
                if (vresult == 0)
                {
                    ClientMessageBox.Show("La competencia seleccionada tiene formulario asignado", this);
                }
                ListaCompetencia();
            
      
           
        }

        public void ListaCompetencia()
        {
            this.GridView1.DataSource = forev.listadoCompetencia();
            this.GridView1.DataBind();
        }


        protected void grvListadoCompetencia_RowEditing(object sender, GridViewEditEventArgs e)
        {


        
        }

        protected void bntCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/GD/GD_Index.aspx");
        }
    }
}