﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;

namespace TMD.SIG.IC
{
    public partial class frmCatalogo : System.Web.UI.Page
    {
        CatalagoChecklistE oCatalogoE=null;
        CatalogoCheckListBL oCatalogoBL = null;
        DetalleCheckListBL oDetalle = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                gvCatalago.DataBind();
        }

        protected void btnGrabar_Click(object sender, EventArgs e)
        {
           
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            oCatalogoE = new CatalagoChecklistE();
            oCatalogoBL = new CatalogoCheckListBL();
            try
            {
                //oCatalogoE.Codigo = txtNombre.Text.Trim();

                //implementando logica de negocio
                oCatalogoBL.Eliminar(oCatalogoE);
            }
            catch (Exception ex)
            {
                //lblMensaje.Text = ex.Message;
            }
        }

        protected void btnAprobar_Click(object sender, EventArgs e)
        {
            oCatalogoBL = new CatalogoCheckListBL();
            oCatalogoE = new CatalagoChecklistE();
            oCatalogoE.Codigo = int.Parse(gvCatalago.SelectedRow.Cells[0].Text);
            oCatalogoE.Estado=gvCatalago.SelectedRow.Cells[4].Text;
            //if (oCatalogoE.Estado.ToUpper() != "U" && oCatalogoE.Estado.ToUpper() != "P" && oCatalogoE.Estado.ToUpper() != "O")
            if (oCatalogoE.Estado.ToUpper() == "A" )
            {
                oCatalogoBL.Eliminar(oCatalogoE);
                gvCatalago.DataBind();
            }
            else
               // lblMensaje.Text = "No se puede eliminar catálogo porque se encuentra pendiente de aprobación";
            {
                if (gvCatalago.SelectedRow.Cells[4].Text.ToUpper() == "O")
                //if (oCatalogoE.Estado.ToUpper() == "O")
                {
                    lblMensaje.Text = "No se puede eliminar, Catálogo Obsoleto";
                }
                else
                    lblMensaje.Text = "No se puede eliminar Catálogo";
            }
        }

        protected void btnModifcar_Click(object sender, EventArgs e)
        {
            oCatalogoE = new CatalagoChecklistE();

            oCatalogoE.Codigo = int.Parse(gvCatalago.SelectedRow.Cells[0].Text);
            oCatalogoE.Nombre = gvCatalago.SelectedRow.Cells[1].Text;
            oCatalogoE.Descripcion = gvCatalago.SelectedRow.Cells[2].Text;
            oCatalogoE.Version = gvCatalago.SelectedRow.Cells[3].Text;
            oCatalogoE.Prioridad = gvCatalago.SelectedRow.Cells[7].Text;
            oCatalogoE.Estado=gvCatalago.SelectedRow.Cells[4].Text;

            //if (oCatalogoE.Estado.ToUpper() != "U" && oCatalogoE.Estado.ToUpper() != "P" && oCatalogoE.Estado.ToUpper() != "O")
            if (oCatalogoE.Estado.ToUpper() == "A" )
            {
                Session["Catalogo"] = oCatalogoE;
                //oCatalogoBL.Eliminar(oCatalogoE);
                Response.Redirect("./frmModCatalogo.aspx");
                //gvCatalago.DataBind();
            }
            else
                lblMensaje.Text = "No se puede Modificar Catalogo";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            oCatalogoBL = new CatalogoCheckListBL();
            oCatalogoE = new CatalagoChecklistE();
            oCatalogoE.Codigo = int.Parse(gvCatalago.SelectedRow.Cells[0].Text);
            oCatalogoE.Estado = gvCatalago.SelectedRow.Cells[4].Text;
            if (oCatalogoE.Estado.ToUpper() == "P")
            {
                oCatalogoBL.Aprobar(oCatalogoE);
                gvCatalago.DataBind();

                lblMensaje.Text = "Catalogo se aprobo.";
            }
            else
            {
                lblMensaje.Text = "No se puede aprobar Catalogo";
            }
        }


    }
}