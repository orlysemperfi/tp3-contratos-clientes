﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.GD;
using Entidades.GD;
using TMD.SIG.Util;

namespace TMD.SIG.GD
{
    public partial class Autoevaluacion : System.Web.UI.Page
    {
        private IFormularioCabeceraBL forcab = new FormularioCabeceraBL();
        private IFormularioDetalleBL fdet = new FormularioDetalleBL();
        List<FormularioDetalleE> formdet = new List<FormularioDetalleE>();
        private Int32 codemp = 1;
        private Int32 form = 1;
        string est;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request.QueryString["Tipo"] == null)
            {
                
                //if (forcab.VALIDA_EVALUACION(codemp, form, "Asignado")==0)
                //{
                //    Response.Redirect("~/GD/GD_Index.aspx?mensaje=1");
                //}

                //if (forcab.VALIDA_EVALUACION(codemp, form, "Registrado") == 0)
                //{
                //    Response.Redirect("~/GD/GD_Index.aspx?mensaje=2");
                //}
                //est = Request.QueryString["estado"];

                //if (forcab.VALIDA_EVALUACION(codemp, form, est) == 0)
                //{
                //    if (est.Equals("Asignado"))
                //    {
                //        Response.Redirect("~/GD/GD_Index.aspx?mensaje=1");
                //    }
                //    else
                //    {
                //        Response.Redirect("~/GD/GD_Index.aspx?mensaje=2");
                //    }
                    
                //}

                NUEVO();
            }
            else
            {
                LECTURA();
            }

        }

        protected void bntGrabar_Click(object sender, EventArgs e)
        {
            String sec1, sec2, sec3, sec4, sec5;

            sec1 = txtSec1.Text;
            sec1.Trim();

            sec2 = txtSec2.Text;
            sec2.Trim();

            sec3 = txtSec3.Text;
            sec3.Trim();

            sec4 = txtSec4.Text;
            sec4.Trim();

            sec5 = txtSec5.Text;
            sec5.Trim();

            if (sec1.Length == 0 || sec2.Length == 0 || sec3.Length == 0 || sec4.Length == 0 || sec5.Length == 0)
            {
                ClientMessageBox.Show("No ha completado todos los campos obligatorios", this);
                return;
            }




            for (int i = 0; i < formdet.Count; i++)
            {
                if (formdet[i].CODIGO_SECCION_DETALLE == 1)
                {
                    fdet.InsertarAuto(form, codemp, formdet[i].CODIGO_SECCION, formdet[i].CODIGO_SECCION_DETALLE, txtSec1.Text);
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 2)
                {
                    fdet.InsertarAuto(form, codemp, formdet[i].CODIGO_SECCION, formdet[i].CODIGO_SECCION_DETALLE, txtSec2.Text);
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 3)
                {
                    fdet.InsertarAuto(form, codemp, formdet[i].CODIGO_SECCION, formdet[i].CODIGO_SECCION_DETALLE, txtSec3.Text);
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 4)
                {
                    fdet.InsertarAuto(form, codemp, formdet[i].CODIGO_SECCION, formdet[i].CODIGO_SECCION_DETALLE, txtSec4.Text);
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 5)
                {
                    fdet.InsertarAuto(form, codemp, formdet[i].CODIGO_SECCION, formdet[i].CODIGO_SECCION_DETALLE, txtSec5.Text);
                }



            }

            fdet.Actualizar(form, codemp, lblFRegistro.Text.ToString(), "Registrado");
            Response.Redirect("~/GD/GD_Index.aspx?mensaje=3");  

        }


        private void NUEVO()
        {
            FormularioCabeceraE frc = new FormularioCabeceraE();
            frc = forcab.llenarCabecera(codemp);
            lblNombre.Text = frc.EVALUADO;
            lblCodigo.Text = frc.CODIGO_EMPLEADO.ToString();
            lblRol.Text = frc.ROL;
            lblProyecto.Text = frc.PROYECTO;
            lblFRecepcion.Text = frc.FRECEPCION;
            lblFRegistro.Text = frc.FECHA;
            lblEvaluador.Text = frc.EVALUADOR;


            formdet = fdet.ListaDetalle(codemp, form);

            for (int i = 0; i < formdet.Count; i++)
            {
                if (formdet[i].CODIGO_SECCION_DETALLE == 1)
                {
                    lblSecA.Text = formdet[i].SECCION;
                    lblSec1.Text = formdet[i].SECCION_DETALLE;
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 2)
                {
                    lblSec2.Text = formdet[i].SECCION_DETALLE;
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 3)
                {
                    lblSecB.Text = formdet[i].SECCION;
                    lblSec3.Text = formdet[i].SECCION_DETALLE;
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 4)
                {
                    lblSec4.Text = formdet[i].SECCION_DETALLE;
                }

                if (formdet[i].CODIGO_SECCION_DETALLE == 5)
                {
                    lblSec5.Text = formdet[i].SECCION_DETALLE;
                }


            }
        }

        private void LECTURA()
        {
             FormularioCabeceraE frc = new FormularioCabeceraE();
                frc = forcab.llenarCabeceraC(1);
                lblNombre.Text = frc.EVALUADO;
                lblCodigo.Text = frc.CODIGO_EMPLEADO.ToString();
                lblRol.Text = frc.ROL;
                lblProyecto.Text = frc.PROYECTO;
                lblFRecepcion.Text = frc.FRECEPCION;
                lblFRegistro.Text = frc.FECHA;
                lblEvaluador.Text = frc.EVALUADOR;

                List<FormularioDetalleE> formdet = new List<FormularioDetalleE>();
                formdet = fdet.ListaDetalleCLF(2);

                for (int i = 0; i < formdet.Count; i++)
                {
                    if (formdet[i].CODIGO_SECCION_DETALLE == 1)
                    {
                        lblSecA.Text = formdet[i].SECCION;
                        lblSec1.Text = formdet[i].SECCION_DETALLE;
                        txtSec1.Text = formdet[i].VALOR_CAMPO;
                        txtSec1.Enabled = false;
                    }

                    if (formdet[i].CODIGO_SECCION_DETALLE == 2)
                    {
                        lblSec2.Text = formdet[i].SECCION_DETALLE;
                        txtSec2.Text = formdet[i].VALOR_CAMPO;
                        txtSec2.Enabled = false;
                    }

                    if (formdet[i].CODIGO_SECCION_DETALLE == 3)
                    {
                        lblSecB.Text = formdet[i].SECCION;
                        lblSec3.Text = formdet[i].SECCION_DETALLE;
                        txtSec3.Text = formdet[i].VALOR_CAMPO;
                        txtSec3.Enabled = false;
                    }

                    if (formdet[i].CODIGO_SECCION_DETALLE == 4)
                    {
                        lblSec4.Text = formdet[i].SECCION_DETALLE;
                        txtSec4.Text = formdet[i].VALOR_CAMPO;
                        txtSec4.Enabled = false;
                    }

                    if (formdet[i].CODIGO_SECCION_DETALLE == 5)
                    {
                        lblSec5.Text = formdet[i].SECCION_DETALLE;
                        txtSec5.Text = formdet[i].VALOR_CAMPO;
                        txtSec5.Enabled = false;
                    }
                }

                bntGrabar.Visible = false;
        }

        protected void bntCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/GD/GD_Index.aspx");
        }


    }

 
}