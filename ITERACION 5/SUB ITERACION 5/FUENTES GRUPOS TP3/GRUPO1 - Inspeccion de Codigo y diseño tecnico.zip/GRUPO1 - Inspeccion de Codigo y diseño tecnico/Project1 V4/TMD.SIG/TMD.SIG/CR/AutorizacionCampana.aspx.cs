﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Negocio.CR;
using Entidades.CR;

namespace TMD.SIG.CR
{
    public partial class AutorizacionCampana : System.Web.UI.Page
    {
        IAutorizacionCampanaBL iAutorizacionCampanaBL = new AutorizacionCampanaBL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ddlListaMarketing.DataSource = iAutorizacionCampanaBL.ObtenerListaMarketing();
                ddlListaMarketing.DataTextField = "nombre";
                ddlListaMarketing.DataValueField = "listaMarketingId";
                ddlListaMarketing.DataBind();

                ddlAsesor.DataSource = iAutorizacionCampanaBL.ObtenerAsesores();
                ddlAsesor.DataTextField = "nombre";
                ddlAsesor.DataValueField = "personaId";
                ddlAsesor.DataBind();
            }
        }

        protected void btnFiltrar_Click(object sender, EventArgs e)
        {
            Filtrar();
        }

        private void Filtrar() {
            try
            {
                if (dtpDesde.Text.Trim().Length != 0 && dtpHasta.Text.Trim().Length != 0)
                {
                    DateTime fecInicio = DateTime.ParseExact(dtpDesde.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);
                    DateTime fecFin = DateTime.ParseExact(dtpHasta.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);


                    TimeSpan restFecha = fecInicio - fecFin;
                    if (restFecha.TotalDays > 0)
                    {
                        lblEstadoGrabar.Text = " La fecha fin debe ser mayor que la fecha de inicio";
                        lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
                        return;
                    }
                }

                DataTable dt = new DataTable();
                CampanaCaptacionE obj = new CampanaCaptacionE();
                obj.nombre = txtNombreCamapaña.Text;
                obj.fechaInicio = dtpDesde.Text;
                obj.fechaFin = dtpHasta.Text;
                obj.estado = "C";

                dt = iAutorizacionCampanaBL.ConsultarCampana_Captacion_Estado(obj).Tables[0];

                grdCampaña.DataSource = dt;
                grdCampaña.DataBind();
                lblEstadoGrabar.Text = grdCampaña.Rows.Count.ToString() + " resultado(s) encontrado(s)";
                lblEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");
            }
            catch (Exception ex)
            {
                lblEstadoGrabar.Text = " " + ex.Message;
                lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
            }
        }
           
        protected void lnkItemName_Click(object sender, EventArgs e)
        {
            Button1_ModalPopupExtender.Show();
        }

        protected void grdCampaña_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            String idCampanaActual = e.CommandArgument.ToString();
            lblModificarId.Text = idCampanaActual;

            DataTable dt = new DataTable();
            dt = iAutorizacionCampanaBL.BuscaCampana_Captacion(Convert.ToInt32(idCampanaActual)).Tables[0];

            lblTitulo.Text = "Autorizar/Rechazar - Campaña de Campaña de Captación";
            lblEstadoPopup.Text = "";
            
            btnModificar.Visible = true;
            

            DateTime fecInicioSol = DateTime.ParseExact(dt.Rows[0][2].ToString(), "dd/MM/yyyy",  System.Globalization.CultureInfo.CurrentCulture);
            DateTime fecFinSol = DateTime.ParseExact(dt.Rows[0][3].ToString(), "dd/MM/yyyy",  System.Globalization.CultureInfo.CurrentCulture);

            String fecInicioSolString = fecInicioSol.ToString("yyyy-MM-dd");
            String fecFinSolString = fecFinSol.ToString("yyyy-MM-dd");

            txtPopNombreCampaña.Text = dt.Rows[0][1].ToString();
            txtPopFecInicio.Text = fecInicioSolString;
            txtPopFecFin.Text = fecFinSolString;
            txtPopPresupuestoPlanificado.Text = dt.Rows[0][5].ToString();
           
            txtPopObjetivos.Text= dt.Rows[0][8].ToString();
            txtPopObservaciones.Text = dt.Rows[0][9].ToString();
            
            lblTextoEstado.Text = dt.Rows[0][7].ToString();
            ddlListaMarketing.SelectedValue = dt.Rows[0][10].ToString();

            SetearCampos();
        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            CampanaCaptacionE obj = new CampanaCaptacionE();
            obj.campanaCaptacionId = Convert.ToInt32(lblModificarId.Text);
            String mensaje = "";

            if (rbtn_autorizar.SelectedValue == "001")
            {
                obj.codigoUsuarioAsesor = ddlAsesor.SelectedItem.Value;
                iAutorizacionCampanaBL.AutorizarCampana_Captacion(obj);
                mensaje = " La Campaña " + txtPopNombreCampaña.Text + " ha sido Autorizada Satisfactoriamente ";
            }
            else
            {
                String cadena = "";
                bool valida = false;

                if (tbMotivo.Text.Trim().Length == 0)
                {
                    cadena += "El Motivo del Rechazo es requerido";
                    valida = true;
                }

                if (valida) {

                    lblEstadoPopup.Text = cadena;
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    Button1_ModalPopupExtender.Show();
                    return;
                
                }

                obj.motivoRechazo = tbMotivo.Text;
                iAutorizacionCampanaBL.RechazarCampana_Captacion(obj);
                mensaje = " La Campaña " + txtPopNombreCampaña.Text + " ha sido Rechazada ";
            }

            Filtrar();

            lblEstadoGrabar.Text = mensaje;
            lblEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");
            
        }

        private void SetearCampos() 
        {
            txtPopNombreCampaña.Enabled = false;
            txtPopFecInicio.Enabled = false;
            txtPopFecFin.Enabled = false;
            txtPopPresupuestoPlanificado.Enabled = false;
            txtPopObjetivos.Enabled = false;
            txtPopObservaciones.Enabled = false;
            ddlListaMarketing.Enabled = false;

            lbAsesor.Visible = true;
            ddlAsesor.Visible = true;
            

            lbMotivo.Visible = false;
            tbMotivo.Visible = false;
            tbMotivo.Text = "";

            rbtn_autorizar.SelectedValue = "001";
                    
        }

        protected void btnSalir_Click(object sender, EventArgs e)
        {
            Button1_ModalPopupExtender.Hide();
        }

        protected void rbtn_reemplazar_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rbtn_autorizar.SelectedValue == "001")
            {
                lbAsesor.Visible = true;
                ddlAsesor.Visible = true;

                lbMotivo.Visible = false;
                tbMotivo.Visible = false;

                Button1_ModalPopupExtender.Show();
            }
            else
            {
                lbAsesor.Visible = false;
                ddlAsesor.Visible = false;

                lbMotivo.Visible = true;
                tbMotivo.Visible = true;

                Button1_ModalPopupExtender.Show();
            }
        }
    }
}
