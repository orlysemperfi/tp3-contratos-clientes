﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using Negocio.SI;
using Entidades.SI;

namespace TMD.SIG.SI
{
    public partial class VerificacionControl : System.Web.UI.Page
    {
        private IVerificacionBL verificacionBL = new VerificacionBL();

        protected void Page_Load(object sender, EventArgs e)
        {
            //Cargar Politica
            List<PoliticaE> lstPolitica = verificacionBL.getListaPoliticas();
            if(!IsPostBack){
                ddlPolitica.Items.Clear();
                ddlPolitica.Items.Add(new ListItem { Value = "0", Text = "--Seleccione codigo--" });
                foreach (PoliticaE L in lstPolitica)
                {
                    ddlPolitica.Items.Add(new ListItem { Value = L.nomPolitica, Text = L.codPolitica.ToString() });
                }
            }

        }

        protected void ddlPolitica_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.txtNombrePolitica.Text = ddlPolitica.SelectedValue.ToString();
            if (!ddlPolitica.SelectedValue.ToString().Equals("0"))
            {
                List<ControlE> lstControl = verificacionBL.getListaControles(Convert.ToInt32(ddlPolitica.SelectedItem.Text));
                txtCodPoli.Text = ddlPolitica.SelectedItem.Text;
                ddlControl.Items.Clear();
                ddlControl.Items.Add(new ListItem { Value = "0", Text = "--Seleccione Control--" });
                foreach (ControlE C in lstControl)
                {
                    ddlControl.Items.Add(new ListItem { Value = C.nomControl, Text = C.codControl.ToString() });
                }
            }
            else
            {
                limpiar();
            }

        }

        protected void ddlControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.txtNombreControl.Text = ddlControl.SelectedValue.ToString();
            List<ControlE> lstControl = verificacionBL.getListaControles(Convert.ToInt32(ddlPolitica.SelectedItem.Text));
            int codEmpleado = 0;
            foreach(ControlE C in lstControl){
                if(ddlControl.SelectedItem.Text.Equals(C.codControl.ToString())){
                    txtCodCtrl.Text = C.codControl.ToString();
                    codEmpleado = C.codEmpleado;
                    break;
                }
            }
            ResponsableControlE resp = verificacionBL.getResponsableControl(codEmpleado);
            this.txtCodigoResponsable.Text = resp.codResponsable.ToString();
            this.txtNombreResponsable.Text = resp.nomResponsable;
        }

        private void limpiar()
        {
            this.txtNombrePolitica.Text = "";
            this.ddlControl.Items.Clear();
            this.ddlPolitica.SelectedIndex = 0;
            this.txtNombreControl.Text = "";
            this.txtCodigoResponsable.Text = "";
            this.txtNombreResponsable.Text = "";
            this.txtFechaDesde.Text = "";
            this.txtFechaHasta.Text = "";
            this.txtCodCtrl.Text = "";
            this.txtCodPoli.Text = "";
            this.lbMensaje.Text = "No se encontraron resultados";
            this.GridViewVerificaciones.DataSource = null;
            this.GridViewVerificaciones.DataBind();
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
             if (ddlPolitica.SelectedIndex != 0
                && !txtCodCtrl.Text.Equals(""))
            {
                List<VerificacionE> lstVerificacion = verificacionBL.getListaVerificacion(
                    Convert.ToInt32(this.ddlControl.SelectedItem.Text),
                    this.txtFechaDesde.Text,
                    this.txtFechaHasta.Text
                    );
                if (lstVerificacion != null && lstVerificacion.Count > 0)
                {
                    this.lbMensaje.Text = "Se encontraron " + lstVerificacion.Count + " resultados";
                    this.GridViewVerificaciones.DataSource = lstVerificacion;
                    this.GridViewVerificaciones.DataBind();
                }
                else
                {
                    this.lbMensaje.Text = "No se encontraron resultados";
                    this.GridViewVerificaciones.DataSource = null;
                    this.GridViewVerificaciones.DataBind();
                }
            }
             else
             {
                 MessageBox.Show("LLene los campos obligatorios", "Registrar",
                   MessageBoxButtons.OK,
                   MessageBoxIcon.Stop);
             }
        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }

        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (ddlPolitica.SelectedIndex != 0
                && !txtCodCtrl.Text.Equals(""))
            {
                Response.Redirect("RegistrarVerificacionControl.aspx?codCtrl=" + txtCodCtrl.Text + "&codPoli=" + txtCodPoli.Text);
            }
            else
            {
                MessageBox.Show("LLene los campos obligatorios", "Registrar",
                  MessageBoxButtons.OK,
                  MessageBoxIcon.Stop);
            }
        }

        
    }
}