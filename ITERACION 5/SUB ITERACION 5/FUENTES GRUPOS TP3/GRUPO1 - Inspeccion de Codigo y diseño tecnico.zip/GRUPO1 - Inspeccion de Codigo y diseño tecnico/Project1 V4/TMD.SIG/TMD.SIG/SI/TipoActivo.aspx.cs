﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.SI;
using Entidades.SI;

namespace TMD.SIG.SI
{
    public partial class TipoActivo : System.Web.UI.Page
    {
        private ITipoActivoBL activoBL = new TipoActivoBL();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            TipoActivoE activoEnt = new TipoActivoE();
            activoEnt.codigo = this.txtCodigo.Text;
            activoEnt.nombre = this.txtNombre.Text;

            activoBL.insertar(activoEnt);
        }
    }
}