﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.GD;
using Entidades.GD;

namespace TMD.SIG.GD
{
    public partial class FormularioEvaluacionL : System.Web.UI.Page
    {
        private IFormularioEvaluacionEmpleadoBL forev = new FormularioEvaluacionEmpleadoBL();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            this.GridView1.DataSource = forev.listAll();
            this.GridView1.DataBind();
        }

        protected void Calificacion_Click(object sender, EventArgs e)
        {
            string emp = ((LinkButton)sender).CommandArgument.ToString();
            Response.Redirect("../GD/Calificacion.aspx?emp='" + emp + "'");
        }



  
    }
}