﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;

namespace TMD.SIG.IC
{
    public partial class frmCatalogoStdProg : System.Web.UI.Page
    {
        EstandarBL oEstandarBL = null;
        EstandaresE oEstandarE = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack ) 
                gvLsProgram.DataBind();
            
        }

        protected void btnNuevo_Click(object sender, EventArgs e)
        {

        }


        protected void ObjectDataSource1_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
        {
            oEstandarE = new EstandaresE();
            oEstandarBL = new EstandarBL();
            if (!Page.IsPostBack)
            {
                oEstandarE.Estado = "A";
                e.InputParameters["o"] = oEstandarE;
            }
            else
            {
                oEstandarE.Estado = "0";
                e.InputParameters["o"] = oEstandarE;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                gvLsProgram.DataBind();
            }
            catch(Exception ex)
            {
            }
        }

      
    }
}