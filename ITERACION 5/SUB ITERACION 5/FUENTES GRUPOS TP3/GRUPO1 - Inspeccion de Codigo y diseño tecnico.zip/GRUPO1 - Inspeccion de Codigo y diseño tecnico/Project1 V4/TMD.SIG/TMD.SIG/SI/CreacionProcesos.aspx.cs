﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using Entidades.SI;
using Negocio.SI;

namespace TMD.SIG.SI
{
    public partial class CreacionProcesos : System.Web.UI.Page
    {
        private ICreacionProcesoBL creacionBL = new CreacionProcesoBL();
        private List<ActivoE> lstActivo = new List<ActivoE>();

        protected void Page_Load(object sender, EventArgs e)
        {
            //Cargar TipoProceso
            List<TipoProcesoE> lstTipoProc = creacionBL.getListaTipoProceso();
            if (!IsPostBack)
            {
                this.ddlTipoProceso.Items.Clear();
                ddlTipoProceso.Items.Add(new ListItem { Value = "0", Text = "--Seleccione Tipo Proceso--" });
                foreach (TipoProcesoE L in lstTipoProc)
                {
                    ddlTipoProceso.Items.Add(new ListItem { Value = L.codTipoProceso.ToString(), Text = L.nomTipoProceso });
                }
            }
            //Cargar Responsable
            List<ResponsableControlE> lstResp = creacionBL.getListaResponsable();
            if (!IsPostBack)
            {
                this.ddlResponsable.Items.Clear();
                ddlResponsable.Items.Add(new ListItem { Value = "0", Text = "--Seleccione Responsable--" });
                foreach (ResponsableControlE L in lstResp)
                {
                    ddlResponsable.Items.Add(new ListItem { Value = L.codResponsable.ToString(), Text = L.nomResponsable });
                }
            }
            //Cargar Tiempo Interrupcion
            List<TiempoInterrupcionE> lstTiempInterr = creacionBL.getTiempoInterrupcion();
            if (!IsPostBack)
            {
                this.ddlMtd.Items.Clear();
                this.ddlRto.Items.Clear();
                ddlMtd.Items.Add(new ListItem { Value = "0", Text = "--Seleccione MTD--" });
                ddlRto.Items.Add(new ListItem { Value = "0", Text = "--Seleccione RTO--" });
                foreach (TiempoInterrupcionE L in lstTiempInterr)
                {
                    ddlMtd.Items.Add(new ListItem { Value = L.codTiempo.ToString(), Text = L.nomTiempo});
                    ddlRto.Items.Add(new ListItem { Value = L.codTiempo.ToString(), Text = L.nomTiempo });
                }
            }
            //Cargar Tipo Impacto
            List<TipoImpactoE> lstTipoImpacto = creacionBL.getListaTipoImpacto();
            List<PrioridadImpactoE> lstPriorid = creacionBL.getListPrioridadImpacto();

            int i = 0;
            foreach(TipoImpactoE I in lstTipoImpacto){
                TableRow fila = new TableRow();

                TableCell colum1 = new TableCell();
                colum1.Controls.Add(new LiteralControl(I.codTipoImpacto.ToString()));
                fila.Cells.Add(colum1);

                TableCell colum2 = new TableCell();
                colum2.Controls.Add(new LiteralControl(I.nomTipoImpacto));
                fila.Cells.Add(colum2);

                TableCell colum3 = new TableCell();
                
                DropDownList ddlPrio = new DropDownList();
                    ddlPrio.ID = "ddlPrio" + i.ToString(); 
                    ddlPrio.Items.Clear();
                    foreach (PrioridadImpactoE L in lstPriorid)
                    {
                        ddlPrio.Items.Add(new ListItem { Value = L.codValor.ToString(), Text = L.descripValor });
                    }
                
                colum3.Controls.Add(ddlPrio);
                fila.Cells.Add(colum3);

                this.tblImpacto.Rows.Add(fila);
                i++;
            }
            
        }
        
        
        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (!txtNombreProceso.Text.Equals("")
                && ddlRto.SelectedIndex != 0
                && ddlMtd.SelectedIndex != 0
                && ddlTipoProceso.SelectedIndex != 0
                && ddlResponsable.SelectedIndex != 0 
                )
            {

                const string message = "Esta seguro de guardar el registro?";
                const string caption = "Guardar Proceso";

                var result = MessageBox.Show(message, caption,
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    ProcesoE proc = new ProcesoE();
                    proc.nomProceso = txtNombreProceso.Text;
                    proc.codTipoProceso = Convert.ToInt32(ddlTipoProceso.SelectedValue);
                    proc.objetivo = txtObjetivoProceso.Text;
                    proc.rto = Convert.ToInt32(ddlRto.SelectedValue);
                    proc.mtd = Convert.ToInt32(ddlMtd.SelectedValue);
                    proc.codResp = Convert.ToInt32(ddlResponsable.SelectedValue);

                    int codProceso = creacionBL.registrarProceso(proc);
                    List<TipoImpactoE> listaImp = creacionBL.getListaTipoImpacto();

                    if (codProceso > 0)
                    {
                        //Graba Impacto
                        int i = 0;
                        foreach (TipoImpactoE E in listaImp)
                        {
                            /**/
                            DropDownList ddl = new DropDownList();
                            if (Page.Master != null)
                            {
                                foreach (System.Web.UI.Control control in Page.Master.Controls)
                                {
                                    foreach (System.Web.UI.Control controlform in control.Controls)
                                    {
                                        if (controlform is ContentPlaceHolder)
                                        {
                                            ddl = (DropDownList)controlform.FindControl("ddlPrio" + i.ToString());
                                            if (ddl != null)
                                                break;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                ddl = (DropDownList)Page.FindControl("ddlPrio" + i.ToString());
                            }
                            /**/
                            creacionBL.registrarProcesoImpacto(codProceso, E.codTipoImpacto, Convert.ToInt32(ddl.SelectedValue));
                            i++;
                        }
                        //Mensage Success
                        var gg = MessageBox.Show("El proceso ha sido grabado satisfactoriamente", "Guardado con exito",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                        if (gg == DialogResult.OK)
                        {
                            limpiar();
                        }
                    }
                }

            }
            else
            {
                MessageBox.Show("Llene los campos obligatorios (*)", "Guardando",
                MessageBoxButtons.OK,
                MessageBoxIcon.Stop);
            }
        }

        
        private void limpiar()
        {
            this.txtNombreProceso.Text = "";
            this.txtObjetivoProceso.Text = "";
            ddlTipoProceso.SelectedIndex = 0;
            ddlResponsable.SelectedIndex = 0;
            ddlMtd.SelectedIndex = 0;
            ddlRto.SelectedIndex = 0;

        }

      }
}