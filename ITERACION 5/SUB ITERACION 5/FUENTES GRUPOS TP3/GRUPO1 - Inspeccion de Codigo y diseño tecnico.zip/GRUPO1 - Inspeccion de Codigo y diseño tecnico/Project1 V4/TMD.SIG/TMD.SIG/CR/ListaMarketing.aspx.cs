﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;
using Negocio.CR;
using Entidades.CR;

namespace TMD.SIG.CR
{
    public partial class ListaMarketing : System.Web.UI.Page
    {
        IListaMarketingBL iListaMarketingBL = new ListaMarketingBL();

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
                try
                {
                    List<ContactoE> contactos = new List<ContactoE>();

                     using (StreamReader sr = new StreamReader(FileUpload1.PostedFile.InputStream, false))
                    {
 
                        String linea;
                        while((linea = sr.ReadLine()) != null){
                            string[] data = linea.Split(',');
                            ContactoE obj = new ContactoE();
                            obj.nombre =data[0];
                            obj.dni =data[1];
                            obj.razonSocial =data[2];
                            obj.ruc =data[3];
                            obj.categoria =data[4];
                            obj.rubro =data[5];
                            obj.cargo =data[6];
                            obj.telefono =data[7];
                            obj.email =data[8];
                            obj.observaciones =data[9];
                            obj.direccion = data[10];
                            obj.tipo = data[11];

                            contactos.Add(obj);
                        }
                    }

                    ListaMarketingE objLista = new ListaMarketingE();
                    objLista.nombre = txtNombre.Text.Trim();
                    int salida = iListaMarketingBL.InsertarListaMarketing(contactos, objLista);
                    if (salida != -1)
                    {
                        lblEstadoGrabar.Text = "Se registro correctamente " + contactos.Count +" elementos";
                        lblEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");

                        DataTable dt = new DataTable();
                        ListaMarketingE obj = new ListaMarketingE();
                        obj.listaMarketingId = salida;

                        dt = iListaMarketingBL.ConsultarLista_de_Marketing(obj).Tables[0];

                        grdListaMarketing.DataSource = dt;
                        grdListaMarketing.DataBind();

                    }else
                    {
                        lblEstadoGrabar.Text = "No se registro el contenido de " + FileUpload1.PostedFile.FileName;
                        lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;

                    }
                   
                }
                catch (Exception ex)
                {
                    lblEstadoGrabar.Text = "Archivo no valido para la carga " + ex.Message;
                    lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;

                }
            else
            {
                lblEstadoGrabar.Text = "No se ha especificado un archivo";
                lblEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");

            }
        }
    }
}
