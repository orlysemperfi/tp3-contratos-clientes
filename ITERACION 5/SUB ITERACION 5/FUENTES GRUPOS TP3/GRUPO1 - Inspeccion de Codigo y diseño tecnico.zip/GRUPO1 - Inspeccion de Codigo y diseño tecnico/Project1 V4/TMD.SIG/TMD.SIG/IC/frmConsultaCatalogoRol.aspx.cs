﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;
using Entidades.GEN;

namespace TMD.SIG.IC
{
    public partial class frmConsultaCatalogoRol : System.Web.UI.Page
    {
        CatalogoRolE oCatalogoE=null;
        CatalogoRolBL oCatalogoBL = null;
        RolUsuarioBL oDetalleBL = null;
        UsuarioRolE oDetalleE = null;
        int Codigo=-1;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CargarLista(Convert.ToInt32(Page.Request.QueryString["Id"]));
            }
        }

        void CargarLista(int Codigo)
        {
            oDetalleBL = new  RolUsuarioBL();
            List<UsuarioE> List = oDetalleBL.ListAll(new CatalogoRolE() { Codigo=Codigo});

            //Guardando Detalle
            foreach (UsuarioE item_ in List)
            {
                ListItem item = new ListItem(item_.Nombre, item_.Codigo);
                lbCriterioAgregar.Items.Add(item);
            }
        }
    }

}