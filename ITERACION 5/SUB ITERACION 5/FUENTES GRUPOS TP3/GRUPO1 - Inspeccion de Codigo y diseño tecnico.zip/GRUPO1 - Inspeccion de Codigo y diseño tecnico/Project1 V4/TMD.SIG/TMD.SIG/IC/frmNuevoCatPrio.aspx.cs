﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMD.SIG.IC
{
    public partial class frmNuevoCatPrio : System.Web.UI.Page
    {
        Entidades.IC.PrioridadE oPrioridadE = null;
        Negocio.IC.PrioridadBL oPrioridadBL = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnNCatPrio_Click(object sender, EventArgs e)
        {
            try
            {
                oPrioridadE = new Entidades.IC.PrioridadE();
                oPrioridadBL = new Negocio.IC.PrioridadBL();

                oPrioridadE.Nombre = txtNombre.Text;
                oPrioridadE.Descripcion = txtDescripcion.Text;

                oPrioridadBL.insert(oPrioridadE);

                lblMensaje.Text = "Catalogo creado";
            }
            catch (Exception ex)
            {
            }
        }
    }
}