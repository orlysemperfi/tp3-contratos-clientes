﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMD.SIG.GD
{
    public partial class GD_Index : System.Web.UI.Page
    {
        String Msj = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["mensaje"] != null)
            {


                Msj = Convert.ToString(Request.QueryString["mensaje"]);
                if (Msj.Equals("1"))
                {
                    lblMensaje.Text = "[No puede registrar de nuevo su evaluacion]";
                }
                if (Msj.Equals("2"))
                {
                    lblMensaje.Text = "[No hay informacion a consultar]";
                }

                if (Msj.Equals("3"))
                {
                    lblMensaje.Text = "[Datos grabados correctamente]";
                }
                if (Msj.Equals("4"))
                {
                    lblMensaje.Text = "[No puede registrar de nuevo la evaluacion]";
                }

            }
            else
            {
                lblMensaje.Text = "";
            }
        }
    }
}