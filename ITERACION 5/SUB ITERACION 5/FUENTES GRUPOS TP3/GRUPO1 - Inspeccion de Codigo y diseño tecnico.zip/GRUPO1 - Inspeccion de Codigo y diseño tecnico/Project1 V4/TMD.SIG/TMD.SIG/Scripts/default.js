﻿$(function () {
    //this code is executed when the page's onload event fires

    $("a#runSample1").click(function () {
        alert("jquery3");
        $('input[id$=txtCodigo]').val('valor!!');
        //$('#txtCodigo').val('valor!!');
        return false;
    });

});


function verificarControl(width_c, height_c) {
        var param = '';
        param = '?codCtrl=' + window.document.getElementById('MainContent_txtCodCtrl').value + '&codPoli=' + window.document.getElementById('MainContent_txtCodPoli').value;
        var url = "RegistrarVerificacionControl.aspx" + param;
        var window_top = (screen.height - height_c) / 2;
        var window_left = (screen.width - width_c) / 2;
        var caracteristicas = "height=" + height_c + ",width=" + width_c + ",scrollTo,resizable=no,scrollbars=1,location=0,menubar=no,status=no,directories=no,titlebar=no, top=" + window_top + ",left = " + window_left;
        window.open(url, 'Popup', caracteristicas);
}

function cerrar() {
    this.close();
}

function setDespatch() {
}

function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 44)
        return false;

    return true;
}

