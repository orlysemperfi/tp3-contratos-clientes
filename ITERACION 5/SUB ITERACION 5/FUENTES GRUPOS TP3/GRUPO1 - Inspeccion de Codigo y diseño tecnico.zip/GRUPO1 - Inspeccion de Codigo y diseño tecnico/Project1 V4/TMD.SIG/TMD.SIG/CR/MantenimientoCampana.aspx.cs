﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Negocio.CR;
using Entidades.CR;

namespace TMD.SIG.CR
{
    public partial class MantenimientoCampana : System.Web.UI.Page
    {
        IMantenimientoCampanaBL iMantenimientoCampanaBL = new MantenimientoCampanaBL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ddlListaMarketing.DataSource = iMantenimientoCampanaBL.ObtenerListaMarketing();
                ddlListaMarketing.DataTextField = "nombre";
                ddlListaMarketing.DataValueField = "listaMarketingId";
                ddlListaMarketing.DataBind();
            }
        }

        protected void btnFiltrar_Click(object sender, EventArgs e)
        {
            try
            {
                if ((dtpDesde.Text.Trim().Length == 0 && dtpHasta.Text.Trim().Length != 0) || (dtpDesde.Text.Trim().Length != 0 && dtpHasta.Text.Trim().Length == 0))
                {
                    lblEstadoGrabar.Text = " La fecha de inicio y fin debe ser ingresados";
                    lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
                    return;
                }

                if (dtpDesde.Text.Trim().Length != 0 && dtpHasta.Text.Trim().Length != 0)
                {
                    DateTime fecInicio = DateTime.ParseExact(dtpDesde.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);
                    DateTime fecFin = DateTime.ParseExact(dtpHasta.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);


                    TimeSpan restFecha = fecInicio - fecFin;
                    if (restFecha.TotalDays > 0)
                    {
                        lblEstadoGrabar.Text = " La fecha fin debe ser mayor que la fecha de inicio";
                        lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
                        return;
                    }
                }

   
                DataTable dt = new DataTable();
                CampanaCaptacionE obj = new CampanaCaptacionE();
                obj.nombre = txtNombreCamapaña.Text;
                obj.fechaInicio = dtpDesde.Text;
                obj.fechaFin = dtpHasta.Text;
                obj.estado = "";
                
                dt = iMantenimientoCampanaBL.ConsultarCampana_Captacion(obj).Tables[0];

                grdCampaña.DataSource = dt;
                grdCampaña.DataBind();
                lblEstadoGrabar.Text = grdCampaña.Rows.Count.ToString() + " resultado(s) encontrado(s)";
                lblEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");
            }
            catch (Exception ex)
            {
                lblEstadoGrabar.Text = " " + ex.Message;
                lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
            }
        }
           
        protected void lnkItemName_Click(object sender, EventArgs e)
        {
            Button1_ModalPopupExtender.Show();
        }

        protected void grdCampaña_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            String idCampanaActual = e.CommandArgument.ToString();
            lblModificarId.Text = idCampanaActual;

            DataTable dt = new DataTable();
            dt = iMantenimientoCampanaBL.BuscaCampana_Captacion(Convert.ToInt32(idCampanaActual)).Tables[0];

            lblTitulo.Text = "Modificación de Campaña de Captación";
            lblEstadoPopup.Text = "";
            lblPresupuestoReal.Visible = true;
            txtPresupuetoReal.Visible = true;
            btnModificar.Visible = true;
            lblEstado.Visible = true;
            ddlEstado.Visible = true;

            DateTime fecInicioSol = DateTime.ParseExact(dt.Rows[0][2].ToString(), "dd/MM/yyyy",  System.Globalization.CultureInfo.CurrentCulture);
            DateTime fecFinSol = DateTime.ParseExact(dt.Rows[0][3].ToString(), "dd/MM/yyyy",  System.Globalization.CultureInfo.CurrentCulture);

            String fecInicioSolString = fecInicioSol.ToString("yyyy-MM-dd");
            String fecFinSolString = fecFinSol.ToString("yyyy-MM-dd");

            txtPopNombreCampaña.Text = dt.Rows[0][1].ToString();
            txtPopFecInicio.Text = fecInicioSolString;
            txtPopFecFin.Text = fecFinSolString;
            txtPopPresupuestoPlanificado.Text = dt.Rows[0][5].ToString();
            txtPresupuetoReal.Text = dt.Rows[0][6].ToString();
            txtPopObjetivos.Text= dt.Rows[0][8].ToString();
            txtPopObservaciones.Text = dt.Rows[0][9].ToString();
            
            String estado = "";

            switch(dt.Rows[0][7].ToString())
            {
                case "CREADA": 
                    estado = "C";
                    break;
                case "ACTIVA":
                    estado = "A";
                    break;
                case "CERRADA":
                    estado = "E";
                    break;
                case "AUTORIZADA":
                    estado = "U";
                    break;
                default :
                    estado = "R";
                    break;
            }
            
            ddlEstado.SelectedValue = estado;
            lblTextoEstado.Text = dt.Rows[0][7].ToString();
            ddlListaMarketing.SelectedValue = dt.Rows[0][10].ToString();

            if (lblTextoEstado.Text.Equals("ACTIVA"))
            {
                txtPopNombreCampaña.Enabled = false;
                txtPopFecFin.Enabled = true; 
                txtPopFecInicio.Enabled = false; 
                txtPopObservaciones.Enabled = true; 
                txtPopPresupuestoPlanificado.Enabled = true;
                ddlEstado.Enabled = true;
                ddlListaMarketing.Enabled = false;
                txtPopObjetivos.Enabled = false; 
            }
            else if(lblTextoEstado.Text.Equals("CERRADA"))
            {
                txtPopNombreCampaña.Enabled = false;
                txtPopFecFin.Enabled = false; ;
                txtPopFecInicio.Enabled = false; ;
                txtPopObjetivos.Enabled = false; ;
                txtPopObservaciones.Enabled = false; ;
                txtPopPresupuestoPlanificado.Enabled = false;
                ddlEstado.Enabled = false;
                ddlListaMarketing.Enabled = false;
                btnModificar.Visible = false;
            }
            else
            {
                txtPopNombreCampaña.Enabled = true;
                txtPopFecFin.Enabled = true; ;
                txtPopFecInicio.Enabled = true; ;
                txtPopObjetivos.Enabled = true; ;
                txtPopObservaciones.Enabled = true; ;
                txtPopPresupuestoPlanificado.Enabled = true;
                ddlEstado.Enabled = true;
                ddlListaMarketing.Enabled = true;
            }
        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            try
            {
                String cadena = "Los campos ";
                bool valida = false;

                if (txtPopNombreCampaña.Text.Trim().Length == 0)
                {
                    cadena += "Nombre de campaña, ";
                    valida = true;
                }

                if (txtPopFecInicio.Text.Trim().Length == 0)
                {
                    cadena += "Fecha de Inicio, ";
                    valida = true;
                }

                if (txtPopFecFin.Text.Trim().Length == 0)
                {
                    cadena += "Fecha de Fin, ";
                    valida = true;
                }

                if (txtPopPresupuestoPlanificado.Text.Trim().Length == 0)
                {
                    cadena += "Presupuesto planificado, ";
                    valida = true;
                }

                if (txtPopObjetivos.Text.Trim().Length == 0)
                {
                    cadena += "Objetivos, ";
                    valida = true;
                }

                if (txtPopObservaciones.Text.Trim().Length == 0)
                {
                    cadena += "Observaciones, ";
                    valida = true;
                }

                if (valida)
                {
                    lblEstadoPopup.Text = cadena + " son requeridos";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    Button1_ModalPopupExtender.Show();
                    return;
                }

                DateTime fecInicio = DateTime.ParseExact(txtPopFecInicio.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);
                DateTime fecFin = DateTime.ParseExact(txtPopFecFin.Text, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture);
                DateTime fecActual = DateTime.Now;

                TimeSpan restInicioActual = fecActual - fecInicio;
                TimeSpan restFinActual = fecActual - fecFin;

                TimeSpan restFecha = fecInicio - fecFin;
                
                if (lblTextoEstado.Text.Trim().ToUpper().Equals("CREADA"))
                {
                    if (!ddlEstado.SelectedItem.Text.ToUpper().Equals("CREADA")) 
                    {
                        lblEstadoPopup.Text = "La campaña Creada no puede cambiar al estado seleccionado";
                        lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                        Button1_ModalPopupExtender.Show();
                        return;
                    }
                }

                if (lblTextoEstado.Text.Trim().ToUpper().Equals("AUTORIZADA"))
                {
                    if (ddlEstado.SelectedItem.Text.ToUpper().Equals("CERRADA"))
                    {
                        lblEstadoPopup.Text = "La campaña Autorizada no puede cambiar al estado seleccionado";
                        lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                        Button1_ModalPopupExtender.Show();
                        return;
                    }
                }

                

                if (lblTextoEstado.Text.Trim().ToUpper().Equals("ACTIVA"))
                {
                    if (!ddlEstado.SelectedItem.Text.ToUpper().Equals("ACTIVA"))
                    {
                        if (!ddlEstado.SelectedItem.Text.ToUpper().Equals("CERRADA"))
                        {
                            lblEstadoPopup.Text = "La campaña Activa no puede cambiar al estado seleccionado";
                            lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                            Button1_ModalPopupExtender.Show();
                            return;
                        }

                        if (!(restInicioActual.TotalDays > 0 && restFinActual.TotalDays < 0))
                        {
                            lblEstadoPopup.Text = " La fecha actual debe estar entre la fecha de inicio y fin";
                            lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                            Button1_ModalPopupExtender.Show();
                            return;
                        }

                        if (restInicioActual.TotalDays >= 0 || restFinActual.TotalDays >= 0)
                        {
                            lblEstadoPopup.Text = " La fecha de inicio y fecha fin deben ser mayores que la fecha actual";
                            lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                            Button1_ModalPopupExtender.Show();
                            return;
                        }
                    }
                }

                if (lblTextoEstado.Text.Trim().ToUpper().Equals("RECHAZADA"))
                {
                    if (!ddlEstado.SelectedItem.Text.ToUpper().Equals("RECHAZADA"))
                    {
                        lblEstadoPopup.Text = "La campaña Rechazada no puede cambiar al estado seleccionado";
                        lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                        Button1_ModalPopupExtender.Show();
                        return;
                    }
                }

                if (lblTextoEstado.Text.Trim().ToUpper().Equals("CERRADA"))
                {
                    if (!ddlEstado.SelectedItem.Text.ToUpper().Equals("CERRADA"))
                    {
                        lblEstadoPopup.Text = "La campaña Cerrada no puede cambiar al estado seleccionado";
                        lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                        Button1_ModalPopupExtender.Show();
                        return;
                    }
                }

                if (lblTextoEstado.Text.Trim().ToUpper().Equals("AUTORIZADA"))
                {
                    if (!ddlEstado.SelectedItem.Text.ToUpper().Equals("ACTIVA"))
                    {
                        lblEstadoPopup.Text = "La campaña Autorizada no puede cambiar al estado seleccionado";
                        lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                        Button1_ModalPopupExtender.Show();
                        return;
                    }
                }

                if (restFecha.TotalDays > 0)
                {
                    lblEstadoPopup.Text = " La fecha fin debe ser mayor que la fecha de inicio";
                    lblEstadoPopup.ForeColor = System.Drawing.Color.Red;
                    Button1_ModalPopupExtender.Show();
                    return;
                }
                                
                CampanaCaptacionE obj = new CampanaCaptacionE();
                obj.campanaCaptacionId = Convert.ToInt32(lblModificarId.Text);
                obj.nombre = txtPopNombreCampaña.Text;
                obj.fechaInicio = txtPopFecInicio.Text;
                obj.fechaFin = txtPopFecFin.Text;
                obj.objetivos = txtPopObjetivos.Text;
                obj.presupuestoReal = double.Parse(txtPresupuetoReal.Text);
                obj.presupuestoPlanificado = double.Parse(txtPopPresupuestoPlanificado.Text);
                obj.observaciones = txtPopObservaciones.Text;
                obj.listaMarketing = Convert.ToInt32(ddlListaMarketing.SelectedValue.ToString());
                obj.estado = ddlEstado.SelectedValue;

                bool salida = iMantenimientoCampanaBL.ModificarCampana_Captacion(obj);

                if (salida)
                {
                    DataTable dt = new DataTable();
                    CampanaCaptacionE campanaCaptacionE = new CampanaCaptacionE();

                    campanaCaptacionE.nombre = txtNombreCamapaña.Text;
                    campanaCaptacionE.estado = "";
                    campanaCaptacionE.fechaInicio = dtpDesde.Text;
                    campanaCaptacionE.fechaFin = dtpHasta.Text;

                    dt = iMantenimientoCampanaBL.ConsultarCampana_Captacion(campanaCaptacionE).Tables[0];

                    grdCampaña.DataSource = dt;
                    grdCampaña.DataBind();

                    lblEstadoGrabar.Text = "Se modifico correctamente";
                    lblEstadoGrabar.ForeColor = System.Drawing.Color.FromName("#3333FF");
                }
                else
                {
                    lblEstadoGrabar.Text = "No se modifico";
                    lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
                }
            }
            catch (Exception ex)
            {
                lblEstadoGrabar.Text = " " + ex.Message;
                lblEstadoGrabar.ForeColor = System.Drawing.Color.Red;
            }        
        }

        protected void btnIngresar_Click(object sender, EventArgs e)
        {
            lblTitulo.Text = "Registro de Campaña de Captación";
            lblPresupuestoReal.Visible = false;
            txtPresupuetoReal.Visible = false;
            lblEstadoPopup.Text = "";
            txtPopNombreCampaña.ReadOnly = false;
            btnModificar.Visible = false;
            lblEstado.Visible = false;
            ddlEstado.Visible = false;
            txtPopNombreCampaña.Text = "";
            txtPopFecFin.Text = "";
            txtPopFecInicio.Text = "";
            txtPopObjetivos.Text = "";
            txtPopObservaciones.Text = "";
            txtPopPresupuestoPlanificado.Text = "";
           
            txtPopNombreCampaña.Enabled = true;
            txtPopFecFin.Enabled = true; ;
            txtPopFecInicio.Enabled = true; ;
            txtPopObjetivos.Enabled = true; ;
            txtPopObservaciones.Enabled = true; ;
            txtPopPresupuestoPlanificado.Enabled = true;
            ddlEstado.Enabled = true;
            ddlListaMarketing.Enabled = true;

            Button1_ModalPopupExtender.Show();
        }
    }
}
