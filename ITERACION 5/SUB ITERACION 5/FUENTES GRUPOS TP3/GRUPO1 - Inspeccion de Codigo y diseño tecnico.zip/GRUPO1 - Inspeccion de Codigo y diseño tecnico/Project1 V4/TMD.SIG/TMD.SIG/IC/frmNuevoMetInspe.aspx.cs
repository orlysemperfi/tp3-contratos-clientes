﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TMD.SIG.IC
{
    public partial class frmNuevoMetInspe : System.Web.UI.Page
    {
        Entidades.IC.CatalagoMetodoInspeccionE oPrioridadE = null;
        Negocio.IC.MetodoBL oPrioridadBL = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnNCatPrio_Click(object sender, EventArgs e)
        {
            try
            {
                oPrioridadE = new Entidades.IC.CatalagoMetodoInspeccionE();
                oPrioridadBL = new Negocio.IC.MetodoBL();

                oPrioridadE.ResumenOperacion = txtDescripcion.Text;
                oPrioridadE.Descripcion = txtNombre.Text;

                oPrioridadBL.insert(oPrioridadE) ;
                lblMensaje.Text = "Se registro metodo";
            }
            catch (Exception ex)
            {
            }
        }
    }
}