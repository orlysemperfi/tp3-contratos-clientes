﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;

namespace TMD.SIG.IC
{
    public partial class MetInspeCatalogo : System.Web.UI.Page
    {
        Negocio.IC.MetodoBL oPrioridadBL = new Negocio.IC.MetodoBL();
        Entidades.IC.CatalagoMetodoInspeccionE oPrioridadE = new Entidades.IC.CatalagoMetodoInspeccionE();
        protected void Page_Load(object sender, EventArgs e)
        {
                gvPrioridad.DataBind();
        }

        protected void btnAprobar_Click(object sender, EventArgs e)
        {
            try
            {
                if (gvPrioridad.SelectedRow.Cells[3].Text.ToUpper() == "P")
                {
                    oPrioridadBL = new Negocio.IC.MetodoBL();
                    oPrioridadE = new Entidades.IC.CatalagoMetodoInspeccionE();

                    oPrioridadE.Codigo = int.Parse(gvPrioridad.SelectedRow.Cells[0].Text);
                    oPrioridadE.Estado = "A";

                    oPrioridadBL.ModificarEstado(oPrioridadE);
                    gvPrioridad.DataBind();

                    lblMensaje.Text = "Catálogo aprobado";
 
                }
                else
                {
                    if (gvPrioridad.SelectedRow.Cells[3].Text.ToUpper() == "O")
                    {
                        lblMensaje.Text = "No se puede Aprobar Catálogo Obsoleto";
                    }
                    else
                        lblMensaje.Text = "No se puede Aprobar Catálogo, catálogo activo o en uso";
                }
            }
            catch (Exception ex)
            {
            }
        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            oPrioridadBL = new MetodoBL();
            oPrioridadE = new CatalagoMetodoInspeccionE();
            oPrioridadE.Codigo = int.Parse(gvPrioridad.SelectedRow.Cells[0].Text);
            oPrioridadE.ResumenOperacion = (gvPrioridad.SelectedRow.Cells[2].Text);
            oPrioridadE.Descripcion = (gvPrioridad.SelectedRow.Cells[1].Text);
            oPrioridadE.Estado = gvPrioridad.SelectedRow.Cells[3].Text;

            // if (oPrioridadE.Estado.ToUpper() != "U" && oPrioridadE.Estado.ToUpper() != "P")
            if (oPrioridadE.Estado.ToUpper() == "A")
            {
                Session["objeto"] = oPrioridadE;
                Response.Redirect("./frmModMetInspe.aspx?codigo=");

               // oPrioridadBL.ModificarEstado(oPrioridadE);
               // gvPrioridad.DataBind();


            }
            else
            {
                if (gvPrioridad.SelectedRow.Cells[3].Text.ToUpper() == "O")
                {
                    lblMensaje.Text = "No se puede modificar Catálogo Obsoleto";
                }
                else
                    lblMensaje.Text = "No se puede modificar Catálogo, catálogo pendiente de aprobación o en uso";
            }               
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            oPrioridadBL = new MetodoBL();
            oPrioridadE = new CatalagoMetodoInspeccionE();
            oPrioridadE.Codigo = int.Parse(gvPrioridad.SelectedRow.Cells[0].Text);
            oPrioridadE.Estado = gvPrioridad.SelectedRow.Cells[3].Text;

            if (oPrioridadE.Estado.ToUpper() != "U" && oPrioridadE.Estado.ToUpper() != "P" && oPrioridadE.Estado.ToUpper() != "O")
            {
                oPrioridadE.Estado = "O";
                oPrioridadBL.ModificarEstado(oPrioridadE);
                gvPrioridad.DataBind();

                lblMensaje.Text = "Catálogo eliminado";
            }
            else
            {
                if (gvPrioridad.SelectedRow.Cells[3].Text.ToUpper() == "O")
                {
                    lblMensaje.Text = "No se puede eliminar Catálogo Obsoleto";
                }
                else
                    lblMensaje.Text = "No se puede eliminar Catálogo, catálogo pendiente de aprobación o en uso";
            }
        }

        protected void btnNuevo_Click(object sender, EventArgs e)
        {

        }
    }
}