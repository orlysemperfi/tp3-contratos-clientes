﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;

namespace TMD.SIG.IC
{
    public partial class PrioridadCatalogo : System.Web.UI.Page
    {
        Negocio.IC.PrioridadBL oPrioridadBL = new Negocio.IC.PrioridadBL();
        Entidades.IC.PrioridadE oPrioridadE = new Entidades.IC.PrioridadE();
        protected void Page_Load(object sender, EventArgs e)
        {
                gvPrioridad.DataBind();
        }

        protected void btnAprobar_Click(object sender, EventArgs e)
        {
            try
            {
                if (gvPrioridad.SelectedRow.Cells[3].Text.ToUpper() == "P")
                {
                    oPrioridadBL = new Negocio.IC.PrioridadBL();
                    oPrioridadE = new Entidades.IC.PrioridadE();

                    oPrioridadE.Codigo = int.Parse(gvPrioridad.SelectedRow.Cells[0].Text);
                    oPrioridadE.Estado = "A";

                    oPrioridadBL.ModificarEstado(oPrioridadE);
                    gvPrioridad.DataBind();

                    lblMensaje.Text = "Se aprobó Catalogo";
                }
                else
                {
                    if (gvPrioridad.SelectedRow.Cells[3].Text.ToUpper() == "O")
                    {
                        lblMensaje.Text = "No se puede Aprobar Catalogo Obsoleto";
                    }
                    else
                        lblMensaje.Text = "No se puede Aprobar Catalogo, catalogo activo o en uso";
                }
            }
            catch (Exception ex)
            {
            }
        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            oPrioridadBL = new PrioridadBL();
            oPrioridadE = new PrioridadE();

            oPrioridadE.Codigo = int.Parse(gvPrioridad.SelectedRow.Cells[0].Text);
            oPrioridadE.Nombre = (gvPrioridad.SelectedRow.Cells[1].Text);
            oPrioridadE.Descripcion = (gvPrioridad.SelectedRow.Cells[2].Text);
            oPrioridadE.Estado = gvPrioridad.SelectedRow.Cells[3].Text;

            //if (oPrioridadE.Estado.ToUpper() != "U" && oPrioridadE.Estado.ToUpper() != "P")
            if (oPrioridadE.Estado.ToUpper() == "A")
            {
                Session["objeto"] = oPrioridadE;
                Response.Redirect("./frmModPrio.aspx?codigo=");
                //oPrioridadBL.ModificarEstado(oPrioridadE);
                //gvPrioridad.DataBind();
            }
            else
            {
                if (gvPrioridad.SelectedRow.Cells[3].Text.ToUpper() == "O")
                {
                    lblMensaje.Text = "No se puede modificar Catalogo Obsoleto";
                }
                else
                    lblMensaje.Text = "No se puede modificar Catalogo, catalogo pendiente de aprobación o en uso";
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            oPrioridadBL = new PrioridadBL();
            oPrioridadE = new PrioridadE();
            oPrioridadE.Codigo = int.Parse(gvPrioridad.SelectedRow.Cells[0].Text);
            oPrioridadE.Estado = gvPrioridad.SelectedRow.Cells[3].Text;

            if (oPrioridadE.Estado.ToUpper() != "U" && oPrioridadE.Estado.ToUpper() != "P" && oPrioridadE.Estado.ToUpper() != "O")
            {
                oPrioridadE.Estado = "O";
                oPrioridadBL.ModificarEstado(oPrioridadE);
                gvPrioridad.DataBind();
                lblMensaje.Text = "Se elimino Catalogo";
            }
            else
            {
                if (gvPrioridad.SelectedRow.Cells[3].Text.ToUpper() == "O")
                {
                    lblMensaje.Text = "No se puede eliminar Catalogo Obsoleto";
                }
                else
                    lblMensaje.Text = "No se puede eliminar Catalogo, catalogo pendiente de aprobación o en uso";
            }
               
        }
    }
}