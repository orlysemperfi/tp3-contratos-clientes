﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entidades.SI;
using Negocio.SI;


namespace TMD.SIG.SI
{
    public partial class ConsultaModProcesos : System.Web.UI.Page
    {
        private IVerificacionBL veri = new VerificacionBL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["idProceso"] != null)
            {
                this.txtCodigoProceso.Value = Request.QueryString["idProceso"].ToString();
                this.txtNombreProceso.Value = Request.QueryString["nomProceso"].ToString();
                this.txtObjetivo.Value = Request.QueryString["nomObjetivo"].ToString();
                this.txtCodigoTipoProceso.Value = Request.QueryString["wvSelect"].ToString();

                this.txtResponsable.Value = Request.QueryString["wvResp"].ToString();
                this.txtMTD.Value = Request.QueryString["wvMTD"].ToString();
                this.txtRTO.Value = Request.QueryString["wvRTO"].ToString();
                //this.txtCodigoTipoProceso.Value = Request.QueryString["wvTipoActivo"].ToString();
                 
            }
        }
    }
}