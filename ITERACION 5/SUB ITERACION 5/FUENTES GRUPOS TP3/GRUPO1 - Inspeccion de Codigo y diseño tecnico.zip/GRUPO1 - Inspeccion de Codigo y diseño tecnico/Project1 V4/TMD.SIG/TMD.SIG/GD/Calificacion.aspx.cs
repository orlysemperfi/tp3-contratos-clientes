﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.GD;
using Entidades.GD;
using TMD.SIG.Util;

namespace TMD.SIG.GD
{
    public partial class Calificacion : System.Web.UI.Page
    {
        private IFormularioCabeceraBL forcab = new FormularioCabeceraBL();
        private IFormularioDetalleBL fdet = new FormularioDetalleBL();
        private Int32 codemp=1;
        private Int32 form = 1;
  


        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                MultiView1.ActiveViewIndex = 0;

                    
                FormularioCabeceraE frc = new FormularioCabeceraE();
                frc = forcab.llenarCabeceraC(codemp);
                lblNombre.Text = frc.EVALUADO;
                lblCodigo.Text = frc.CODIGO_EMPLEADO.ToString();
                lblRol.Text = frc.ROL;
                lblProyecto.Text = frc.PROYECTO;
                lblFRecepcion.Text = frc.FRECEPCION;
                lblFRegistro.Text = frc.FECHA;
                lblEvaluador.Text = frc.EVALUADOR;

                List<FormularioDetalleE> formdet = new List<FormularioDetalleE>();
                formdet = fdet.ListaDetalleCLF(2);

                for (int i = 0; i < formdet.Count; i++)
                {
                    if (formdet[i].CODIGO_SECCION_DETALLE == 1)
                    {
                        lblSecA.Text = formdet[i].SECCION;
                        lblSec1.Text = formdet[i].SECCION_DETALLE;
                        txtSec1.Text = formdet[i].VALOR_CAMPO;
                        txtSec1.Enabled = false;
                    }

                    if (formdet[i].CODIGO_SECCION_DETALLE == 2)
                    {
                        lblSec2.Text = formdet[i].SECCION_DETALLE;
                        txtSec2.Text = formdet[i].VALOR_CAMPO;
                        txtSec2.Enabled = false;
                    }

                    if (formdet[i].CODIGO_SECCION_DETALLE == 3)
                    {
                        lblSecB.Text = formdet[i].SECCION;
                        lblSec3.Text = formdet[i].SECCION_DETALLE;
                        txtSec3.Text = formdet[i].VALOR_CAMPO;
                        txtSec3.Enabled = false;
                    }

                    if (formdet[i].CODIGO_SECCION_DETALLE == 4)
                    {
                        lblSec4.Text = formdet[i].SECCION_DETALLE;
                        txtSec4.Text = formdet[i].VALOR_CAMPO;
                        txtSec4.Enabled = false;
                    }

                    if (formdet[i].CODIGO_SECCION_DETALLE == 5)
                    {
                        lblSec5.Text = formdet[i].SECCION_DETALLE;
                        txtSec5.Text = formdet[i].VALOR_CAMPO;
                        txtSec5.Enabled = false;
                    }


                    List<FormularioCalificacionE> formc = new List<FormularioCalificacionE>();
                    formc = fdet.ListaDetalleC(codemp, form);

                    for (int j = 0; j < formc.Count; j++)
                    {
                        if (formc[j].CODIGO_SECCION == 6)
                        {
                            lblSecC.Text = formc[j].SECCION;
                        }
                    }


                    this.GridView1.DataSource = fdet.ListaCombo(form);
                    this.GridView1.DataBind();
                    this.GridView1.Columns[2].Visible = false;
                    this.GridView1.Columns[3].Visible = false;

                    DropDownList drdList;


                    List<RolesyCompetenciasE> rycomp = new List<RolesyCompetenciasE>();
                    rycomp = fdet.ListaCombo(form);

                    for (int k = 0; k < GridView1.Rows.Count; k++)
                    {
                        drdList = (DropDownList)(GridView1.Rows[k].Cells[1].FindControl("DropDownList1"));
                        drdList.DataValueField = "Nivel";

                        for (int m = 0; m < rycomp.Count; m++)
                        {
                            if (rycomp[m].COMPETENCIA.Equals(GridView1.DataKeys[k]["COMPETENCIA"].ToString()))
                            {
                                drdList.Items.Insert(0, "Seleccione un nivel");

                                if (rycomp[m].NIVEL_1.Length > 10)
                                {
                                    drdList.Items.Insert(1, rycomp[m].NIVEL_1);
                                }

                                if (rycomp[m].NIVEL_2.Length > 10)
                                {
                                    drdList.Items.Insert(2, rycomp[m].NIVEL_2);
                                }

                                if (rycomp[m].NIVEL_3.Length > 10)
                                {
                                    drdList.Items.Insert(3, rycomp[m].NIVEL_3);
                                }

                                if (rycomp[m].NIVEL_4.Length > 10)
                                {
                                    drdList.Items.Insert(4, rycomp[m].NIVEL_4);
                                }

                                if (rycomp[m].NIVEL_5.Length>10)
                                {
                                    drdList.Items.Insert(5, rycomp[m].NIVEL_5);
                                }
                                

                                
                                
                                
                                
                            }


                        }

                        drdList.DataBind();
                    }

                }
            }



        }

        protected void btn1_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
        }

        protected void btn2_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 1;
        }

        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            DropDownList drdList;
            String comp, resul;
            String cod_i, cod_id;

            if (txtSec6.Text.Length == 0)
            {
                ClientMessageBox.Show("Debe completar el campo " + lblSecC.Text, this);
                return;
            }

            if (VerificaCalificacion() == 0)
            {
                ClientMessageBox.Show("Debe seleccionar un nivel para todas las competencias", this);
                return;
            }

            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                comp = GridView1.DataKeys[i]["COMPETENCIA"].ToString();
                cod_i = GridView1.DataKeys[i]["COD_I"].ToString();
                cod_id = GridView1.DataKeys[i]["COD_ID"].ToString();
                drdList = (DropDownList)(GridView1.Rows[i].Cells[1].FindControl("DropDownList1"));
                resul = drdList.SelectedValue.ToString().Substring(0, 7).Trim();
                
                fdet.IngresaCompetencias(form, codemp, 1, Convert.ToInt32(cod_i), Convert.ToInt32(cod_id), resul);
                
            }

            fdet.InsertarAuto(form, codemp, 3, 6, txtSec6.Text);
            fdet.Actualizar(form, codemp, lblFRecepcion.Text, "Evaluado");
            Response.Redirect("~/GD/GD_Index.aspx?mensaje=3"); 
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/GD/GD_Index.aspx");
        }

        private Int32 VerificaCalificacion()
        {
            DropDownList drdList;
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                drdList = (DropDownList)(GridView1.Rows[i].Cells[1].FindControl("DropDownList1"));
                if (drdList.SelectedValue.ToString() == "Seleccione un nivel")
                {
                    return 0;
                }
            }
            return 1;
        }



    }
}