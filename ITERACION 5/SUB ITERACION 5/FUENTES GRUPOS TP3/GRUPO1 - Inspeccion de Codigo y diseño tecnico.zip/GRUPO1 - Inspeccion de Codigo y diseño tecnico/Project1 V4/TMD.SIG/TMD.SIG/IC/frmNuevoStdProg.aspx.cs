﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;

namespace TMD.SIG.IC
{
    public partial class frmNuevoStdProg : System.Web.UI.Page
    {
        EstandaresE  oEstandarE = null;
        EstandarBL oEstandarBL = null;
        int resultado = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
        
        }

        protected void btnNStdProg_Click(object sender, EventArgs e)
        {
            oEstandarE = new EstandaresE();
            oEstandarBL = new EstandarBL();
            try
            {

                string appPath = HttpContext.Current.Request.ApplicationPath;

                string physicalPath = HttpContext.Current.Request.MapPath(appPath);

                fuArchivo.SaveAs(@""+physicalPath+"IC\\Documentos\\" + fuArchivo.FileName);

                oEstandarE.Nombre = txtNombre.Text.Trim();
                oEstandarE.Descripcion = txtDescripcion.Text.Trim();
                oEstandarE.Archivo = "Documentos/"+fuArchivo.FileName.Trim();
                oEstandarE.Version = int.Parse(txtVersion.Text);
                oEstandarE.Usuario_Creacion = "1";

                //implementando logica de negocio
                resultado = oEstandarBL.insertar(oEstandarE);

                if (resultado >0)
                {
                    lblMensaje.Text = "El Estandar se registró exitosamente";
                }
                else
                {
                    lblMensaje.Text = "Error al registrar";
                }

            }
            catch (Exception ex)
            {
                lblMensaje.Text = ex.Message;
            }
        }
    }
}