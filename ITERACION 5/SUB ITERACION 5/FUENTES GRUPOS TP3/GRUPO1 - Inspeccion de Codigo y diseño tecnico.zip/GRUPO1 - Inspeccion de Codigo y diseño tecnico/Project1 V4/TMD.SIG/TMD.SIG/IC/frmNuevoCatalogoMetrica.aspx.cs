﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;

namespace TMD.SIG.IC
{
    public partial class frmNuevoCatalogoMetrica : System.Web.UI.Page
    {
        MetricaE oCatalogoE=null;
        MetricaBL oCatalogoBL = null;
        MetricaDetalleBL oDetalleBL = null;
        MetricaDeltalleE oDetalleE = null;
        int Codigo=-1;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                lbCriterioLista.DataBind();
                //gvListar.DataBind();
            }

        }

        protected void btnGrabar_Click(object sender, EventArgs e)
        {
            if (lbCriterioAgregar.Items.Count > 0)
            {
                oCatalogoE = new MetricaE();
                oCatalogoBL = new MetricaBL();
                oDetalleBL = new MetricaDetalleBL();
                int CodigoCheckList;
                try
                {
                    oCatalogoE.Objetivo = txtNombre.Text.Trim();
                    oCatalogoE.Descripcion = txtDescripcion.Text.Trim();

                    //implementando logica de negocio
                    CodigoCheckList = oCatalogoBL.Insertar(oCatalogoE);
                    Codigo = CodigoCheckList;

                   //Guardando Detalle
                    foreach (ListItem item in lbCriterioAgregar.Items)
                    {
                        oDetalleBL.Insertar(new MetricaDeltalleE
                        {
                            CodigoMetrica = CodigoCheckList,
                            CodigoCriterio = int.Parse(item.Value),
                        });
                        
                    }

                    limpiarCasillas();
                    lbCriterioAgregar.Items.Clear();
                    lblMensaje.Text = "Detalle Guardado";
                }
                catch (Exception ex)
                {
                    lblMensaje.Text = ex.Message;
                }
            }
            else
                lblMensaje.Text = "Ingrese Detalle....";
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            /*oCatalogoE = new MetricaE();
            oCatalogoBL = new MetricaBL();
            try
            {
                //oCatalogoE.Codigo = txtNombre.Text.Trim();

                //implementando logica de negocio
                oCatalogoBL.Eliminar(oCatalogoE);
            }
            catch (Exception ex)
            {
                lblMensaje.Text = ex.Message;
            }*/
        }


        public void limpiarCasillas()
        {
            txtNombre.Text = "";
            txtDescripcion.Text = "";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                ListItem item_ = new ListItem(lbCriterioLista.SelectedItem.Text,
                    lbCriterioLista.SelectedValue);

                lbCriterioAgregar.Items.Add(item_);
            }
            catch (Exception ex)
            {
            }
        }

        protected void btnQuitar_Click(object sender, EventArgs e)
        {
            try
            {
                lbCriterioAgregar.Items.RemoveAt(lbCriterioAgregar.SelectedIndex);
            }
            catch (Exception ex)
            {
                    
            }
        }

        protected void btnActualizar_Click(object sender, EventArgs e)
        {

        }

        protected void ObjectDataSource2_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
        {
            /*oDetalleE = new DetalleCheckListE();
            oDetalleE.CodigoCheckList = 0;
                if (!Page.IsPostBack)
                {
                    e.InputParameters["o"] = oDetalleE;
                }
                else
                {
                    oDetalleE.CodigoCheckList = Codigo;
                    e.InputParameters["o"] = oDetalleE;
                }*/

        }


        void LimpiarLista()
        {
            foreach (ListItem item in lbCriterioAgregar.Items)
            {
                lbCriterioAgregar.Items.Remove(item);

            }
        }
    }
}