﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Negocio.IC;
using Entidades.IC;

namespace TMD.SIG.IC
{
    public partial class frmModMetInspe : System.Web.UI.Page
    {
        CatalagoMetodoInspeccionE oPrioridadE = null;
        MetodoBL oPrioridadBL = null;
        int resultado = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                carga();
            }

        }

        protected void btnNCatPrio_Click(object sender, EventArgs e)
        {
            try
            {
                oPrioridadE = (CatalagoMetodoInspeccionE)Session["objeto"];
                oPrioridadBL = new MetodoBL();

                oPrioridadE.ResumenOperacion = txtDescripcion.Text;
                oPrioridadE.Descripcion = txtNombre.Text;

                resultado=oPrioridadBL.Modificar(oPrioridadE);
                if (resultado == -1)
                {
                    lblMensaje.Text = "Error al modificar";

                }
                else
                {
                    lblMensaje.Text = "Catalogo modificado satisfactoriamente";
                
                }
            }
            catch(Exception ex)
            {
                lblMensaje.Text = ex.Message;
            }


            

        }

        private void carga() {
            oPrioridadE = new CatalagoMetodoInspeccionE();
            try
            {
                oPrioridadE = (CatalagoMetodoInspeccionE)Session["objeto"];
                txtNombre.Text = oPrioridadE.ResumenOperacion;
                txtDescripcion.Text = oPrioridadE.Descripcion;
            }
            catch(Exception ex)
            {
                lblMensaje.Text = ex.Message;
            }
        }
    }
}