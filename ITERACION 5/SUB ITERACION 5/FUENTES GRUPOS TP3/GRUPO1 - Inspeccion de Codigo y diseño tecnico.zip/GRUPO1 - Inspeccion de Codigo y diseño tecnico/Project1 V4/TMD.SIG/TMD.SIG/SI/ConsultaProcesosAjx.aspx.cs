﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
//using System.Web.UI.WebControls;
using Entidades.SI;
using Negocio.SI;


namespace TMD.SIG.SI
{
    public partial class ConsultaProcesosAjx : System.Web.UI.Page
    {
        private IVerificacionBL veri = new VerificacionBL();
        private ICreacionProcesoBL proc = new CreacionProcesoBL();
        
        protected void Page_Load(object sender, EventArgs e)
        {   
            if (Request.QueryString["wvAction"]!=null) {
                
                String wvAction = Request.QueryString["wvAction"].ToString();

                if (wvAction == "L") // Carga Tipo de Proceso en el Select
                {
                    int wvSelect = Convert.ToInt32(Request.QueryString["wvSelect"].ToString());
                    
                    String sRespuesta = "<select id='selTipoProceso' style='width:200px;'><option value=0>TODOS</option>";
                    List<TipoProcesoE> list = veri.getListaTipoProceso();            
                    foreach (TipoProcesoE C in list)
                    {
                        sRespuesta = sRespuesta + "<option value='" + C.codTipoProceso.ToString() + "'";
                        if (wvSelect == C.codTipoProceso) {
                            sRespuesta = sRespuesta + " selected";
                        }                        
                        sRespuesta = sRespuesta + ">" + C.nomTipoProceso + "</option>";

                    }

                    sRespuesta = sRespuesta + "</select>";

                    Response.Expires = -1;
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = "text/html";
                    Response.Write(sRespuesta);
                    Response.Flush();
                }
                if (wvAction == "LP") { // Lista Procesos
                    String sCodigoResponsable = Request.QueryString["wvCodigoResponsable"].ToString();
                    int wvCodigoResponsable = 0;
                    if (sCodigoResponsable == "")
                    {
                        wvCodigoResponsable = 0;
                    }
                    else {
                        wvCodigoResponsable = Convert.ToInt32(sCodigoResponsable);
                    }
                    int wvTipoProceso = Convert.ToInt32(Request.QueryString["wvTipoProceso"].ToString());
                    

                    List<ProcesoE> list = veri.getListaProceso(wvTipoProceso, wvCodigoResponsable);

                    String sRespuesta = "    <table border=1 width=100%>" +
                                                "<tr>" +
                                                "    <th>Codigo</th>" +
                                                "    <th>Nombre</th>" +
                                                "    <th>Tipo</th>" +
                                                "    <th>Objetivo</th>" +
                                                "    <th>RTO</th>" +
                                                "    <th>MTD</th>" +
                                                "    <th>Responsable</th>" +
                                                "    <th>Area</th>" +
                                                "    <th>Estado</th>" +
                                                "    <th>Editar</th>" +
                                                "</tr>";                    
                    foreach (ProcesoE C in list)
                    {
                        sRespuesta = sRespuesta + "<tr>";
                        sRespuesta = sRespuesta + "    <td>" + C.codProceso.ToString() + "</td>";
                        sRespuesta = sRespuesta + "    <td>" + C.nomProceso + "</td>";
                        sRespuesta = sRespuesta + "    <td>" + C.nomTipoProceso + "</td>";
                        sRespuesta = sRespuesta + "    <td>" + C.objProceso + "</td>";
                        sRespuesta = sRespuesta + "    <td>" + C.nomRTO + "</td>";
                        sRespuesta = sRespuesta + "    <td>" + C.nomMTD + "</td>";
                        sRespuesta = sRespuesta + "    <td>" + C.nomEmpleado + "</td>";
                        sRespuesta = sRespuesta + "    <td>" + C.nomArea + "</td>";
                        sRespuesta = sRespuesta + "    <td>" + C.estProceso + "</td>";
                        sRespuesta = sRespuesta + "    <td><a href='../SI/ConsultaModProcesos.aspx?idProceso=" + C.codProceso.ToString() + "&nomProceso=" + C.nomProceso + "&nomObjetivo=" + C.objProceso + "&wvSelect=" + C.codTipoProceso.ToString() + "&wvResp=" + C.codResponsable.ToString() + "&wvMTD=" + C.mtd.ToString() + "&wvRTO=" + C.rto.ToString() + "&wvTipoActivo='>Editar</a></td>";
                        sRespuesta = sRespuesta + "</tr>";
                    }

                    sRespuesta = sRespuesta + "</table>";

                    Response.Expires = -1;
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = "text/html";
                    Response.Write(sRespuesta);
                    Response.Flush();
                }
                if (wvAction == "LR")
                { // Lista Responsable
                    int wvSelect = Convert.ToInt32(Request.QueryString["wvSelect"].ToString());

                    String sRespuesta = "<select id='selResponsable' style='width:200px;'>";
                    List<ResponsableControlE> list = proc.getListaResponsable();
                    foreach (ResponsableControlE C in list)
                    {
                        sRespuesta = sRespuesta + "<option value='" + C.codResponsable.ToString() + "'";
                        if (wvSelect == C.codResponsable)
                        {
                            sRespuesta = sRespuesta + " selected";
                        }
                        sRespuesta = sRespuesta + ">" + C.nomResponsable + "</option>";

                    }
                    sRespuesta = sRespuesta + "</select>";

                    Response.Expires = -1;
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = "text/html";
                    Response.Write(sRespuesta);
                    Response.Flush();
                }
                if (wvAction == "MTD")
                { // Lista MTD
                    int wvSelect = Convert.ToInt32(Request.QueryString["wvSelect"].ToString());

                    String sRespuesta = "<select id='selMTD' style='width:200px;'>";
                    List<TiempoInterrupcionE> list = proc.getTiempoInterrupcion();
                    foreach (TiempoInterrupcionE C in list)
                    {
                        sRespuesta = sRespuesta + "<option value='" + C.codTI.ToString() + "'";
                        if (wvSelect == C.codTI)
                        {
                            sRespuesta = sRespuesta + " selected";
                        }
                        sRespuesta = sRespuesta + ">" + C.nomTI + "</option>";

                    }
                    sRespuesta = sRespuesta + "</select>";

                    Response.Expires = -1;
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = "text/html";
                    Response.Write(sRespuesta);
                    Response.Flush();
                }
                if (wvAction == "RTO")
                { // Lista RTO
                    int wvSelect = Convert.ToInt32(Request.QueryString["wvSelect"].ToString());

                    String sRespuesta = "<select id='selRTO' style='width:200px;'>";
                    List<TiempoInterrupcionE> list = proc.getTiempoInterrupcion();
                    foreach (TiempoInterrupcionE C in list)
                    {
                        sRespuesta = sRespuesta + "<option value='" + C.codTI.ToString() + "'";
                        if (wvSelect == C.codTI)
                        {
                            sRespuesta = sRespuesta + " selected";
                        }
                        sRespuesta = sRespuesta + ">" + C.nomTI + "</option>";

                    }
                    sRespuesta = sRespuesta + "</select>";

                    Response.Expires = -1;
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = "text/html";
                    Response.Write(sRespuesta);
                    Response.Flush();
                }
                if (wvAction == "TA")
                { // Lista TA
                    int wvSelect = Convert.ToInt32(Request.QueryString["wvSelect"].ToString());

                    String sRespuesta = "<select id='selTipoActivo' style='width:200px;'>";
                    List<TipoProcesoE> list = veri.getListaTipoProceso();
                    foreach (TipoProcesoE C in list)
                    {
                        sRespuesta = sRespuesta + "<option value='" + C.codTipoProceso.ToString() + "'";
                        if (wvSelect == C.codTipoProceso)
                        {
                            sRespuesta = sRespuesta + " selected";
                        }
                        sRespuesta = sRespuesta + ">" + C.nomTipoProceso + "</option>";

                    }
                    sRespuesta = sRespuesta + "</select>";

                    Response.Expires = -1;
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = "text/html";
                    Response.Write(sRespuesta);
                    Response.Flush();
                }
                if (wvAction == "PI")
                { // Lista Proceso Impacto
                    int wvCodProceso = Convert.ToInt32(Request.QueryString["wvSelect"].ToString());
                    
                    String sRespuesta = "";
                    List<TipoImpactoE> list = proc.getListaTipoImpacto();
                    List<PrioridadImpactoE> list2 = proc.getListPrioridadImpacto();
                    List<ProcesoImpactoE> list3 = proc.getListaImpactoProceso(wvCodProceso);
                    sRespuesta = sRespuesta + "<table border=1 width='100%'>";
                    sRespuesta = sRespuesta + "<th>Codigo Impacto</th>";
                    sRespuesta = sRespuesta + "<th>Tipo Impacto</th>";
                    sRespuesta = sRespuesta + "<th>Prioridad</th>";
                    Boolean creaSele = false;

                    foreach (TipoImpactoE C in list)
                    {
                        sRespuesta = sRespuesta + "<tr>";
                        sRespuesta = sRespuesta + "<td align=center>" + C.codTipoImpacto + "</td>";
                        sRespuesta = sRespuesta + "<td>" + C.nomTipoImpacto + "</td>";
                        sRespuesta = sRespuesta + "<td align=center><select id='selTI_" + C.codTipoImpacto.ToString() + "' style='width:80px;' onChange=fxModiProcTI(this,'" + C.codTipoImpacto.ToString()  + "')>";
                        foreach (PrioridadImpactoE P in list2) { // Prioridad Impacto
                            foreach (ProcesoImpactoE PIm in list3) // Proceso Impacto
                            {
                                if (C.codTipoImpacto == PIm.codTipoImpacto && P.codValor == PIm.codPrioridad) {
                                    creaSele = true;
                                    sRespuesta = sRespuesta + "<option value='" + P.codValor.ToString() + "' selected>" + P.descripValor + "</option>";    
                                }
                            }
                            if (!creaSele)
                            {
                                sRespuesta = sRespuesta + "<option value='" + P.codValor.ToString() + "'>" + P.descripValor + "</option>";
                            }
                            else {
                                creaSele = false;
                            }
                        }
                        sRespuesta = sRespuesta + "</select></td>";
                        sRespuesta = sRespuesta + "</tr>";
                    }

                    sRespuesta = sRespuesta + "</table>";

                    Response.Expires = -1;
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = "text/html";
                    Response.Write(sRespuesta);
                    Response.Flush();
                }
                if (wvAction == "PU")
                { // Update Proceso
                    String sRespuesta = "";
                    int wvSelect = Convert.ToInt32(Request.QueryString["vwCODRESPONSABLE"].ToString());

                    ProcesoE wvProceso = new ProcesoE();
                    wvProceso.codArea = 0;
                    wvProceso.codProceso = Convert.ToInt32(Request.QueryString["vwCODPROCESO"].ToString()); ;
                    wvProceso.codResp = Convert.ToInt32(Request.QueryString["vwCODRESPONSABLE"].ToString());
                    wvProceso.codTipoProceso = Convert.ToInt32(Request.QueryString["vwCODTIPOPROCESO"].ToString());
                    wvProceso.mtd = Convert.ToInt32(Request.QueryString["vwMTD"].ToString()); ;
                    wvProceso.rto = Convert.ToInt32(Request.QueryString["vwRTO"].ToString());
                    wvProceso.nomProceso = Request.QueryString["vwNOMPROCESO"].ToString();
                    wvProceso.objetivo = Request.QueryString["vwOBJPROCESO"].ToString();
                    wvProceso.impacto = Request.QueryString["vwProcImpacto"].ToString();

                    sRespuesta = proc.actualizarProceso(wvProceso);

                    Response.Expires = -1;
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = "text/html";
                    Response.Write(sRespuesta);
                    Response.Flush();
                }
            }
        }
    }
}