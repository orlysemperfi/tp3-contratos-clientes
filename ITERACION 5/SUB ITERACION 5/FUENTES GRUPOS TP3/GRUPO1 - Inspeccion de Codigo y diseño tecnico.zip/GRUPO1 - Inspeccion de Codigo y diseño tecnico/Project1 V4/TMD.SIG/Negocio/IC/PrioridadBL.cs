﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Negocio.IC
{
    public class PrioridadBL
    {
        Datos.IC.PrioridadDAO oPrioridad = null;
        public int insert(Entidades.IC.PrioridadE o)
        {
            oPrioridad = new Datos.IC.PrioridadDAO();
            return oPrioridad.insert(o);
        }

        public List<Entidades.IC.PrioridadE> ListAll()
        {
            oPrioridad = new Datos.IC.PrioridadDAO();
            return oPrioridad.ListAlL();
        }

        public int ModificarEstado(Entidades.IC.PrioridadE o)
        {
            oPrioridad = new Datos.IC.PrioridadDAO();
            return oPrioridad.ModificarEstado(o);
        }

        public int Modificar(Entidades.IC.PrioridadE o)
        {
            oPrioridad = new Datos.IC.PrioridadDAO();
            return oPrioridad.Modificar(o);
        }
    }
}
