﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.SI;
using Entidades.SI;

namespace Negocio.SI
{
    public class CreacionProcesoBL : Negocio.SI.ICreacionProcesoBL
    {
        private ICreacionProcesoDAO creacionDao = new CreacionProcesoDAO();

        public List<ActivoE> getListaActivo(string codTipoActivo)
        {
            return creacionDao.getListaActivo(codTipoActivo);
        }
        public List<ResponsableControlE> getListaResponsable()
        {
            return creacionDao.getListaResponsable();
        }
        public List<TipoActivoE> getListaTipoActivo()
        {
            return creacionDao.getListaTipoActivo();

        }
        public List<TipoImpactoE> getListaTipoImpacto()
        {
            return creacionDao.getListaTipoImpacto();
        }
        public List<TipoProcesoE> getListaTipoProceso()
        {
            return creacionDao.getListaTipoProceso();
        }
        public List<PrioridadImpactoE> getListPrioridadImpacto()
        {
            return creacionDao.getListPrioridadImpacto();
        }
        public List<TiempoInterrupcionE> getTiempoInterrupcion()
        {
            return creacionDao.getTiempoInterrupcion();
        }
        public int registrarProceso(ProcesoE o)
        {
            return creacionDao.registrarProceso(o);
        }

        public void registrarProcesoImpacto(int codProceso, int codTipoImpac, int codPriori)
        {
            creacionDao.registrarProcesoImpacto(codProceso,codTipoImpac,codPriori);
        }

        public void registrarProcesoActivo(int codProceso, int codActivo)
        {
            creacionDao.registrarProcesoActivo(codProceso,codActivo);
        }
    }
}
