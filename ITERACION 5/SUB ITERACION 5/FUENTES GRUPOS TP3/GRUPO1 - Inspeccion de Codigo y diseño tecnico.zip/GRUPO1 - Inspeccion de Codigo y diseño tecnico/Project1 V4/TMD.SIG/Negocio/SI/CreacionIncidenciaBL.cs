﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.SI;
using Datos.SI;

namespace Negocio.SI
{
    public class CreacionIncidenciaBL : Negocio.SI.ICreacionIncidenciaBL
    {
        private ICreacionIncidenciaDAO creacionIncid = new CreacionIncidenciaDAO();

        public List<PrioridadImpactoE> getListPrioridadImpacto(string param)
        {
            return creacionIncid.getListPrioridadImpacto(param);
        }

        public int registrarIncidencia(IncidenciaE o)
        {
            return creacionIncid.registrarIncidencia(o);
        }
    }
}
