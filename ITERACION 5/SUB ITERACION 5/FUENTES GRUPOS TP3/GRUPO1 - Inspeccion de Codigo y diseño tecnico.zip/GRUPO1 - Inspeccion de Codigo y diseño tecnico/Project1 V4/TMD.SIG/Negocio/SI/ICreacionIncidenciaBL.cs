﻿using System;
namespace Negocio.SI
{
    public interface ICreacionIncidenciaBL
    {
        System.Collections.Generic.List<Entidades.SI.PrioridadImpactoE> getListPrioridadImpacto(string param);
        int registrarIncidencia(Entidades.SI.IncidenciaE o);
    }
}
