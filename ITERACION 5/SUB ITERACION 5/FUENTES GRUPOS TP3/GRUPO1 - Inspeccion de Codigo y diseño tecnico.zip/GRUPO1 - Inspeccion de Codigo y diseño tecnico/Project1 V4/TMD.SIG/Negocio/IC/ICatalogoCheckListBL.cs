﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;

namespace Negocio.IC
{
    public interface ICatalogoCheckListBL
    {
        int insertar(CatalagoChecklistE o);
        List<Entidades.IC.CatalagoChecklistE> listAll();
    }
}
