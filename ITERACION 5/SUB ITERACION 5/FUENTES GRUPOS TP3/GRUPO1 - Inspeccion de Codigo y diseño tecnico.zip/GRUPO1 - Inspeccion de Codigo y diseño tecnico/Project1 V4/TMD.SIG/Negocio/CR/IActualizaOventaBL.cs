﻿using System;
using System.Data;
using Entidades.CR;
using System.Collections.Generic;

namespace Negocio.CR
{
    public interface IActualizaOventaBL
    {
        DataSet Consultar_Oventa(ContactoE contactoE);

        DataSet Busca_Oventa(int oventaId);

        bool Actualiza_Oventa(ContactoE contactoE);
    }
}
