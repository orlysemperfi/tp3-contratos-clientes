﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.CR;
using Entidades.CR;
using System.Data;


namespace Negocio.CR
{
    public class ActualizaOventaBL : IActualizaOventaBL
    {

        IContactoDAO iContactoDAO = new ContactoDAO();

        public DataSet Consultar_Oventa(ContactoE contactoE)
        {
            return iContactoDAO.Consultar_Oventa(contactoE);
        }

        public DataSet Busca_Oventa(int oventaId)
        {
            return iContactoDAO.Busca_Oventa(oventaId);
        }

        public bool Actualiza_Oventa(ContactoE contactoE) 
        {
            return iContactoDAO.Actualiza_Oventa(contactoE);
        }

    }
}
