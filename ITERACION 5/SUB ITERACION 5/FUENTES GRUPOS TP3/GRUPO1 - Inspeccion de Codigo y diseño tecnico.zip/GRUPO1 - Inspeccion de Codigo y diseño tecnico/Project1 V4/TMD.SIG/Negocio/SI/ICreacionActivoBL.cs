﻿using System;
namespace Negocio.SI
{
    public interface ICreacionActivoBL
    {
        System.Collections.Generic.List<Entidades.SI.ActivoE> getListActivo();
        System.Collections.Generic.List<Entidades.SI.MonedaE> getListaMonedas();
        int registrarActivo(Entidades.SI.ActivoE o, int codProp, int codRTO, string codTipoAct, string codMoneda, int codActivoPadre);
    }
}
