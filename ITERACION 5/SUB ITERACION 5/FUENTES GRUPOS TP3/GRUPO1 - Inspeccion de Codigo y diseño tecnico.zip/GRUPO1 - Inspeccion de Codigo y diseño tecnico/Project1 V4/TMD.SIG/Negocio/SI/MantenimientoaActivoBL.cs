﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.SI;
using Datos.SI;

namespace Negocio.SI
{
    public class MantenimientoaActivoBL : Negocio.SI.IMantenimientoaActivoBL
    {
        private IMantenimientoActivoDAO actDao = new MantenimientoActivoDAO();
        
        public void insertar(ActivoE o)
        {
            actDao.Insert(o);
        }

        public List<ActivoE> listAll()
        {
            return actDao.listAll();
        }

        public List<TipoActivoE> listTipoActivo()
        {
            return actDao.listTipoActivo();
        }

        public List<ActivoE> getListaActivoPadre(int codActivo)
        {
            return actDao.getListaActivoPadre(codActivo);
        }


        public int CodigoActivoSel()
        {
            return actDao.CodigoActivoSel();
        }

        public List<ActivoE> getListaActivo(string codTipoActivo, string nomActivo)
        {
            return actDao.getListaActivo(codTipoActivo, nomActivo);


        }

        public List<ActivoE> getBuscarActivo(int codActivo)
        {
            return actDao.getBuscarActivo(codActivo);


        }
        public int ActualizarActivo(int codActivo, string nomActivo, int codPropietario,
                                    int codRPO, string codTipoActivo, string ubicacion, string codMoneda,
                                    decimal costoActivo, int codActivoPadre)
        {
            return actDao.ActualizarActivo(codActivo, nomActivo, codPropietario,
                                           codRPO, codTipoActivo, ubicacion, codMoneda,
                                           costoActivo, codActivoPadre);
        }


        public int EliminarActivo(int codActivo)
        {
            return actDao.EliminarActivo(codActivo);
        }
    }
}
