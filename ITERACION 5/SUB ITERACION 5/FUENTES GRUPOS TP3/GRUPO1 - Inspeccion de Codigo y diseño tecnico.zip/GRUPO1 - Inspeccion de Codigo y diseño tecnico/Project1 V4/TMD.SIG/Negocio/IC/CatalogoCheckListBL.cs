﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.IC;
using Entidades.IC;

namespace Negocio.IC
{
    public class CatalogoCheckListBL : ICatalogoCheckListBL
    {
        CatalogoDAO oCatalogDAO = null;
        public int insertar(Entidades.IC.CatalagoChecklistE o)
        {
            oCatalogDAO = new CatalogoDAO();
            return oCatalogDAO.Insert(o);
        }

        public List<Entidades.IC.CatalagoChecklistE> listAll()
        {
            oCatalogDAO = new CatalogoDAO();
            return oCatalogDAO.ListAll(); 
        }

        public List<Entidades.IC.CatalagoChecklistE> listAll(Entidades.IC.CatalagoChecklistE o)
        {
            oCatalogDAO = new CatalogoDAO();
            return null;//oCatalogDAO.ListAll(o); 
        }

        public List<Entidades.IC.CatalagoChecklistE> ListGrilla(Entidades.IC.CatalagoChecklistE oCatalogoe)
        {
            oCatalogDAO= new CatalogoDAO();
            return null;// oCatalogDAO.ListCatalogoNombre(oCatalogoe);
        }

        public int Eliminar(Entidades.IC.CatalagoChecklistE o)
        {
            oCatalogDAO = new CatalogoDAO();   
            return oCatalogDAO.Eliminar(o);
        }

        public int Aprobar(Entidades.IC.CatalagoChecklistE o)
        {
            oCatalogDAO = new CatalogoDAO();
            return oCatalogDAO.Aprobar(o);
        }

        public int ModificarCatalogo(CatalagoChecklistE o)
        {
            oCatalogDAO = new CatalogoDAO();
            return oCatalogDAO.Modificar(o);
        }
    }
}
