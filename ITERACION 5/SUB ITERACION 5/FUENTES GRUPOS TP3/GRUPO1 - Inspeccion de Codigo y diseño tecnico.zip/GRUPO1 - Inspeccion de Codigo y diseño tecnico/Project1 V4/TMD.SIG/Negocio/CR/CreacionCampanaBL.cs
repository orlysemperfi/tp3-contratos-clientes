﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.CR;
using Entidades.CR;
using Negocio.CR;

namespace Negocio.CR
{
    public class CreacionCampanaBL : ICreacionCampanaBL
    {
        ICampanaCaptacionDAO iCampanaCaptacionDAO = new CampanaCaptacionDAO();
        IListaMarketingDAO iListaMarketingDAO = new ListaMarketingDAO();

        public bool InsertarCampana_Captacion(CampanaCaptacionE campanaCaptacionE) {
            return iCampanaCaptacionDAO.InsertarCampana_Captacion(campanaCaptacionE);
        }

        public List<ListaMarketingE> ObtenerListaMarketing() {
            return iListaMarketingDAO.ObtenerListaMarketing();
        }
    }
}
