﻿using System;
namespace Negocio.SI
{
    public interface ICreacionProcesoBL
    {
        System.Collections.Generic.List<Entidades.SI.ActivoE> getListaActivo(string codTipoActivo);
        System.Collections.Generic.List<Entidades.SI.ResponsableControlE> getListaResponsable();
        System.Collections.Generic.List<Entidades.SI.TipoActivoE> getListaTipoActivo();
        System.Collections.Generic.List<Entidades.SI.TipoImpactoE> getListaTipoImpacto();
        System.Collections.Generic.List<Entidades.SI.TipoProcesoE> getListaTipoProceso();
        System.Collections.Generic.List<Entidades.SI.PrioridadImpactoE> getListPrioridadImpacto();
        System.Collections.Generic.List<Entidades.SI.TiempoInterrupcionE> getTiempoInterrupcion();
        int registrarProceso(Entidades.SI.ProcesoE o);
        void registrarProcesoActivo(int codProceso, int codActivo);
        void registrarProcesoImpacto(int codProceso, int codTipoImpac, int codPriori);
    }
}
