﻿using System;

namespace Negocio.CC
{
    public interface IIncumplimientoBL
    {
        void insertar(Entidades.CC.IncumplimientoE incumplimiento);
    }
}
