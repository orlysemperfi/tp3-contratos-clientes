﻿using System;
using System.Data;
using Entidades.CR;
namespace Negocio.CR
{
    public interface IMantenimientoSeguimientoBL
    {
        DataSet BuscaCampana_Captacion(int campanaCaptacionId);
        
        DataSet buscaSeguimiento(int seguimientoId);
        
        DataSet ConsultarSegumiento_PorCampana_Captacion(int campanaCaptacionId);
        
        DataSet ConsultarSegumiento_PorContacto(SeguimientoE seguimientoE);
        
        bool InsertarSeguimiento(SeguimientoE seguimientoE);
        
        bool ModificarCostoCampana(CampanaCaptacionE campanaCaptacionE);
        
        bool ModificarCostoCampana(int idCampana);
        
        bool ModificarSegumiento(SeguimientoE seguimientoE);

        DataSet ConsultarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);

        DataSet ConsultarCampana_Captacion_Estado(CampanaCaptacionE campanaCaptacionE);
    }
}
