﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;
using Datos.IC;

namespace Negocio.IC
{
    public class CatalogoRolBL
    {
        CatalogoRolDAO oCatalgoDAO = null;
        public int insertar(CatalogoRolE o)
        {
            oCatalgoDAO = new CatalogoRolDAO();
            return oCatalgoDAO.Insertar(o);
        }

        public int modificar(CatalogoRolE o)
        {
            oCatalgoDAO = new CatalogoRolDAO();
            return oCatalgoDAO.Modificar(o);
        }

        public int modificarestado(CatalogoRolE o)
        {
            oCatalgoDAO = new CatalogoRolDAO();
            return oCatalgoDAO.ModificarEstado(o);
        }

        public List<CatalogoRolE> ListaAll()
        {
            oCatalgoDAO = new CatalogoRolDAO();
            return oCatalgoDAO.listAll();
        }

    }
}
