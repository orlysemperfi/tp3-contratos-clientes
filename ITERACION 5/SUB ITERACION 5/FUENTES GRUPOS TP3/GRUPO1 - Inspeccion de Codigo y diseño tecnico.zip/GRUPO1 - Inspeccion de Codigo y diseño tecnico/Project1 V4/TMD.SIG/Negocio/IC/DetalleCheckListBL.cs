﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;
using Datos.IC;

namespace Negocio.IC
{
    public class DetalleCheckListBL
    {
        DetalleCheckListDAO oDetalleDao = null;
        public List<Entidades.IC.DetalleCheckListE> ListAll(DetalleCheckListE o)
        {
            oDetalleDao = new DetalleCheckListDAO();
            return oDetalleDao.ListAll(o);
        }

        public int Insertar(DetalleCheckListE o)
        {
            oDetalleDao = new DetalleCheckListDAO();
            return oDetalleDao.Insertar(o);
        }

        public int EliminarDetalle(DetalleCheckListE o)
        {
            oDetalleDao = new DetalleCheckListDAO();
            return oDetalleDao.Delete(o);
        }
    }
}
