﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.IC;

namespace Negocio.IC
{
    public class EstandarBL:IEstandarBL
    {
        EstandarDAO oEstandarDAO = null;
        #region Miembros de IEstandarBL

        public int insertar(Entidades.IC.EstandaresE o)
        {
            oEstandarDAO = new EstandarDAO();
            return oEstandarDAO.Insert(o);
        }

        public List<Entidades.IC.EstandaresE> listAll()
        {
            oEstandarDAO = new EstandarDAO();
            return oEstandarDAO.ListAll();
        }

        public List<Entidades.IC.EstandaresE> listAll(Entidades.IC.EstandaresE o)
        {
            oEstandarDAO = new EstandarDAO();
            return oEstandarDAO.ListAll(o);
        }

        public int modificar(Entidades.IC.EstandaresE o)
        {
            oEstandarDAO = new EstandarDAO();
            return oEstandarDAO.Modificar(o);
        }

        public int aprobar(Entidades.IC.EstandaresE o)
        {
            oEstandarDAO = new EstandarDAO();
            return oEstandarDAO.Aprobar(o);
        }

        public int eliminar(Entidades.IC.EstandaresE o)
        {
            oEstandarDAO = new EstandarDAO();
            return oEstandarDAO.Eliminar(o);
        }

        #endregion
    }
}
