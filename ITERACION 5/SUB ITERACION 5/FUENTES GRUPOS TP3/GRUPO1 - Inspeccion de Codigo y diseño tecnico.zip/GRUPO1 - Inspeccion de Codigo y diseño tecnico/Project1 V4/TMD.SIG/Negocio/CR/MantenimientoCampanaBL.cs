﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.CR;
using Entidades.CR;
using System.Data;


namespace Negocio.CR
{
    public class MantenimientoCampanaBL : IMantenimientoCampanaBL
    {
        ICampanaCaptacionDAO iCampanaCaptacionDAO = new CampanaCaptacionDAO();
        IListaMarketingDAO iListaMarketingDAO = new ListaMarketingDAO();

        public DataSet ConsultarCampana_Captacion(CampanaCaptacionE campanaCaptacionE)
        {
            return iCampanaCaptacionDAO.ConsultarCampana_Captacion(campanaCaptacionE);
        }

        public bool ModificarCampana_Captacion(CampanaCaptacionE campanaCaptacionE) 
        {
            return iCampanaCaptacionDAO.ModificarCampana_Captacion(campanaCaptacionE);
        }

        public DataSet BuscaCampana_Captacion(int campanaCaptacionId) 
        {
            return iCampanaCaptacionDAO.BuscaCampana_Captacion(campanaCaptacionId);
        }

        public List<ListaMarketingE> ObtenerListaMarketing()
        {
            return iListaMarketingDAO.ObtenerListaMarketing();
        }

    }
}
