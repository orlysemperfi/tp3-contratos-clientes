﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.IC;
using Entidades.IC;
using Entidades.GEN;

namespace Negocio.IC
{
    public class RolUsuarioBL
    {
        RolUsuarioDAO oRolUsuario = null;

        public int insertar(UsuarioRolE o)
        {
            oRolUsuario = new RolUsuarioDAO();
            return oRolUsuario.insert(o);
        }

        public List<UsuarioE> ListAll(CatalogoRolE o)
        {
            oRolUsuario = new RolUsuarioDAO();
            return oRolUsuario.ListaAll(o);
        }

        public int eliminar(UsuarioRolE o)
        {
            oRolUsuario = new RolUsuarioDAO();
            return oRolUsuario.eliminar(o);
        }
    }
}
