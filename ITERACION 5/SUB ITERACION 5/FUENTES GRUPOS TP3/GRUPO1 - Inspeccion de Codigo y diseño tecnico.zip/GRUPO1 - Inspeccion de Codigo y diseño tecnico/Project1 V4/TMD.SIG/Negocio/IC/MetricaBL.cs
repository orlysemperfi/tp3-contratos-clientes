﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.IC;
using Entidades.IC;

namespace Negocio.IC
{
    public class MetricaBL
    {
        MetricaDAO oMetricaDAO = null;
        public int Insertar(MetricaE o)
        {
            oMetricaDAO = new MetricaDAO();
            return oMetricaDAO.Insert(o);
        }

        public int Modificar(MetricaE o)
        {
            oMetricaDAO = new MetricaDAO();
            return oMetricaDAO.Modificar(o);
        }

        public int ModificarEstado(MetricaE o)
        {
            oMetricaDAO = new MetricaDAO();
            return oMetricaDAO.ModificarEstado(o);
        }
        public List<MetricaE> ListAll()
        {
            oMetricaDAO = new MetricaDAO();
            return oMetricaDAO.ListAll();
        }
    }
}
