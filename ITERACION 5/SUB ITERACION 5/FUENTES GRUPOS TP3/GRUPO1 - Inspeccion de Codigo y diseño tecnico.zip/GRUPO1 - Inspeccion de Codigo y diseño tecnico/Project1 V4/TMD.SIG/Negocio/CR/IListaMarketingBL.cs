﻿using System;
using System.Data;
using Entidades.CR;
using System.Collections.Generic;

namespace Negocio.CR
{
    public interface IListaMarketingBL
    {
        DataSet ConsultarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);

        DataSet ConsultarLista_de_Marketing(ListaMarketingE listaMarketingE);

        int InsertarListaMarketing(List<ContactoE> lstContacto, ListaMarketingE listaMarketingE);

        List<ListaMarketingE> ObtenerListaMarketing();
    }
}
