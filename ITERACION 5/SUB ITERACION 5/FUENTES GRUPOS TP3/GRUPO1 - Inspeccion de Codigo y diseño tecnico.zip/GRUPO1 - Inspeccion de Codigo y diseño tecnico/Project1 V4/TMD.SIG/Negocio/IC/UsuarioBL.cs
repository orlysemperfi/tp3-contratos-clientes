﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.IC;
using Entidades.GEN;

namespace Negocio.IC
{
    public class UsuarioBL
    {
        UsuarioDAO oUsuarioDAO = null;
        public List<UsuarioE> ListAll()
        {
            oUsuarioDAO = new UsuarioDAO();
            return oUsuarioDAO.ListaAll();
        }
    }
}
