﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.IC;

namespace Negocio.IC
{
    public class CatalogoPBL : ICatalogoPBL
    {
        CatalogoPDAO oCatalogDAO = null;

        #region Miembros de ICatalogoPBL

        public int insertar(Entidades.IC.CatalagoPrioridadE o)
        {
            oCatalogDAO = new CatalogoPDAO();
            return oCatalogDAO.Insert(o);
        }

        public List<Entidades.IC.CatalagoPrioridadE> ListAll()
        {
            oCatalogDAO = new CatalogoPDAO();
            return oCatalogDAO.ListAll();
        }

        public int modificar(Entidades.IC.CatalagoPrioridadE o)
        {
            oCatalogDAO = new CatalogoPDAO();
            return oCatalogDAO.Modificar(o);
        }

        public int aprobar(Entidades.IC.CatalagoPrioridadE o)
        {
            oCatalogDAO = new CatalogoPDAO();
            return oCatalogDAO.Aprobar(o);
        }

        public List<Entidades.IC.CatalagoPrioridadE> buscar(String nombre)
        {
            oCatalogDAO = new CatalogoPDAO();
            return oCatalogDAO.Buscar(nombre);
        }

        public int eliminar(Entidades.IC.CatalagoPrioridadE o)
        {
            oCatalogDAO = new CatalogoPDAO();
            return oCatalogDAO.Eliminar(o);
        }

        #endregion
    }
}
