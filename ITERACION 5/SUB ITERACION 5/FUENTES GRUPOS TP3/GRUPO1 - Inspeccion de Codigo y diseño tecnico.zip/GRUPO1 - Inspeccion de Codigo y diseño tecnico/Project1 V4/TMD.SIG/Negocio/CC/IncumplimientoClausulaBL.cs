﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.CC;
using Datos.CC;

namespace Negocio.CC
{
    public class IncumplimientoClausulaBL : Negocio.CC.IIncumplimientoClausulaBL
    {
        private IIncumplimientoClausulaDAO incumplimientoClausulaDAO = new IncumplimientoClausulaDAO();

        public void insertar(IncumplimientoClausulaE incumplimientoClausula, int codigo_incumplimiento)
        {
            incumplimientoClausulaDAO.Insertar(incumplimientoClausula, codigo_incumplimiento);
        }
    }
}
