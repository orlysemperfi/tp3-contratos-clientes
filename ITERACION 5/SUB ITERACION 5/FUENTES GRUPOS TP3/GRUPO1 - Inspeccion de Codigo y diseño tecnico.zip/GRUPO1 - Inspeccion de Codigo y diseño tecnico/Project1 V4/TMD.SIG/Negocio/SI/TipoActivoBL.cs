﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.SI;
using Entidades.SI;

namespace Negocio.SI
{
    public class TipoActivoBL : Negocio.SI.ITipoActivoBL
    {
        private ITipoActivoDAO activoDAO = new TipoActivoDAO();

        public void insertar(TipoActivoE o)
        {
            activoDAO.insertar(o);
        }

    }
}
