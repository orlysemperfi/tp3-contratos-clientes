﻿using System;

namespace Negocio.CC
{
    public interface IIncumplimientoClausulaBL
    {
        void insertar(Entidades.CC.IncumplimientoClausulaE incumplimiento_clausula, int codigo_incumplimiento);
    }
}
