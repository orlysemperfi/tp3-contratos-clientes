﻿using System;
namespace Negocio.SI
{
    public interface IMantenimientoaActivoBL
    {
        int ActualizarActivo(int codActivo, string nomActivo, int codPropietario, int codRPO, string codTipoActivo, string ubicacion, string codMoneda, decimal costoActivo, int codActivoPadre);
        int CodigoActivoSel();
        int EliminarActivo(int codActivo);
        System.Collections.Generic.List<Entidades.SI.ActivoE> getBuscarActivo(int codActivo);
        System.Collections.Generic.List<Entidades.SI.ActivoE> getListaActivo(string codTipoActivo, string nomActivo);
        System.Collections.Generic.List<Entidades.SI.ActivoE> getListaActivoPadre(int codActivo);
        void insertar(Entidades.SI.ActivoE o);
        System.Collections.Generic.List<Entidades.SI.ActivoE> listAll();
        System.Collections.Generic.List<Entidades.SI.TipoActivoE> listTipoActivo();
    }
}
