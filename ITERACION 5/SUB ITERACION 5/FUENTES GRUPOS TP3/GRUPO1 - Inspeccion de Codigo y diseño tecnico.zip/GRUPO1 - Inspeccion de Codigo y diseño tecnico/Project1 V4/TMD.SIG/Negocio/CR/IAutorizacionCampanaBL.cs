﻿using System;
using Entidades.CR;
using System.Collections.Generic;
using System.Data;

namespace Negocio.CR
{
    public interface IAutorizacionCampanaBL
    {
        bool AutorizarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);

        List<Entidades.CR.PersonaE> ObtenerAsesores();

        bool RechazarCampana_Captacion(CampanaCaptacionE campanaCaptacionE);

        DataSet ConsultarCampana_Captacion_Estado(CampanaCaptacionE campanaCaptacionE);

        List<ListaMarketingE> ObtenerListaMarketing();

        DataSet BuscaCampana_Captacion(int campanaCaptacionId);
    }
}
