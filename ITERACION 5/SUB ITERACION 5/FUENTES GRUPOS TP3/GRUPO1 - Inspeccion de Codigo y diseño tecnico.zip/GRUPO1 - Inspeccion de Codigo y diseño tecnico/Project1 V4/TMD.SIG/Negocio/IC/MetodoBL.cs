﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Negocio.IC
{
    public class MetodoBL
    {
        Datos.IC.MetodoDAO oMetodo = null;
        public int insert(Entidades.IC.CatalagoMetodoInspeccionE o)
        {
            oMetodo = new Datos.IC.MetodoDAO();
            return oMetodo.insert(o);
        }

        public List<Entidades.IC.CatalagoMetodoInspeccionE> ListAll()
        {
            oMetodo = new Datos.IC.MetodoDAO();
            return oMetodo.ListAlL();
        }

        public int ModificarEstado(Entidades.IC.CatalagoMetodoInspeccionE o)
        {
            oMetodo = new Datos.IC.MetodoDAO();
            return oMetodo.ModificarEstado(o);
        }

        public int Modificar(Entidades.IC.CatalagoMetodoInspeccionE o)
        {
            oMetodo = new Datos.IC.MetodoDAO();
            return oMetodo.Modificar(o);
        }
    }
}
