﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;
using Datos.IC;

namespace Negocio.IC
{
    public class CriterioBL:ICriterio
    {
        CriterioDAO oCriterioDAO = null;
        public List<Entidades.IC.CriterioE> listAll()
        {
            oCriterioDAO = new CriterioDAO();
            return oCriterioDAO.ListAll();
        }

        public List<Entidades.IC.CriterioE> listAllCriterioMetrica(MetricaE o)
        {
            oCriterioDAO = new CriterioDAO();
            return oCriterioDAO.ListAllxMetrica(o);
        }
    }
}
