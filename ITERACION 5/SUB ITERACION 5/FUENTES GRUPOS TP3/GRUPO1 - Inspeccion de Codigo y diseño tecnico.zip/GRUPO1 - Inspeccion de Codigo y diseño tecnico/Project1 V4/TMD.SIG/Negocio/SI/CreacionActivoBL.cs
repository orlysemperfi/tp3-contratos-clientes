﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.SI;
using Datos.SI;

namespace Negocio.SI
{
    public class CreacionActivoBL : Negocio.SI.ICreacionActivoBL
    {
        private ICreacionActivoDAO creacionActivo = new CreacionActivoDAO();

        public List<MonedaE> getListaMonedas()
        {
            return creacionActivo.getListaMonedas();
        }

        public List<ActivoE> getListActivo()
        {
            return creacionActivo.getListActivo();
        }

        public int registrarActivo(ActivoE o, int codProp, int codRTO, string codTipoAct, string codMoneda, int codActivoPadre)
        {
            return creacionActivo.registrarActivo(o, codProp, codRTO, codTipoAct, codMoneda, codActivoPadre);
        }
    }
}
