﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos.IC;
using Entidades.IC;

namespace Negocio.IC
{
    
    public class MetricaDetalleBL
    {
        MetricaDetalleDAO oMetricaDetalleDAO = null;

        public int Insertar(MetricaDeltalleE o)
        {
            oMetricaDetalleDAO = new MetricaDetalleDAO();
            return oMetricaDetalleDAO.Insert(o);
        }

        public int Eliminar(MetricaDeltalleE o)
        {
            oMetricaDetalleDAO = new MetricaDetalleDAO();
            return oMetricaDetalleDAO.Eliminar(o);
        }
        
    }
}
