﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;

namespace Negocio.IC
{
    public interface IEstandarBL
    {
         int insertar(EstandaresE  o);
         List<Entidades.IC.EstandaresE> listAll();
         int modificar(EstandaresE o);
         int aprobar(EstandaresE o);
         int eliminar(EstandaresE o); 
    }
}
