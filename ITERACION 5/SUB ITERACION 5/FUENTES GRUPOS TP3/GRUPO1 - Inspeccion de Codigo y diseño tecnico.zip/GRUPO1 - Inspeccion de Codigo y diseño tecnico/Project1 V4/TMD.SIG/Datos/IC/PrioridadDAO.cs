﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Entidades.IC;

namespace Datos.IC
{
    public class PrioridadDAO
    {
        //public int insert(Entidades.IC.PrioridadE o)
        public int insert(PrioridadE oPrioridadE)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[CATALAGO_PRIORIDAD_INS]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    //cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", oPrioridadE.Nombre));
                    cmd.Parameters.Add(new SqlParameter("@P_DESCRIPCION", oPrioridadE.Descripcion));

                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public List<Entidades.IC.PrioridadE> ListAlL()
        {
            //ConexionDAO cn = new ConexionDAO();
            List<PrioridadE> listCatalogoChecklist = new List<PrioridadE>();

            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[IC].[PRIORIDAD_LIST]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        PrioridadE bean = new PrioridadE();
                        bean.Codigo = int.Parse(reader["CODIGO"].ToString());
                        bean.Nombre = reader["NOMBRE"].ToString();
                        bean.Descripcion = reader["DESCRIPCION"].ToString();
                        bean.Estado = reader["ESTADO"].ToString();

                        //bean.Fecha_Aprobacion = DateTime.Parse(reader["FECHA_APROBACION"].ToString());
                        //bean.Fecha_Creacion = DateTime.Parse(reader["FECHA_CREACION"].ToString());
                        listCatalogoChecklist.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listCatalogoChecklist;
        }

        public int ModificarEstado(Entidades.IC.PrioridadE o)
        {
            
                 //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[PRIORIDAD_UDPATE]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    //cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_ESTADO", o.Estado));
                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", o.Codigo));

                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public int Modificar(PrioridadE oCatalogoE)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[CATALPRIO_UPD]";
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", oCatalogoE.Nombre));
                    cmd.Parameters.Add(new SqlParameter("@P_DESCRIPCION", oCatalogoE.Descripcion));


                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

    }
}
