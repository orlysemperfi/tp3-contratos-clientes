﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;

namespace Datos.IC
{
    public interface IEstandarDAO
    {
        int Insert(EstandaresE oEstandarE);
        List<EstandaresE> ListAll();
        int Modificar(EstandaresE oEstandarE);
        int Aprobar(EstandaresE oEstandarE);
        int Eliminar(EstandaresE oEstandarE);

    }
}
