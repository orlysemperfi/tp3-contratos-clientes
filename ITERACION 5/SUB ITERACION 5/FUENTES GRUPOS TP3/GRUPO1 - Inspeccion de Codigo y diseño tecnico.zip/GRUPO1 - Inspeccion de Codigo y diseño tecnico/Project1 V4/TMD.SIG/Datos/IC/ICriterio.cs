﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;

namespace Datos.IC
{
    public interface ICriterio
    {
        List<CriterioE> ListAll();
    }
}
