﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;

namespace Datos.IC
{
    public interface ICatalogoPDAO
    {
        int Insert(CatalagoPrioridadE oCatalogoE);
        List<CatalagoPrioridadE> ListAll();
        int Modificar(CatalagoPrioridadE oCatalogoE);
        int Aprobar(CatalagoPrioridadE oCatalogoE);
        List<CatalagoPrioridadE> Buscar(String nombre);
        int Eliminar(CatalagoPrioridadE oCatalogoE);

    }
}
