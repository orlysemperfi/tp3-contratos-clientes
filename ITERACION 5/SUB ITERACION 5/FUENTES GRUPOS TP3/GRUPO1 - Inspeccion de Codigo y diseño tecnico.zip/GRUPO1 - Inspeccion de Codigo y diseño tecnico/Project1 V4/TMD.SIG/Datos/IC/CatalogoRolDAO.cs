﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using Datos.GEN;
using Entidades.IC;

namespace Datos.IC
{
    public class CatalogoRolDAO
    {
        public int Insertar(CatalogoRolE o)
        {
            int response=0;
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[GEN].[ROLES_INS]", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", o.Nombre));

                    con.Open();
                    response = Convert.ToInt32( cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public List<CatalogoRolE> listAll()
        {
            List<CatalogoRolE> list = new List<CatalogoRolE>();

            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[GEN].[ROLES_LIST]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        CatalogoRolE bean = new CatalogoRolE();
                        bean.Codigo = int.Parse(reader[0].ToString());
                        bean.Descripcion = reader[1].ToString();
                        list.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return list;
        }

        public int Modificar(CatalogoRolE o)
        {
            int response = 0;
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[GEN].[ROLES_MODIFICAR]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", o.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", o.Nombre));

                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public int ModificarEstado(CatalogoRolE o)
        {
            int response = 0;
            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("IC.CATALOGO_ROLES_MODIFICAR_ESTADO", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", o.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_ESTADO", o.Estado));

                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }
            
    }
}
