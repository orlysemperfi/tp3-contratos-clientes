﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;
using System.Data;
using System.Data.SqlClient;

namespace Datos.IC
{
    public class CriterioDAO:IC.ICriterio
    {

        public List<Entidades.IC.CriterioE> ListAll()
        {
            List<CriterioE> oCriterio = new List<CriterioE>();
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[IC].[CRITERIO_LIST]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        CriterioE bean = new CriterioE();
                        bean.Codigo = int.Parse(reader["CODIGO"].ToString());
                        bean.Descripcion = reader["DESCRIPCION"].ToString();

                        oCriterio.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return oCriterio;
        }

        public List<Entidades.IC.CriterioE> ListAllxMetrica(MetricaE o)
        {
            List<CriterioE> oCriterio = new List<CriterioE>();
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[IC].[DETALLE_CATALOGO_LIST_METRICA]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_METRICA", o.Codigo);
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        CriterioE bean = new CriterioE();
                        bean.Codigo = int.Parse(reader["CODIGO"].ToString());
                        bean.Descripcion = reader["DESCRIPCION"].ToString();

                        oCriterio.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

            return oCriterio;
        }
    }
}
