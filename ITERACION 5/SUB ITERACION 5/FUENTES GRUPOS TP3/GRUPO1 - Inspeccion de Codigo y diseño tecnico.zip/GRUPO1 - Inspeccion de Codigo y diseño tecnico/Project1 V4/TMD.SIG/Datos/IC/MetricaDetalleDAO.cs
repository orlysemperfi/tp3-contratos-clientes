﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;
using System.Data;
using System.Data.SqlClient;

namespace Datos.IC
{
    public class MetricaDetalleDAO
    {
        public int Insert(MetricaDeltalleE o)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "IC.CATALOGO_METRICA_DETALLE_INS";
                    cmd.CommandType = CommandType.StoredProcedure;


                    //cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", o.CodigoMetrica));
                    cmd.Parameters.Add(new SqlParameter("@P_CRITERIO", o.CodigoCriterio));

                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public int Eliminar(MetricaDeltalleE o)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "IC.CATALOGO_METRICA_DETALLE_ELIMINAR";
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", o.CodigoMetrica));

                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }
    }
}
