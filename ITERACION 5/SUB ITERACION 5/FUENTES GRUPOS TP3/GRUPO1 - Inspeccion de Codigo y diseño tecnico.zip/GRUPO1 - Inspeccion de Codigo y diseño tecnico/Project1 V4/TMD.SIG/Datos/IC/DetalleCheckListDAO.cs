﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Entidades.IC;

namespace Datos.IC
{
    public class DetalleCheckListDAO
    {
        public List<Entidades.IC.DetalleCheckListE> ListAll(Entidades.IC.DetalleCheckListE o)
        {
            //ConexionDAO cn = new ConexionDAO();
            List<DetalleCheckListE> listCatalogoChecklist = new List<DetalleCheckListE>();

            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[IC].[DETALLE_LIST]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_CODIGO", o.CodigoCheckList);
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        DetalleCheckListE bean = new DetalleCheckListE();
                        bean.CodigoCheckList = int.Parse(reader["CODIGO"].ToString());
                        bean.CHECKLIST  = reader["CHECKLIST"].ToString();
                        bean.Prioridad = reader["PRIORIDAD"].ToString();
                        bean.CodigoDetalle = int.Parse(reader["CRITERIO"].ToString());
                        bean.Obligatorio = reader["OBLIGATORIO_CUMPLIR"].ToString();

                        //bean.Fecha_Aprobacion = DateTime.Parse(reader["FECHA_APROBACION"].ToString());
                        //bean.Fecha_Creacion = DateTime.Parse(reader["FECHA_CREACION"].ToString());
                        listCatalogoChecklist.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listCatalogoChecklist;
        }

        public int Insertar(Entidades.IC.DetalleCheckListE o)
        {
             //ConexionDAO cn = new ConexionDAO();
            int response=-1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection=con;
                    cmd.CommandText = "[IC].[DETALLE_CATALOGO_CHECKLIST_INS]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    

                    //cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO_CHECKLIST", o.CodigoCheckList));
                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO_CRITERIO", o.CodigoDetalle));
                    cmd.Parameters.Add(new SqlParameter("@P_PRIORIDAD", o.Prioridad));


                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public int Delete(DetalleCheckListE o)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[DETALLE_ELIMINAR]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    //cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", o.CodigoCheckList));
                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }
    }
}
