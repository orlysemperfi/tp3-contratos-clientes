﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Entidades.IC;
using Entidades.GEN;
using Datos.GEN;

namespace Datos.IC
{
    public class RolUsuarioDAO
    {
        public List<UsuarioE> ListaAll(CatalogoRolE o)
        {
            List<UsuarioE> list = new List<UsuarioE>();

            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("GEN.USUARIO_ROLES", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_ROL", o.Codigo);
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        UsuarioE bean = new UsuarioE();
                        bean.Codigo = (reader[0].ToString());
                        bean.Nombre = reader[1].ToString();
                        list.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return list;
        }

        public int insert(UsuarioRolE o)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[GEN].[ROL_USUARIO_INSERTAR]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    //cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_CODIGOROL", o.CodigoRol));
                    cmd.Parameters.Add(new SqlParameter("@P_COIDGOUSU", o.CodigoUsu));

                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public int eliminar(UsuarioRolE o)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[GEN].[ROL_USUARIO_ELIMINAR]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    //cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", o.CodigoRol));
                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }
    }
}
