﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Datos.GEN;
using Entidades.GEN;

namespace Datos.IC
{
    public class UsuarioDAO
    {
        public List<UsuarioE> ListaAll()
        {
            List<UsuarioE> list = new List<UsuarioE>();

            using (SqlConnection con = new SqlConnection(ConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("GEN.USUARIO_LIST", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        UsuarioE bean = new UsuarioE();
                        bean.Codigo = (reader[0].ToString());
                        bean.Nombre = reader[1].ToString();
                        list.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return list;
        }
    }
}
