﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;
using System.Data;
using System.Data.SqlClient;

namespace Datos.IC
{
    public class MetricaDAO
    {
        public int Insert(MetricaE o)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "IC.CATALOGO_METRICA_INS";
                    cmd.CommandType = CommandType.StoredProcedure;


                    //cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", o.Descripcion));
                    cmd.Parameters.Add(new SqlParameter("@P_OBJETIVO", o.Objetivo));

                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public List<Entidades.IC.MetricaE> ListAll()
        {
            //ConexionDAO cn = new ConexionDAO();
            List<MetricaE> listCatalogoChecklist = new List<MetricaE>();

            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("IC.CATALOGO_METRICA_LIST", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        MetricaE bean = new MetricaE();
                        bean.Codigo = int.Parse(reader["CODIGO"].ToString());
                        bean.Descripcion = reader["DESCRIPCION"].ToString();
                        bean.Objetivo = reader["OBJETIVO"].ToString();
                        bean.Estado = reader["ESTADO"].ToString();

                        //bean.Fecha_Aprobacion = DateTime.Parse(reader["FECHA_APROBACION"].ToString());
                        //bean.Fecha_Creacion = DateTime.Parse(reader["FECHA_CREACION"].ToString());
                        listCatalogoChecklist.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listCatalogoChecklist;
        }

        public int Modificar(MetricaE o)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "IC.CATALOGO_METRICA_MODIFICAR";
                    cmd.CommandType = CommandType.StoredProcedure;


                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", o.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", o.Descripcion));
                    cmd.Parameters.Add(new SqlParameter("@P_OBJETIVO", o.Objetivo));

                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public int ModificarEstado(MetricaE o)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "IC.CATALOGO_METRICA_MODIFICAR_ESTADO";
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", o.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_ESTADO", o.Estado));

                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }
    }
}
