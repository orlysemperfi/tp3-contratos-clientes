﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;
using System.Data;
using System.Data.SqlClient;


namespace Datos.IC
{
    public class CatalogoDAO: ICatalogoDAO
    {
        
        public int Insert(Entidades.IC.CatalagoChecklistE oCatalogoE)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response=-1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection=con;
                    cmd.CommandText = "[IC].[CATALOGOCHECKLIST_INS]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    

                    //cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", oCatalogoE.Nombre));
                    cmd.Parameters.Add(new SqlParameter("@P_DESCRIPCION", oCatalogoE.Descripcion));
                    cmd.Parameters.Add(new SqlParameter("@P_VERSION", oCatalogoE.Version));
                    cmd.Parameters.Add(new SqlParameter("@P_PRIORIDAD", oCatalogoE.Prioridad));


                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public List<Entidades.IC.CatalagoChecklistE> ListAll()
        {
            //ConexionDAO cn = new ConexionDAO();
            List<CatalagoChecklistE> listCatalogoChecklist = new List<CatalagoChecklistE>();

            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[IC].[CATALOGO_LIST]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        CatalagoChecklistE bean = new CatalagoChecklistE();
                        bean.Codigo = int.Parse(reader["CODIGO"].ToString());
                        bean.Nombre = reader["NOMBRE"].ToString();
                        bean.Descripcion = reader["DESCRIPCION"].ToString();
                        bean.Version = reader["VERSION"].ToString();
                        bean.Estado = reader["ESTADO"].ToString();
                        bean.Fecha_Creacion = reader["FECHA_CREACION"].ToString();
                        bean.Usuario_Creacion = reader["USUARIO_CREACION"].ToString();
                        bean.Prioridad = reader["PRIORIDAD"].ToString();
                        
                        //bean.Fecha_Aprobacion = DateTime.Parse(reader["FECHA_APROBACION"].ToString());
                        //bean.Fecha_Creacion = DateTime.Parse(reader["FECHA_CREACION"].ToString());
                        listCatalogoChecklist.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listCatalogoChecklist;
        }
        
        public int Modificar(CatalagoChecklistE oCatalogoE)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[dbo].[CATALOGO_UPDATE]";
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", oCatalogoE.Nombre));
                    cmd.Parameters.Add(new SqlParameter("@P_DESCRIPCION", oCatalogoE.Descripcion));
                    cmd.Parameters.Add(new SqlParameter("@P_VERSION", oCatalogoE.Version));
                    cmd.Parameters.Add(new SqlParameter("@P_PRIORIDAD", oCatalogoE.Prioridad));

                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public int Eliminar(CatalagoChecklistE oCatalogoE)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[CATALOGOCHECKLIST_ELIMINAR]";
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_MOTIVO_ELIMINACION", "NO MOTIVO"));

                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public int Aprobar(CatalagoChecklistE oCatalogoE)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[CATALOGOCHECKLIST_APROBAR]";
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));

                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }
    }
}
