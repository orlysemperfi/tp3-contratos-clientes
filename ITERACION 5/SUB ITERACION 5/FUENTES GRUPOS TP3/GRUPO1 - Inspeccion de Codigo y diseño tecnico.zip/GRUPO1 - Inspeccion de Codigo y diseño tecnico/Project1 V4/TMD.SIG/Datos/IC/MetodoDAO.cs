﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Entidades.IC;

namespace Datos.IC
{
    public class MetodoDAO
    {
        public int insert(Entidades.IC.CatalagoMetodoInspeccionE  o)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[METODO_INS]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    //cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", o.Descripcion));
                    cmd.Parameters.Add(new SqlParameter("@P_RESUMEN_OPERACION", o.ResumenOperacion));

                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public List<Entidades.IC.CatalagoMetodoInspeccionE> ListAlL()
        {
            //ConexionDAO cn = new ConexionDAO();
            List<CatalagoMetodoInspeccionE> listCatalogoChecklist = new List<CatalagoMetodoInspeccionE>();
            
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[IC].[METODO_LIST]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        CatalagoMetodoInspeccionE bean = new CatalagoMetodoInspeccionE();
                        bean.Codigo = int.Parse(reader["CODIGO"].ToString());
                        bean.Descripcion = reader["DESCRIPCION"].ToString();
                        bean.ResumenOperacion = reader["RESUMEN_OPERACION"].ToString();
                        bean.Estado = reader["ESTADO"].ToString();

                        //bean.Fecha_Aprobacion = DateTime.Parse(reader["FECHA_APROBACION"].ToString());
                        //bean.Fecha_Creacion = DateTime.Parse(reader["FECHA_CREACION"].ToString());
                        listCatalogoChecklist.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listCatalogoChecklist;
        }

        public int ModificarEstado(Entidades.IC.CatalagoMetodoInspeccionE o)
        {
            
                 //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[METODO_UPDATE]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    //cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_ESTADO", o.Estado));
                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", o.Codigo));

                    con.Open();
                    response = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public int Modificar(CatalagoMetodoInspeccionE oCatalogoE)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[METODO_UPDATE_CAMPOS]";
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", oCatalogoE.ResumenOperacion));
                    cmd.Parameters.Add(new SqlParameter("@P_DESCRIPCIOn", oCatalogoE.Descripcion));


                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

    }
}
