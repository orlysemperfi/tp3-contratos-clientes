﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;
using System.Data;
using System.Data.SqlClient;

namespace Datos.IC
{
    public class EstandarDAO: IEstandarDAO
    {

        #region Miembros de IEstandarDAO

        public int Insert(EstandaresE oEstandarE)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[ESTANDAR_INS]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oEstandarE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", oEstandarE.Nombre));
                    cmd.Parameters.Add(new SqlParameter("@P_DESCRIPCION", oEstandarE.Descripcion));
                    cmd.Parameters.Add(new SqlParameter("@P_ARCHIVO", oEstandarE.Archivo));
                    cmd.Parameters.Add(new SqlParameter("@P_USRCREA", oEstandarE.Usuario_Creacion));
                    cmd.Parameters.Add(new SqlParameter("@P_VERSION", oEstandarE.Version));


                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public List<EstandaresE> ListAll()
        {
            return null;
        }

        public List<EstandaresE> ListAll(Entidades.IC.EstandaresE o)
        {
            //ConexionDAO cn = new ConexionDAO();
            List<EstandaresE> listCatalogoChecklist = new List<EstandaresE>();

            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[IC].[ESTANDAR_LIS]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_ESTADO", o.Estado);
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        EstandaresE bean = new EstandaresE();
                        bean.Codigo = int.Parse ( reader["CODIGO"].ToString() );
                        bean.Nombre = reader["NOMBRE"].ToString();
                        bean.Descripcion = reader["DESCRIPCION"].ToString();
                        bean.Archivo = reader["ARCHIVO"].ToString();
                        bean.Estado = reader["ESTADO"].ToString();
                        bean.Version = int.Parse(reader["VERSION"].ToString());
                        bean.Fecha_Creacion =  reader["FECHA_CREACION"].ToString();
                        bean.Usuario_Creacion = reader["USUARIO_CREACION"].ToString();
                        listCatalogoChecklist.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listCatalogoChecklist;
        }

        public int Modificar(EstandaresE oEstandarE)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[ESTANDAR_UPD]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oEstandarE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", oEstandarE.Nombre));
                    cmd.Parameters.Add(new SqlParameter("@P_DESCRIPCION", oEstandarE.Descripcion));
                    cmd.Parameters.Add(new SqlParameter("@P_ARCHIVO", oEstandarE.Archivo));
                    cmd.Parameters.Add(new SqlParameter("@P_USRMODI", oEstandarE.Usuario_Modificacion));


                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public int Aprobar(EstandaresE oEstandarE)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[ESTANDAR_APR]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oEstandarE.Codigo));


                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }


        public int Eliminar(EstandaresE oEstandarE)
        {
            //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[ESTANDAR_DEL]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oEstandarE.Codigo));


                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        #endregion


    }
}
