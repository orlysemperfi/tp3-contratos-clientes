﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.IC;
using System.Data;
using System.Data.SqlClient;

namespace Datos.IC
{
    public class CatalogoPDAO : ICatalogoPDAO
    {

        #region Miembros de ICatalogoPDAO

        public int Insert(CatalagoPrioridadE oCatalogoE)
        {
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[CATALPRIO_INS]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", oCatalogoE.Nombre));
                    cmd.Parameters.Add(new SqlParameter("@P_DESCRIPCION", oCatalogoE.Descripcion));
                    cmd.Parameters.Add(new SqlParameter("@P_VALOR", oCatalogoE.Prioridad));
                    cmd.Parameters.Add(new SqlParameter("@P_MOTIVO", oCatalogoE.Motivo_Creacion));
                    cmd.Parameters.Add(new SqlParameter("@P_USRCREA", oCatalogoE.Usuario_Creacion));


                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public List<CatalagoPrioridadE> ListAll()
        {
            //ConexionDAO cn = new ConexionDAO();
            List<CatalagoPrioridadE> listCatalogoChecklist = new List<CatalagoPrioridadE>();

            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[IC].[CATALPRIO_LIS]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        CatalagoPrioridadE bean = new CatalagoPrioridadE();
                        bean.Codigo = int.Parse ( reader["CODIGO"].ToString() );
                        bean.Nombre = reader["NOMBRE"].ToString();
                        bean.Descripcion = reader["DESCRIPCION"].ToString();
                        bean.Prioridad = reader["PRIORIDAD"].ToString();
                        bean.Motivo_Creacion = reader["MOTIVO_CREACION"].ToString();
                        bean.Motivo_Modificacion = reader["MOTIVO_MODIFICACION"].ToString();
                        bean.Estado = reader["ESTADO"].ToString();
                        bean.Version = reader["VERSION"].ToString();
                        bean.Fecha_Creacion =  reader["FECHA_CREACION"].ToString();
                        bean.Fecha_Aprobacion = reader["FECHA_APROBACION"].ToString();
                        bean.Fecha_Modificacion = reader["FECHA_MODIFICACION"].ToString();
                        bean.Usuario_Modificacion = reader["USUARIO_MODIFICACION"].ToString();
                        bean.Usuario_Creacion = reader["USUARIO_CREACION"].ToString();
                        bean.Usuario_Aprobacion  = reader["USUARIO_APROBACION"].ToString();
                        listCatalogoChecklist.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listCatalogoChecklist;
        }


        public int Modificar(CatalagoPrioridadE oCatalogoE)
        {
             //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[CATALPRIO_UPD]";
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", oCatalogoE.Nombre));
                    cmd.Parameters.Add(new SqlParameter("@P_DESCRIPCION", oCatalogoE.Descripcion));
                    cmd.Parameters.Add(new SqlParameter("@P_VALOR", oCatalogoE.Prioridad));
                    cmd.Parameters.Add(new SqlParameter("@P_MOTIVO", oCatalogoE.Motivo_Modificacion));
                    cmd.Parameters.Add(new SqlParameter("@P_USRMODI", oCatalogoE.Usuario_Modificacion));


                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public int Aprobar(CatalagoPrioridadE oCatalogoE)
        {
              //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[ESTANDAR_APR]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_USRAPR", oCatalogoE.Usuario_Aprobacion));


                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        public List<Entidades.IC.CatalagoPrioridadE> Buscar(String nombre)
        {
            //ConexionDAO cn = new ConexionDAO();
            List<CatalagoPrioridadE> listCatalogoChecklist = new List<CatalagoPrioridadE>();

            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[IC].[CATALPRIO_BUS]", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@P_NOMBRE", nombre));
                    con.Open();
                    IDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        CatalagoPrioridadE bean = new CatalagoPrioridadE();
                        bean.Codigo = int.Parse(reader["CODIGO"].ToString());
                        bean.Nombre = reader["NOMBRE"].ToString();
                        bean.Descripcion = reader["DESCRIPCION"].ToString();
                        bean.Prioridad = reader["PRIORIDAD"].ToString();
                        bean.Motivo_Creacion = reader["MOTIVO_CREACION"].ToString();
                        bean.Motivo_Modificacion = reader["MOTIVO_MODIFICACION"].ToString();
                        bean.Estado = reader["ESTADO"].ToString();
                        bean.Version = reader["VERSION"].ToString();
                        bean.Fecha_Creacion = reader["FECHA_CREACION"].ToString();
                        bean.Fecha_Aprobacion = reader["FECHA_APROBACION"].ToString();
                        bean.Fecha_Modificacion = reader["FECHA_MODIFICACION"].ToString();
                        bean.Usuario_Modificacion = reader["USUARIO_MODIFICACION"].ToString();
                        bean.Usuario_Creacion = reader["USUARIO_CREACION"].ToString();
                        bean.Usuario_Aprobacion = reader["USUARIO_APROBACION"].ToString();
                        listCatalogoChecklist.Add(bean);
                    }

                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            return listCatalogoChecklist;
        }

        public int Eliminar(CatalagoPrioridadE oCatalogoE)
        {
             //ConexionDAO cn = new ConexionDAO();
            int response = -1;
            using (SqlConnection con = new SqlConnection(CatalogoConexionDAO.CadenaConexion()))
            {
                try
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "[IC].[ESTANDAR_DEL]";
                    cmd.CommandType = CommandType.StoredProcedure;


                    cmd.Parameters.Add(new SqlParameter("@P_CODIGO", oCatalogoE.Codigo));
                    cmd.Parameters.Add(new SqlParameter("@P_MOTIVO", oCatalogoE.Motivo_Eiminacion));
                    cmd.Parameters.Add(new SqlParameter("@P_USRMODI", oCatalogoE.Usuario_Modificacion));


                    con.Open();
                    response = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                return response;
            }
        }

        #endregion
    }
}
