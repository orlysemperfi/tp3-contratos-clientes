﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.GD
{
    public class FormularioCabeceraE
    {
        public Int32 CODIGO_EMPLEADO { get; set; }
        public string EVALUADO { get; set; }
        public string ROL { get; set; }
        public string PROYECTO { get; set; }
        public string FECHA { get; set; }
        public string FRECEPCION { get; set; }
        public string EVALUADOR { get; set; }
        public string NOMBRE { get; set; }
        public string ESTADO { get; set; }
        public string AREA { get; set; }
        public Int32 CODIGO_PROYECTO { get; set; }
         
    }
}
