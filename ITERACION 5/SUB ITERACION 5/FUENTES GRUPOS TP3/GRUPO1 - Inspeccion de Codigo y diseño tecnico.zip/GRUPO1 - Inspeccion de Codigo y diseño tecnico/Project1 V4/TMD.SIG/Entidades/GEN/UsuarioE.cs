﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.GEN
{
    public class UsuarioE
    {
        public string Codigo { get; set; }
        public string Nombre { get; set; }
    }
}
