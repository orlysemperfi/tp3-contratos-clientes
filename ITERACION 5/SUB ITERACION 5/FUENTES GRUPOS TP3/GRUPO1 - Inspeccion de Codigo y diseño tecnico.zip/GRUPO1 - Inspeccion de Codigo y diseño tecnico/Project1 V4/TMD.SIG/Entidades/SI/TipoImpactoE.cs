﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.SI
{
    public class TipoImpactoE
    {
        public int codTipoImpacto { get; set; }
        public string nomTipoImpacto { get; set; }
    }
}
