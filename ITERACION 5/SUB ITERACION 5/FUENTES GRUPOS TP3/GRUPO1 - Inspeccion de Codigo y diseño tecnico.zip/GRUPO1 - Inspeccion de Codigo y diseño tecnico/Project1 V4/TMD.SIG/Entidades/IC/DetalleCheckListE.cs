﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.IC
{
    public class DetalleCheckListE
    {
        public int CodigoCheckList { get; set; }
        public int CodigoDetalle { get; set; }
        public string Prioridad { get; set; }
        public string CHECKLIST { get; set; }
        public string Obligatorio { get; set; }
    }
}
