﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.GD
{
    public class FormularioGeneracionDetalle
    {
        public Int32 CODIGO_FORMULARIO { get; set; }
        public Int32 CODIGO_SECCION_DETALLE { get; set; }
        public Int32 CODIGO_SECCION { get; set; }

     
       
    }
}
