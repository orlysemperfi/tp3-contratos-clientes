﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.IC
{

        public class DetalleMetricaE
        {
            public int CodigoMetrica { get; set; }
            public int CodigoDetalle { get; set; }
            public string Metrica { get; set; }
        }
}
