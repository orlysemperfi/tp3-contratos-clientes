﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.SI
{
    public class IncidenciaE
    {
        public int codIncidencia { get; set; }
        public int codTicket { get; set; }
        public int codControl { get; set; }
        public string fechaApertura { get; set; }
        public int codPrioridad { get; set; }
        public int codImpacto { get; set; }
        public int codEstado { get; set; }
        public string resumen { get; set; }
        public string accionInmediata { get; set; }
        public string causa { get; set; }
        public decimal estimacionCosto { get; set; }
    }
}
