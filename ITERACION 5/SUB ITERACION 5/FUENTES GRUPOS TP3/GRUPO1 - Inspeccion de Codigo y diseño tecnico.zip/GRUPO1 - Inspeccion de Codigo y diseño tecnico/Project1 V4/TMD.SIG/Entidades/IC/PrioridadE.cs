﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.IC
{
    public class PrioridadE
    {
        public string Nombre {get;set;}
        public string Descripcion{get;set;}
        public string Estado{get;set;}
        public int Codigo { get; set; }
    }
}
