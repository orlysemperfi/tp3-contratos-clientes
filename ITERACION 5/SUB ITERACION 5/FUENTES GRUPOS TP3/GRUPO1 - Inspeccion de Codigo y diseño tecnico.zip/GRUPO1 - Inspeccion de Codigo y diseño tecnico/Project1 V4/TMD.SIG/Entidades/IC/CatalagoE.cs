﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.IC
{
    public class CatalagoChecklistE
    {
        public int Codigo { get; set; }
        public string Nombre {get;set;}
        public string Descripcion {get;set;}
        public string Version {get;set;}
        public  string Prioridad {get;set;}
        public  string Motivo_Creacion {get;set;}
        public  string Motivo_Modificacion {get;set;}
        public  string Motivo_Eiminacion {get;set;}
        public  string Estado {get;set;}
        public  string Obligatorio_Cumplir {get;set;}
        public  string Responsable_Documentacion {get;set;}
        public  string Usuario_Aprobacion {get;set;}
        public  DateTime Fecha_Aprobacion {get;set;}
        public  string Usuario_Creacion {get;set;} 
        public  string Fecha_Creacion {get;set;}
        public  string Usuario_Modificacion {get;set;}
        public DateTime Fecha_Modificacion { get; set; }
    }

    public class CatalagoMetodoInspeccionE
    {
        public int Codigo { get; set; }
        public string Descripcion { get; set; }
        public string ResumenOperacion { get; set; }
        public string Version { get; set; }
        public string Motivo_Creacion { get; set; }
        public string Motivo_Modificacion { get; set; }
        public string Motivo_Eiminacion { get; set; }
        public string Estado { get; set; }
        public string Obligatorio_Cumplir { get; set; }
        public string Responsable_Documentacion { get; set; }
        public string Archivo { get; set; }
        public string Usuario_Aprobacion { get; set; }
        public string Fecha_Aprobacion { get; set; }
        public string Usuario_Creacion { get; set; }
        public string Fecha_Creacion { get; set; }
        public string Usuario_Modificacion { get; set; }
        public string Fecha_Modificacion { get; set; }
    }

    public class CatalagoMetricaE
    {
        public int Codigo { get; set; }
        public string Descripcion { get; set; }
        public string Objetivo { get; set; }
        public string Formula_Calculo { get; set; }
        public string Responsable_Mantenimiento { get; set; }
        public string Version { get; set; }
        public string Motivo_Creacion { get; set; }
        public string Motivo_Modificacion { get; set; }
        public string Motivo_Eiminacion { get; set; }
        public string Estado { get; set; }
        public string Responsable_Documentacion { get; set; }
        public string Archivo { get; set; }
        public string Usuario_Aprobacion { get; set; }
        public DateTime Fecha_Aprobacion { get; set; }
        public string Usuario_Creacion { get; set; }
        public DateTime Fecha_Creacion { get; set; }
        public string Usuario_Modificacion { get; set; }
        public DateTime Fecha_Modificacion { get; set; }
    }

    public class CatalagoPrioridadE
    {
        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Prioridad { get; set; }
        public string Version { get; set; }
        public string Motivo_Creacion { get; set; }
        public string Motivo_Modificacion { get; set; }
        public string Motivo_Eiminacion { get; set; }
        public string Estado { get; set; }
        public string Responsable_Documentacion { get; set; }
        public string Usuario_Aprobacion { get; set; }
        public string Fecha_Aprobacion { get; set; }
        public string Usuario_Creacion { get; set; }
        public string Fecha_Creacion { get; set; }
        public string Usuario_Modificacion { get; set; }
        public string Fecha_Modificacion { get; set; }
    }

    public class CatalagoRolesE
    {
        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Prioridad { get; set; }
        public string Version { get; set; }
        public string Motivo_Creacion { get; set; }
        public string Motivo_Modificacion { get; set; }
        public string Motivo_Eiminacion { get; set; }
        public string Estado { get; set; }
        public string Codigo_Estandar_Programacion_Diseno{ get; set; }
        public string Responsable_Documentacion { get; set; }
        public string Usuario_Aprobacion { get; set; }
        public DateTime Fecha_Aprobacion { get; set; }
        public string Usuario_Creacion { get; set; }
        public DateTime Fecha_Creacion { get; set; }
        public string Usuario_Modificacion { get; set; }
        public DateTime Fecha_Modificacion { get; set; }
    }

    
}
