﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.SI
{
    public class ProcesoImpactoE
    {
        // Para grabar
        public int codProceso { get; set; }
        public int codTipoImpacto { get; set; }
        public int codPrioridad { get; set; }
        public string observacion { get; set; }

        // Para mostrar datos
        public string desImpacto { get; set; }
        public string desValor { get; set; }


    }
}