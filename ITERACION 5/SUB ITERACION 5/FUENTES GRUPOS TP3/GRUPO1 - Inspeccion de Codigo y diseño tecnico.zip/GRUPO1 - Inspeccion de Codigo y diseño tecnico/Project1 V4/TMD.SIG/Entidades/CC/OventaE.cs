﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.CC
{
    public class OventaE
    {
        public string RUC { get; set; }
        public string RAZON_SOCIAL { get; set; }
        public string RUBRO { get; set; }
        public string TIPO { get; set; }
        public string CONTACTO { get; set; }
        public string TELEFONO { get; set; }
        public string CORREO { get; set; }
        public string CARGO { get; set; }
        public string DIRECCION { get; set; }
    }
}
