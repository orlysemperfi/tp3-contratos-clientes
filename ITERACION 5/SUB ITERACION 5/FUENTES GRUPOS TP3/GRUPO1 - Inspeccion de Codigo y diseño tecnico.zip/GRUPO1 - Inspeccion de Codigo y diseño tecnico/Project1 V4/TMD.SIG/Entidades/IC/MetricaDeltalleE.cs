﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.IC
{
    public class MetricaDeltalleE
    {
        public int CodigoMetrica { get; set; }
        public int CodigoCriterio { get; set; }
    }
}
