﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.SI
{
    public class ResponsableControlE
    {
        public int codResponsable { get; set; }
        public string nomResponsable { get; set; }
    }
}
