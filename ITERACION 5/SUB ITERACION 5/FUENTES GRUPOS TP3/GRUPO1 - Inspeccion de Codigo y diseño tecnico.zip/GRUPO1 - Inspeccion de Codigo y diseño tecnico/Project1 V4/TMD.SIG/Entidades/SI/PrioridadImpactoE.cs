﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.SI
{
    public class PrioridadImpactoE
    {
        public int codValor { get; set; }
        public string valor { get; set; }
        public string descripValor { get; set; }
        public string criterio { get; set; }
    }
}
