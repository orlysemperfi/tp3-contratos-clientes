﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.CC
{
   public class EntregableE 
    {
       public int Codigo { get; set; }
       public String Nombre { get; set; }
       public int CodigoRol { get; set; }
       public String NombreRol { get; set; }
       public DateTime FechaPactada { get; set; }
    }
}
