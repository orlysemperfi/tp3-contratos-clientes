﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.SI
{
    public class ControlE
    {
        public int codControl { get; set; }
        public string nomControl { get; set; }
        public int codEmpleado { get; set; }

    }
}
