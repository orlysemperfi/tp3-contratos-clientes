﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.SI
{
    public class ProcesoE
    {
        public int codProceso { get; set; }
        public string nomProceso { get; set; }
        public int codTipoProceso { get; set; }
        public string objetivo { get; set; }
        public int rto { get; set; }
        public int mtd { get; set; }
        public int codResp { get; set; }
        public int codArea { get; set; }
        public string rutaPCN { get; set; }
        public int estadoProceso { get; set; }

        public int codResponsable { get; set; }
        public string estProceso { get; set; }
        public string nomTipoProceso { get; set; }
        public string nomRTO { get; set; }
        public string nomMTD { get; set; }
        public string nomEmpleado { get; set; }
        public string nomArea { get; set; }
        public string objProceso { get; set; }
        public string impacto { get; set; }
    }
}
