﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.CC {

  public class EstadoContratoE {

    public string CODIGO { get; set; }
    public string NOMBRE { get; set; }

  }


}
