﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.SI
{
    public class PoliticaE
    {
        public int codPolitica { get; set; }
        public string nomPolitica { get; set; }
    }
}
