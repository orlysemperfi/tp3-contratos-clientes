﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.CC
{
   public class MonedaE
    {
       public String CODIGO_MONEDA { get; set; }
       public String NOMBRE { get; set; }
    }
}
