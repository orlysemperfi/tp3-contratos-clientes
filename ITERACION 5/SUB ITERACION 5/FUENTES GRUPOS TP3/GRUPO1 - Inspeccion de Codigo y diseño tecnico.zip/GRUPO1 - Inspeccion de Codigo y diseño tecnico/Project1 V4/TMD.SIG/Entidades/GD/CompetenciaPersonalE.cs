﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Entidades.GD
{
   public class CompetenciaPersonalE
    {
       public Int32 CODIGO_COMPETENCIA_INDICADOR_DETALLE { get; set; }
        public String NOMBRE_COMPETENCIA { get; set; }
        public String TIPO_COMPETENCIA { get; set; }
        public Int32 CODIGO_COMPETENCIA_INDICADOR { get; set; }
        public String DESCRIPCION_COMPETENCIA { get; set; }
        public Int32 CODIGO_TIPO_CALIFICACION_EVALUACION { get; set; }
        public String DESCRIPCION_COMPETENCIA_INDICADOR { get; set; }
        public String NIVEL1 { get; set; }
        public String NIVEL2 { get; set; }
        public String NIVEL3 { get; set; }
        public String NIVEL4 { get; set; }
        public String NIVEL5 { get; set; }

  

    }
}
