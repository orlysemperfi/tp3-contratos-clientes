﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.CC
{
   public class RolE
    {
       public int Codigo { get; set; }
       public String Nombre { get; set; }
    }
}
