﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.CC {

  public class EstadoAdendaE {

    public string CODIGO { get; set; }
    public string NOMBRE { get; set; }

  }


}
